-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: tribes_cliqs
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(220) NOT NULL,
  `message` text NOT NULL,
  `target_role` enum('all','attendee','organizer','admin') NOT NULL DEFAULT 'all',
  `channel` enum('in_app','email','sms','push') NOT NULL DEFAULT 'in_app',
  `created_by` bigint(20) DEFAULT NULL,
  `sent_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ann_creator` (`created_by`),
  CONSTRAINT `fk_ann_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(60) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(300) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,NULL,'register','user',3,NULL,NULL,NULL,'2026-08-04 16:15:49'),(2,NULL,'login','user',3,NULL,NULL,NULL,'2026-08-04 16:15:57'),(3,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 16:16:59'),(4,6,'register','user',6,NULL,NULL,NULL,'2026-08-04 16:18:28'),(5,6,'login','user',6,NULL,NULL,NULL,'2026-08-04 16:18:32'),(6,6,'logout','user',6,NULL,NULL,NULL,'2026-08-04 16:19:10'),(7,1,'login','user',1,NULL,NULL,NULL,'2026-08-04 16:21:53'),(8,1,'logout','user',1,NULL,NULL,NULL,'2026-08-04 16:36:38'),(9,6,'login','user',6,NULL,NULL,NULL,'2026-08-04 16:37:58'),(10,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 16:38:45'),(11,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 16:39:36'),(12,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 16:41:35'),(13,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 16:41:41'),(14,6,'logout','user',6,NULL,NULL,NULL,'2026-08-04 16:44:59'),(15,9,'register','user',9,NULL,NULL,NULL,'2026-08-04 16:45:59'),(16,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 16:47:43'),(17,NULL,'register','user',10,NULL,NULL,NULL,'2026-08-04 16:51:16'),(18,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 16:51:28'),(19,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 16:51:54'),(20,NULL,'register','user',13,NULL,NULL,NULL,'2026-08-04 17:00:47'),(21,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 17:00:48'),(22,1,'approve_organizer','user',10,NULL,NULL,NULL,'2026-08-04 17:00:48'),(23,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 17:00:56'),(24,1,'reject_organizer','user',9,'{\"reason\":\"Incomplete documentation.\"}',NULL,NULL,'2026-08-04 17:00:56'),(25,1,'approve_organizer','user',9,NULL,NULL,NULL,'2026-08-04 17:45:46'),(26,9,'login','user',9,NULL,NULL,NULL,'2026-08-04 17:46:03'),(27,NULL,'login','user',10,NULL,NULL,NULL,'2026-08-04 17:57:26'),(28,NULL,'login','user',10,NULL,NULL,NULL,'2026-08-04 17:57:57'),(29,NULL,'login','user',10,NULL,NULL,NULL,'2026-08-04 17:58:12'),(30,NULL,'login','user',10,NULL,NULL,NULL,'2026-08-04 17:58:34'),(31,NULL,'login','user',10,NULL,NULL,NULL,'2026-08-04 17:59:19'),(32,NULL,'login','user',10,NULL,NULL,NULL,'2026-08-04 18:11:26'),(33,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-04 18:19:45'),(34,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-05 02:15:49'),(35,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-05 02:21:49'),(36,9,'logout','user',9,NULL,NULL,NULL,'2026-08-05 02:43:24'),(37,6,'login','user',6,NULL,NULL,NULL,'2026-08-05 02:43:31'),(38,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-05 02:46:59'),(39,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-05 02:49:27'),(40,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-05 02:49:48'),(41,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-05 02:50:04'),(42,6,'login','user',6,NULL,NULL,NULL,'2026-08-12 22:36:09'),(43,6,'logout','user',6,NULL,NULL,NULL,'2026-08-13 04:08:40'),(44,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:10:48'),(45,1,'approve_organizer','user',9,NULL,NULL,NULL,'2026-08-13 04:11:07'),(46,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:12:31'),(47,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:16:50'),(48,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:17:23'),(49,NULL,'register','user',20,NULL,NULL,NULL,'2026-08-13 04:17:23'),(50,1,'approve_organizer','user',20,NULL,NULL,NULL,'2026-08-13 04:17:24'),(51,1,'approve_organizer','user',20,NULL,NULL,NULL,'2026-08-13 04:17:24'),(52,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:17:55'),(53,1,'approve_organizer','user',9,NULL,NULL,NULL,'2026-08-13 04:19:36'),(54,1,'approve_organizer','user',9,NULL,NULL,NULL,'2026-08-13 04:19:59'),(55,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:21:18'),(56,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:22:19'),(57,1,'update_system_settings','system',NULL,'{\"keys\":[\"platform_name\",\"commission_pct\"]}',NULL,NULL,'2026-08-13 04:22:19'),(58,1,'update_system_settings','system',NULL,'{\"keys\":[\"platform_name\",\"currency\",\"timezone\",\"maintenance_mode\",\"paystack_secret_key\",\"paystack_public_key\",\"commission_pct\",\"smtp_host\",\"smtp_port\",\"resend_api_key\",\"sms_api_key\",\"sms_sender_id\",\"jwt_expires_in\",\"max_login_attempts\",\"email_verification\",\"vat_percent\"]}',NULL,NULL,'2026-08-13 04:22:43'),(59,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:22:49'),(60,NULL,'register','user',21,NULL,NULL,NULL,'2026-08-13 04:22:58'),(61,NULL,'register','user',22,NULL,NULL,NULL,'2026-08-13 04:22:59'),(62,1,'approve_organizer','user',22,NULL,NULL,NULL,'2026-08-13 04:23:29'),(63,1,'approve_organizer','user',21,NULL,NULL,NULL,'2026-08-13 04:23:33'),(64,1,'approve_organizer','user',21,NULL,NULL,NULL,'2026-08-13 04:23:39'),(65,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:23:48'),(66,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:24:05'),(67,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:25:12'),(68,NULL,'register','user',23,NULL,NULL,NULL,'2026-08-13 04:25:12'),(69,1,'reject_organizer','user',23,'{\"reason\":\"Test rejection reason\"}',NULL,NULL,'2026-08-13 04:25:13'),(70,1,'approve_organizer','user',9,NULL,NULL,NULL,'2026-08-13 04:26:04'),(71,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:27:55'),(72,NULL,'register','user',24,NULL,NULL,NULL,'2026-08-13 04:30:35'),(73,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:30:35'),(74,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:31:06'),(75,1,'approve_organizer','user',9,NULL,NULL,NULL,'2026-08-13 04:38:02'),(76,6,'login','user',6,NULL,NULL,NULL,'2026-08-13 04:38:38'),(77,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:43:33'),(78,NULL,'register','user',25,NULL,NULL,NULL,'2026-08-13 04:49:11'),(79,NULL,'register','user',26,NULL,NULL,NULL,'2026-08-13 04:49:16'),(80,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:49:17'),(81,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:50:11'),(82,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:50:17'),(83,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:50:24'),(84,1,'approve_organizer','user',26,NULL,NULL,NULL,'2026-08-13 04:50:24'),(85,NULL,'login','user',26,NULL,NULL,NULL,'2026-08-13 04:50:24'),(86,NULL,'login','user',26,NULL,NULL,NULL,'2026-08-13 04:51:20'),(87,NULL,'login','user',26,NULL,NULL,NULL,'2026-08-13 04:52:43'),(88,NULL,'login','user',26,NULL,NULL,NULL,'2026-08-13 04:53:01'),(89,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:54:16'),(90,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:54:25'),(91,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:54:32'),(92,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:54:38'),(93,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 04:59:51'),(94,6,'update_profile','user',6,NULL,NULL,NULL,'2026-08-13 05:14:57'),(95,NULL,'register','user',27,NULL,NULL,NULL,'2026-08-13 05:15:37'),(96,NULL,'login','user',27,NULL,NULL,NULL,'2026-08-13 05:15:51'),(97,1,'login','user',1,NULL,NULL,NULL,'2026-08-13 05:16:25'),(98,1,'login','user',1,NULL,NULL,NULL,'2026-08-13 05:16:32'),(99,1,'update_system_settings','system',NULL,'{\"keys\":[\"platform_name\",\"currency\",\"timezone\",\"maintenance_mode\",\"paystack_secret_key\",\"paystack_public_key\",\"commission_pct\",\"smtp_host\",\"smtp_port\",\"resend_api_key\",\"sms_api_key\",\"sms_sender_id\",\"jwt_expires_in\",\"max_login_attempts\",\"email_verification\",\"vat_percent\"]}',NULL,NULL,'2026-08-13 07:00:44'),(100,1,'update_system_settings','system',NULL,'{\"keys\":[\"platform_name\",\"currency\",\"timezone\",\"maintenance_mode\",\"paystack_secret_key\",\"paystack_public_key\",\"commission_pct\",\"smtp_host\",\"smtp_port\",\"resend_api_key\",\"sms_api_key\",\"sms_sender_id\",\"jwt_expires_in\",\"max_login_attempts\",\"email_verification\",\"vat_percent\"]}',NULL,NULL,'2026-08-13 07:01:45'),(101,6,'logout','user',6,NULL,NULL,NULL,'2026-08-13 07:02:00'),(102,6,'login','user',6,NULL,NULL,NULL,'2026-08-13 07:02:37'),(103,6,'logout','user',6,NULL,NULL,NULL,'2026-08-13 07:08:57'),(104,6,'forgot_password','user',6,NULL,NULL,NULL,'2026-08-13 11:49:25'),(105,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:15:52'),(106,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:15:59'),(107,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:16:44'),(108,1,'admin_update_user','user',9,'{\"changed\":{\"name\":\"Kwame Darlington Junior\",\"email\":\"asomanirawlingsjunior71@gmail.com\",\"role\":\"organizer\",\"phone\":\"+233257501827\"}}',NULL,NULL,'2026-08-13 12:18:11'),(109,1,'admin_update_user','user',6,'{\"changed\":{\"name\":\"Asomani Rawlings Junior\",\"email\":\"asomanirawlingsjunior5333@gmail.com\",\"role\":\"attendee\",\"phone\":\"+233257501827\"}}',NULL,NULL,'2026-08-13 12:18:24'),(110,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:21:42'),(111,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:21:53'),(112,1,'suspend_user','user',6,'{\"reason\":\"Verification of suspend flow\"}',NULL,NULL,'2026-08-13 12:21:54'),(113,1,'unsuspend_user','user',6,NULL,NULL,NULL,'2026-08-13 12:21:55'),(114,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:22:02'),(115,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:23:21'),(116,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:37:09'),(117,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:37:26'),(118,1,'update_profile','user',1,NULL,NULL,NULL,'2026-08-13 12:37:27'),(119,NULL,'register','user',29,NULL,NULL,NULL,'2026-08-13 12:43:09'),(120,NULL,'login','user',29,NULL,NULL,NULL,'2026-08-13 12:43:29'),(121,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:44:26'),(122,1,'delete_user','user',29,'{\"name\":\"Frontend Tester\",\"email\":\"frontendtester@test.com\"}',NULL,NULL,'2026-08-13 12:44:27'),(123,NULL,'register','user',30,NULL,NULL,NULL,'2026-08-13 12:58:27'),(124,NULL,'login','user',30,NULL,NULL,NULL,'2026-08-13 12:58:38'),(125,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:58:39'),(126,1,'create_event','event',3,NULL,NULL,NULL,'2026-08-13 12:58:40'),(127,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:59:18'),(128,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 12:59:46'),(129,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:12:01'),(130,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:12:04'),(131,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:12:26'),(132,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:12:33'),(133,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:12:39'),(134,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:12:44'),(135,1,'login','user',1,NULL,NULL,NULL,'2026-08-13 14:23:17'),(136,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:25:13'),(137,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:25:19'),(138,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-13 14:25:31'),(139,6,'login','user',6,NULL,NULL,NULL,'2026-08-14 06:36:11'),(140,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-16 11:03:32'),(141,1,'delete_user','user',30,'{\"name\":\"Community Tester\",\"email\":\"communitytester@test.com\"}',NULL,NULL,'2026-08-16 11:03:53'),(142,6,'logout','user',6,NULL,NULL,NULL,'2026-08-16 11:30:45'),(143,1,'logout','user',1,NULL,NULL,NULL,'2026-08-16 11:31:12'),(144,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-16 11:31:49'),(145,1,'admin_reset_password','user',9,'{\"generated\":false,\"by\":\"admin@tribesandcliqs.com\"}',NULL,NULL,'2026-08-16 11:32:24'),(146,9,'login','user',9,NULL,NULL,NULL,'2026-08-16 11:33:28'),(147,1,'logout','user',1,NULL,NULL,NULL,'2026-08-16 11:41:19'),(148,9,'login','user',9,NULL,NULL,NULL,'2026-08-16 11:41:29'),(149,9,'create_event','event',4,NULL,NULL,NULL,'2026-08-16 11:50:54'),(150,9,'logout','user',9,NULL,NULL,NULL,'2026-08-16 11:51:02'),(151,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-16 11:51:15'),(152,1,'approve_event','event',4,NULL,NULL,NULL,'2026-08-16 11:51:50'),(153,9,'logout','user',9,NULL,NULL,NULL,'2026-08-16 11:52:52'),(154,6,'login','user',6,NULL,NULL,NULL,'2026-08-16 11:53:00'),(155,1,'logout','user',1,NULL,NULL,NULL,'2026-08-16 11:54:04'),(156,6,'login','user',6,NULL,NULL,NULL,'2026-08-16 11:54:13'),(157,6,'logout','user',6,NULL,NULL,NULL,'2026-08-16 12:09:11'),(158,1,'admin_login','user',1,NULL,NULL,NULL,'2026-08-16 12:09:21'),(159,1,'update_system_settings','system',NULL,'{\"keys\":[\"platform_name\",\"currency\",\"timezone\",\"maintenance_mode\",\"paystack_secret_key\",\"paystack_public_key\",\"commission_pct\",\"smtp_host\",\"smtp_port\",\"resend_api_key\",\"sms_api_key\",\"sms_sender_id\",\"jwt_expires_in\",\"max_login_attempts\",\"email_verification\",\"vat_percent\"]}',NULL,NULL,'2026-08-16 12:10:14'),(160,6,'create_order','order',2,NULL,NULL,NULL,'2026-08-16 12:10:40'),(161,6,'create_resale_listing','resale_listing',1,'{\"ticketId\":1,\"eventId\":4,\"price\":250}',NULL,NULL,'2026-08-16 12:23:30'),(162,6,'cancel_resale_listing','resale_listing',1,NULL,NULL,NULL,'2026-08-16 12:23:42'),(163,6,'logout','user',6,NULL,NULL,NULL,'2026-08-16 12:24:09'),(164,9,'login','user',9,NULL,NULL,NULL,'2026-08-16 12:24:13'),(165,1,'update_system_settings','system',NULL,'{\"keys\":[\"platform_name\",\"currency\",\"timezone\",\"maintenance_mode\",\"paystack_secret_key\",\"paystack_public_key\",\"commission_pct\",\"smtp_host\",\"smtp_port\",\"resend_api_key\",\"sms_api_key\",\"sms_sender_id\",\"jwt_expires_in\",\"max_login_attempts\",\"email_verification\",\"vat_percent\"]}',NULL,NULL,'2026-08-16 14:11:15'),(166,1,'update_system_settings','system',NULL,'{\"keys\":[\"platform_name\",\"currency\",\"timezone\",\"maintenance_mode\",\"paystack_secret_key\",\"paystack_public_key\",\"commission_pct\",\"smtp_host\",\"smtp_port\",\"resend_api_key\",\"sms_api_key\",\"sms_sender_id\",\"jwt_expires_in\",\"max_login_attempts\",\"email_verification\",\"vat_percent\"]}',NULL,NULL,'2026-08-16 14:14:06'),(167,1,'logout','user',1,NULL,NULL,NULL,'2026-08-16 14:39:41'),(168,9,'login','user',9,NULL,NULL,NULL,'2026-08-16 14:39:49');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `subtitle` varchar(300) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `link_url` varchar(300) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_posts`
--

DROP TABLE IF EXISTS `blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_posts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `slug` varchar(280) DEFAULT NULL,
  `excerpt` text DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `cover_image` varchar(500) DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `status` enum('draft','published','archived') NOT NULL DEFAULT 'draft',
  `published_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_bp_author` (`author_id`),
  CONSTRAINT `fk_bp_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_posts`
--

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `icon` varchar(80) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Concert','concert','mic',NULL,1,1,'2026-08-04 16:13:39','2026-08-04 16:13:39'),(2,'Sports','sports','Music',NULL,1,2,'2026-08-04 16:13:39','2026-08-04 16:30:40'),(3,'Festival','festival','sparkles',NULL,1,3,'2026-08-04 16:13:39','2026-08-04 16:13:39'),(4,'Conference','conference','presentation',NULL,1,4,'2026-08-04 16:13:39','2026-08-04 16:13:39'),(5,'Seminar','seminar','graduation-cap',NULL,1,5,'2026-08-04 16:13:39','2026-08-04 16:13:39'),(6,'Workshop','workshop','wrench',NULL,1,6,'2026-08-04 16:13:39','2026-08-04 16:13:39'),(7,'Theatre','theatre','drama',NULL,1,7,'2026-08-04 16:13:39','2026-08-04 16:13:39'),(8,'Church Programs','church-programs','church',NULL,1,8,'2026-08-04 16:13:39','2026-08-04 16:13:39'),(9,'Weddings','weddings','heart',NULL,1,9,'2026-08-04 16:13:39','2026-08-04 16:13:39'),(10,'Fashion Shows','fashion-shows','shirt',NULL,1,10,'2026-08-04 16:13:39','2026-08-04 16:13:39');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) DEFAULT NULL,
  `organizer_id` bigint(20) NOT NULL,
  `code` varchar(40) NOT NULL,
  `discount_type` enum('percentage','fixed') NOT NULL DEFAULT 'percentage',
  `discount_value` decimal(10,2) NOT NULL,
  `max_uses` int(11) DEFAULT 0,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `valid_from` datetime DEFAULT NULL,
  `valid_to` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `fk_coup_event` (`event_id`),
  KEY `fk_coup_org` (`organizer_id`),
  KEY `idx_coup_code` (`code`),
  CONSTRAINT `fk_coup_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_coup_org` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_verifications`
--

DROP TABLE IF EXISTS `email_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_verifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_ev_user` (`user_id`),
  CONSTRAINT `fk_ev_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_verifications`
--

LOCK TABLES `email_verifications` WRITE;
/*!40000 ALTER TABLE `email_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_meetup_members`
--

DROP TABLE IF EXISTS `event_meetup_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_meetup_members` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `meetup_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `role` enum('host','member') NOT NULL DEFAULT 'member',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_member` (`meetup_id`,`user_id`),
  KEY `fk_emm_user` (`user_id`),
  CONSTRAINT `fk_emm_meetup` FOREIGN KEY (`meetup_id`) REFERENCES `event_meetups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_emm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_meetup_members`
--

LOCK TABLES `event_meetup_members` WRITE;
/*!40000 ALTER TABLE `event_meetup_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_meetup_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_meetups`
--

DROP TABLE IF EXISTS `event_meetups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_meetups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `host_id` bigint(20) NOT NULL,
  `title` varchar(160) NOT NULL,
  `description` text DEFAULT NULL,
  `meeting_spot` varchar(200) DEFAULT NULL,
  `meet_at` datetime DEFAULT NULL,
  `max_members` int(11) DEFAULT 0,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_em_host` (`host_id`),
  KEY `idx_em_event` (`event_id`),
  CONSTRAINT `fk_em_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_em_host` FOREIGN KEY (`host_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_meetups`
--

LOCK TABLES `event_meetups` WRITE;
/*!40000 ALTER TABLE `event_meetups` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_meetups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `organizer_id` bigint(20) NOT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `title` varchar(220) NOT NULL,
  `slug` varchar(260) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(80) DEFAULT NULL,
  `venue` varchar(200) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `city` varchar(120) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Ghana',
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `capacity` int(11) NOT NULL DEFAULT 0,
  `dress_code` varchar(200) DEFAULT NULL,
  `contact_email` varchar(190) DEFAULT NULL,
  `contact_phone` varchar(30) DEFAULT NULL,
  `banner_image` varchar(500) DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `status` enum('draft','pending','published','cancelled','completed','rejected','suspended') NOT NULL DEFAULT 'draft',
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `visibility` enum('public','private') NOT NULL DEFAULT 'public',
  `approval_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `view_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_events_cat` (`category_id`),
  KEY `idx_events_status` (`status`),
  KEY `idx_events_category` (`category`),
  KEY `idx_events_org` (`organizer_id`),
  KEY `idx_events_dates` (`start_date`,`end_date`),
  KEY `idx_events_featured` (`is_featured`),
  CONSTRAINT `fk_events_cat` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_events_org` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (3,1,NULL,'Community Verification Event',NULL,NULL,'Music','Test Hall','1 Test St','Accra','Ghana',NULL,NULL,'2030-06-15','2030-06-15','20:00:00','23:00:00',100,NULL,NULL,NULL,NULL,NULL,NULL,'draft',0,'public','pending',NULL,0,'2026-08-13 12:58:40','2026-08-13 12:58:40'),(4,9,8,'Youth Retreats',NULL,'The youth retreat programme at Accra','Church Programs','The National Theatre','8FR9XC2Q+CF','Kan Royal Filling Station, Abuakwa','Ghana',NULL,NULL,'2026-08-18','2026-08-20','12:00:00','20:00:00',1000,'All White','asomanirawlingsjunior5333@gmail.com','0552945333','http://localhost:5000/uploads/359b013a85ed494576b06b3f88c3ef39.jpeg','[]','[]','published',0,'public','approved',NULL,0,'2026-08-16 11:50:54','2026-08-16 11:51:50');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `question` varchar(300) NOT NULL,
  `answer` text NOT NULL,
  `category` varchar(80) DEFAULT 'General',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `favorites` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `event_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fav` (`user_id`,`event_id`),
  KEY `fk_fav_event` (`event_id`),
  CONSTRAINT `fk_fav_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fav_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
INSERT INTO `favorites` VALUES (1,6,4,'2026-08-16 11:56:06');
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flash_sales`
--

DROP TABLE IF EXISTS `flash_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flash_sales` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `ticket_type_id` bigint(20) DEFAULT NULL,
  `organizer_id` bigint(20) NOT NULL,
  `discount_percent` decimal(5,2) NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_fs_event` (`event_id`),
  KEY `fs_org` (`organizer_id`),
  KEY `fs_tt` (`ticket_type_id`),
  CONSTRAINT `fk_fs_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fs_org` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fs_tt` FOREIGN KEY (`ticket_type_id`) REFERENCES `ticket_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sales`
--

LOCK TABLES `flash_sales` WRITE;
/*!40000 ALTER TABLE `flash_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `flash_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_campaigns`
--

DROP TABLE IF EXISTS `marketing_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_campaigns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `organizer_id` bigint(20) NOT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  `channel` enum('email','sms','push') NOT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text NOT NULL,
  `audience_size` int(11) DEFAULT 0,
  `status` enum('draft','sent','scheduled','failed') NOT NULL DEFAULT 'draft',
  `sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_mc_org` (`organizer_id`),
  KEY `fk_mc_event` (`event_id`),
  CONSTRAINT `fk_mc_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mc_org` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_campaigns`
--

LOCK TABLES `marketing_campaigns` WRITE;
/*!40000 ALTER TABLE `marketing_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_preferences`
--

DROP TABLE IF EXISTS `notification_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_preferences` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `email_tickets` tinyint(1) DEFAULT 1,
  `email_reminders` tinyint(1) DEFAULT 1,
  `email_offers` tinyint(1) DEFAULT 1,
  `sms_tickets` tinyint(1) DEFAULT 1,
  `sms_reminders` tinyint(1) DEFAULT 1,
  `push_enabled` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_np_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_preferences`
--

LOCK TABLES `notification_preferences` WRITE;
/*!40000 ALTER TABLE `notification_preferences` DISABLE KEYS */;
INSERT INTO `notification_preferences` VALUES (1,1,1,1,1,0,0,1);
/*!40000 ALTER TABLE `notification_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_templates`
--

DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_templates` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `type` enum('email','sms','push','in_app') NOT NULL DEFAULT 'email',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_templates`
--

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `message` text DEFAULT NULL,
  `type` enum('ticket','reminder','update','price_change','announcement','system','marketing','payment','refund','info','account','withdrawal','support') NOT NULL DEFAULT 'system',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `link` varchar(300) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notif_user` (`user_id`),
  KEY `idx_notif_read` (`is_read`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (2,9,'Organizer application update','Your organizer application was not approved. Reason: Incomplete documentation.','',0,NULL,'2026-08-04 17:00:56'),(3,9,'Organizer account approved','You can now create and publish events.','',0,NULL,'2026-08-04 17:45:46'),(4,9,'Organizer account approved','You can now create and publish events.','',0,NULL,'2026-08-13 04:11:07'),(7,9,'Organizer account approved','You can now create and publish events.','',0,NULL,'2026-08-13 04:19:36'),(8,9,'Organizer account approved','You can now create and publish events.','',0,NULL,'2026-08-13 04:19:59'),(13,9,'Organizer account approved','You can now create and publish events.','',0,NULL,'2026-08-13 04:26:04'),(14,9,'Organizer account approved','You can now create and publish events.','',0,NULL,'2026-08-13 04:38:02'),(16,6,'Account suspended','Your account has been suspended. Reason: Verification of suspend flow','account',0,NULL,'2026-08-13 12:21:54'),(17,6,'Account reinstated','Your account has been reinstated. You can now use the platform again.','account',0,NULL,'2026-08-13 12:21:55'),(18,9,'Password updated by administrator','Your password was reset by an administrator. Please log in using the new password.','account',0,NULL,'2026-08-16 11:32:24'),(19,9,'Event approved','Your event \"Youth Retreats\" has been approved and is now live.','',0,NULL,'2026-08-16 11:51:50'),(20,6,'Payment confirmed','Your payment for \"Youth Retreats\" was confirmed. Your tickets are ready.','payment',0,NULL,'2026-08-16 12:11:09'),(21,6,'Payment confirmed','Your payment for \"Youth Retreats\" was confirmed. Your tickets are ready.','payment',0,NULL,'2026-08-16 12:11:09');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) NOT NULL,
  `ticket_type_id` bigint(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_oi_tt` (`ticket_type_id`),
  KEY `idx_oi_order` (`order_id`),
  CONSTRAINT `fk_oi_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oi_tt` FOREIGN KEY (`ticket_type_id`) REFERENCES `ticket_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,1,1,2,200.00,400.00),(2,2,1,2,200.00,400.00);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `event_id` bigint(20) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `coupon_code` varchar(40) DEFAULT NULL,
  `payment_method` enum('mobile_money','visa','mastercard','paypal','apple_pay','google_pay','paystack') NOT NULL DEFAULT 'paystack',
  `payment_status` enum('pending','completed','failed','refunded','partially_refunded') NOT NULL DEFAULT 'pending',
  `payment_reference` varchar(100) DEFAULT NULL,
  `paystack_ref` varchar(100) DEFAULT NULL,
  `resale_listing_id` bigint(20) DEFAULT NULL,
  `order_status` enum('active','cancelled','refunded','completed') NOT NULL DEFAULT 'active',
  `cancel_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_orders_user` (`user_id`),
  KEY `idx_orders_event` (`event_id`),
  KEY `idx_orders_status` (`payment_status`),
  CONSTRAINT `fk_orders_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,6,4,400.00,0.00,NULL,'paystack','pending','TC-0A6CAC90',NULL,NULL,'active',NULL,'2026-08-16 11:53:46','2026-08-16 11:53:46'),(2,6,4,400.00,0.00,NULL,'paystack','completed','TC-621C5A5A',NULL,NULL,'active',NULL,'2026-08-16 12:10:39','2026-08-16 12:11:09');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizer_follows`
--

DROP TABLE IF EXISTS `organizer_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizer_follows` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `follower_id` bigint(20) NOT NULL,
  `organizer_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_follow` (`follower_id`,`organizer_id`),
  KEY `idx_of_organizer` (`organizer_id`),
  CONSTRAINT `fk_of_follower` FOREIGN KEY (`follower_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_of_organizer` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizer_follows`
--

LOCK TABLES `organizer_follows` WRITE;
/*!40000 ALTER TABLE `organizer_follows` DISABLE KEYS */;
INSERT INTO `organizer_follows` VALUES (3,6,9,'2026-08-16 11:53:18');
/*!40000 ALTER TABLE `organizer_follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizer_profiles`
--

DROP TABLE IF EXISTS `organizer_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organizer_profiles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `organization_name` varchar(180) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `website` varchar(300) DEFAULT NULL,
  `logo_url` varchar(500) DEFAULT NULL,
  `banner_url` varchar(500) DEFAULT NULL,
  `social_links` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`social_links`)),
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `approved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `bank_name` varchar(150) DEFAULT NULL,
  `account_number` varchar(100) DEFAULT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `mobile_money` varchar(100) DEFAULT NULL,
  `payout_method` varchar(50) DEFAULT 'bank',
  `primary_color` varchar(50) DEFAULT '#D4AF37',
  `tagline` varchar(255) DEFAULT NULL,
  `about` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_op_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizer_profiles`
--

LOCK TABLES `organizer_profiles` WRITE;
/*!40000 ALTER TABLE `organizer_profiles` DISABLE KEYS */;
INSERT INTO `organizer_profiles` VALUES (1,9,' Darlington Tech Solution',NULL,NULL,NULL,NULL,'{\"facebook\":\"\",\"twitter\":\"\",\"instagram\":\"\",\"linkedin\":\"\"}',1,'2026-08-13 04:38:02','2026-08-04 16:45:59','2026-08-13 04:38:02',NULL,NULL,NULL,NULL,'bank','#D4AF37',NULL,NULL);
/*!40000 ALTER TABLE `organizer_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token_hash`),
  KEY `fk_prt_user` (`user_id`),
  CONSTRAINT `fk_prt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES (2,6,'96d20aef9db2a3c73c09495ef12a264c6b4dab53a926daef8b668f5dc42c3906','2026-08-13 12:49:25',0,'2026-08-13 11:49:25');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  `organizer_id` bigint(20) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `commission` decimal(12,2) NOT NULL DEFAULT 0.00,
  `net_to_organizer` decimal(12,2) NOT NULL DEFAULT 0.00,
  `method` varchar(40) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `status` enum('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_pay_order` (`order_id`),
  KEY `fk_pay_user` (`user_id`),
  KEY `idx_pay_status` (`status`),
  KEY `idx_pay_event` (`event_id`),
  CONSTRAINT `fk_pay_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pay_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platform_commissions`
--

DROP TABLE IF EXISTS `platform_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_commissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `commission_pct` decimal(5,2) NOT NULL DEFAULT 5.00,
  `currency` varchar(10) DEFAULT 'GHS',
  `updated_by` bigint(20) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platform_commissions`
--

LOCK TABLES `platform_commissions` WRITE;
/*!40000 ALTER TABLE `platform_commissions` DISABLE KEYS */;
INSERT INTO `platform_commissions` VALUES (1,5.00,'GHS',NULL,'2026-08-04 16:13:39'),(2,5.00,'GHS',NULL,'2026-08-04 16:14:55'),(3,5.00,'GHS',NULL,'2026-08-04 16:16:51'),(4,5.00,'GHS',NULL,'2026-08-04 16:37:19'),(5,5.00,'GHS',NULL,'2026-08-04 16:59:06'),(6,5.00,'GHS',NULL,'2026-08-04 18:03:01'),(7,5.00,'GHS',NULL,'2026-08-05 02:14:46'),(8,5.00,'GHS',NULL,'2026-08-05 02:20:25');
/*!40000 ALTER TABLE `platform_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refunds`
--

DROP TABLE IF EXISTS `refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refunds` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','processed') NOT NULL DEFAULT 'pending',
  `processed_by` bigint(20) DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ref_order` (`order_id`),
  KEY `fk_ref_user` (`user_id`),
  CONSTRAINT `fk_ref_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ref_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refunds`
--

LOCK TABLES `refunds` WRITE;
/*!40000 ALTER TABLE `refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resale_listings`
--

DROP TABLE IF EXISTS `resale_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resale_listings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) NOT NULL,
  `seller_id` bigint(20) NOT NULL,
  `event_id` bigint(20) NOT NULL,
  `ticket_type_id` bigint(20) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `status` enum('active','sold','cancelled') NOT NULL DEFAULT 'active',
  `sold_to` bigint(20) DEFAULT NULL,
  `sold_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_resale_ticket` (`ticket_id`),
  KEY `fk_rl_seller` (`seller_id`),
  KEY `fk_rl_tt` (`ticket_type_id`),
  KEY `idx_rl_event` (`event_id`),
  KEY `idx_rl_status` (`status`),
  CONSTRAINT `fk_rl_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rl_seller` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rl_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rl_tt` FOREIGN KEY (`ticket_type_id`) REFERENCES `ticket_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resale_listings`
--

LOCK TABLES `resale_listings` WRITE;
/*!40000 ALTER TABLE `resale_listings` DISABLE KEYS */;
INSERT INTO `resale_listings` VALUES (1,1,6,4,1,250.00,'cancelled',NULL,NULL,'2026-08-16 12:23:30');
/*!40000 ALTER TABLE `resale_listings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `event_id` bigint(20) NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_rev_user` (`user_id`),
  KEY `idx_rev_event` (`event_id`),
  CONSTRAINT `fk_rev_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rev_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_rating` CHECK (`rating` between 1 and 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_replies`
--

DROP TABLE IF EXISTS `support_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_replies` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `is_staff` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_sr_ticket` (`ticket_id`),
  KEY `fk_sr_user` (`user_id`),
  CONSTRAINT `fk_sr_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sr_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_replies`
--

LOCK TABLES `support_replies` WRITE;
/*!40000 ALTER TABLE `support_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `category` varchar(80) DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `status` enum('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
  `assigned_to` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_st_user` (`user_id`),
  KEY `idx_st_status` (`status`),
  CONSTRAINT `fk_st_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `category` varchar(60) DEFAULT 'general',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'platform_name','Tribes & Cliqs','general','2026-08-04 16:13:39','2026-08-13 04:22:43',NULL),(2,'currency','GHS','general','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(3,'timezone','Africa/Accra','general','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(4,'maintenance_mode','true','general','2026-08-04 16:13:39','2026-08-13 07:00:44',NULL),(5,'commission_pct','5','payment','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(6,'paystack_public_key','pk_test_dd14984b41b85f106338ccae5cbed85bb97059e5','payment','2026-08-04 16:13:39','2026-08-16 12:10:14',NULL),(7,'paystack_secret_key','sk_test_99e893e5f02c7fb0ca56fb9c09d71e28d44a3b09','payment','2026-08-04 16:13:39','2026-08-16 12:10:14',NULL),(8,'smtp_host','','email','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(9,'smtp_port','587','email','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(10,'resend_api_key','','email','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(11,'sms_api_key','1106ef1c668c2471d659a2debfb40ea2915cc28dc42bdac882529c75766b42ce','sms','2026-08-04 16:13:39','2026-08-16 14:11:15',NULL),(12,'sms_sender_id','TribesCliqs','sms','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(13,'jwt_expires_in','168','security','2026-08-04 16:13:39','2026-08-13 04:22:43',NULL),(14,'max_login_attempts','5','security','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(15,'email_verification','false','security','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL),(16,'vat_percent','0','tax','2026-08-04 16:13:39','2026-08-04 16:13:39',NULL);
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_invites`
--

DROP TABLE IF EXISTS `team_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_invites` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `organizer_id` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'staff',
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ti_organizer` (`organizer_id`),
  CONSTRAINT `fk_ti_organizer` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_invites`
--

LOCK TABLES `team_invites` WRITE;
/*!40000 ALTER TABLE `team_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_members`
--

DROP TABLE IF EXISTS `team_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team_members` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `organizer_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `email` varchar(190) NOT NULL,
  `role` enum('staff','inspector','manager') NOT NULL DEFAULT 'staff',
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `status` enum('pending','active','revoked') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_tm_org` (`organizer_id`),
  KEY `fk_tm_user` (`user_id`),
  CONSTRAINT `fk_tm_org` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_members`
--

LOCK TABLES `team_members` WRITE;
/*!40000 ALTER TABLE `team_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_types`
--

DROP TABLE IF EXISTS `ticket_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `quantity_sold` int(11) NOT NULL DEFAULT 0,
  `sale_start` datetime DEFAULT NULL,
  `sale_end` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tt_event` (`event_id`),
  CONSTRAINT `fk_tt_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_types`
--

LOCK TABLES `ticket_types` WRITE;
/*!40000 ALTER TABLE `ticket_types` DISABLE KEYS */;
INSERT INTO `ticket_types` VALUES (1,4,'VVIP','VVIP for those highly people',200.00,100,4,'2026-08-16 00:00:00','2026-08-18 00:00:00',1,0,'2026-08-16 11:50:54','2026-08-16 12:10:39');
/*!40000 ALTER TABLE `ticket_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `event_id` bigint(20) NOT NULL,
  `ticket_type_id` bigint(20) NOT NULL,
  `ticket_number` varchar(60) NOT NULL,
  `qr_code` text DEFAULT NULL,
  `seat_number` varchar(50) DEFAULT NULL,
  `status` enum('active','used','cancelled','transferred') NOT NULL DEFAULT 'active',
  `transferred_to` bigint(20) DEFAULT NULL,
  `checked_in_at` datetime DEFAULT NULL,
  `checked_in_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_number` (`ticket_number`),
  KEY `fk_t_oi` (`order_item_id`),
  KEY `fk_t_tt` (`ticket_type_id`),
  KEY `idx_t_user` (`user_id`),
  KEY `idx_t_event` (`event_id`),
  KEY `idx_t_number` (`ticket_number`),
  CONSTRAINT `fk_t_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_t_oi` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_t_tt` FOREIGN KEY (`ticket_type_id`) REFERENCES `ticket_types` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_t_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,2,6,4,1,'TC-EC5643CE','TC-EC5643CE',NULL,'active',NULL,NULL,NULL,'2026-08-16 12:11:09'),(2,2,6,4,1,'TC-DBBA9BEC','TC-DBBA9BEC',NULL,'active',NULL,NULL,NULL,'2026-08-16 12:11:09');
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_payment_methods`
--

DROP TABLE IF EXISTS `user_payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_payment_methods` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `type` enum('mobile_money','card') NOT NULL,
  `provider` varchar(60) DEFAULT NULL,
  `last4` varchar(4) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_upm_user` (`user_id`),
  CONSTRAINT `fk_upm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_payment_methods`
--

LOCK TABLES `user_payment_methods` WRITE;
/*!40000 ALTER TABLE `user_payment_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_sessions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `device` varchar(200) DEFAULT NULL,
  `last_active` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_us_user` (`user_id`),
  CONSTRAINT `fk_us_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('attendee','organizer','admin') NOT NULL DEFAULT 'attendee',
  `phone` varchar(25) DEFAULT NULL,
  `avatar` varchar(500) DEFAULT NULL,
  `avatar_url` varchar(500) DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'active',
  `suspend_reason` varchar(500) DEFAULT NULL,
  `suspended_at` datetime DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'System Administrator','admin@tribesandcliqs.com','$2a$10$Vo3BXokgCtBVMjK5ebPi9eQBK2j6xVWNMPRwFP5ZmtaP6Cjd44DaC','admin',NULL,NULL,NULL,'Accra, Ghana','Platform admin',NULL,'active',NULL,NULL,1,1,'2026-08-16 12:09:20','2026-08-04 16:13:39','2026-08-16 12:09:20'),(6,'Asomani Rawlings Junior','asomanirawlingsjunior5333@gmail.com','$2a$10$RLO6w3dK7InPUkOCosTpiO5XAWg.Y.NBiWh0943yn9YZINBa4O3mi','attendee','+233257501827',NULL,NULL,NULL,NULL,NULL,'active',NULL,NULL,1,0,'2026-08-16 11:54:13','2026-08-04 16:18:28','2026-08-16 11:54:13'),(9,'Kwame Darlington Junior','asomanirawlingsjunior71@gmail.com','$2a$10$gTUsiNUFpIVNipXE4fqJ0uGUUKBlTbWef/MHRIJeBvbk6PEnALBKm','organizer','+233257501827',NULL,NULL,NULL,NULL,NULL,'active',NULL,NULL,1,0,'2026-08-16 14:39:49','2026-08-04 16:45:59','2026-08-16 14:39:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet_transactions`
--

DROP TABLE IF EXISTS `wallet_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wallet_transactions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `organizer_id` bigint(20) NOT NULL,
  `type` enum('credit','debit','withdrawal','commission') NOT NULL,
  `description` varchar(300) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `balance_after` decimal(12,2) DEFAULT NULL,
  `reference` varchar(80) DEFAULT NULL,
  `status` enum('pending','completed','failed') NOT NULL DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_wt_org` (`organizer_id`),
  CONSTRAINT `fk_wt_org` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_transactions`
--

LOCK TABLES `wallet_transactions` WRITE;
/*!40000 ALTER TABLE `wallet_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wallet_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdrawals`
--

DROP TABLE IF EXISTS `withdrawals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `withdrawals` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `organizer_id` bigint(20) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` enum('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
  `bank_name` varchar(120) DEFAULT NULL,
  `account_number` varchar(40) DEFAULT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `reference` varchar(80) DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_wd_org` (`organizer_id`),
  KEY `idx_wd_status` (`status`),
  CONSTRAINT `fk_wd_org` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdrawals`
--

LOCK TABLES `withdrawals` WRITE;
/*!40000 ALTER TABLE `withdrawals` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdrawals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tribes_cliqs'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-16 15:33:53
