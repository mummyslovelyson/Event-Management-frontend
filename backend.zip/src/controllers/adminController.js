import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import pool from '../config/db.js';
import { sendNotification, sendNotificationToMany } from '../utils/notify.js';
import {
  sendEmail, sendOrganizerApprovalEmail, sendEventApprovalEmail, sendEventRejectionEmail,
} from '../utils/email.js';
import { sendSMS } from '../utils/sms.js';
import { getSmsApiKey, getPaystackSecretKey, clearSettingsCache } from '../utils/settings.js';
import { logAudit } from '../utils/audit.js';
import { validatePassword } from '../utils/password.js';
import { refundTransaction } from '../utils/paystack.js';
import { REFUND_POLICY_CIRCUMSTANCES, getPolicyClause, formatPolicyCitation } from '../constants/refundPolicy.js';
import {
  voiceModel,
  DEFAULT_PHONETIC_LEXICON,
  DEFAULT_TRAINING_SAMPLES,
  correctVoicePhonetics,
  formatVoiceUtterance,
  analyzeVoiceEmotion,
} from '../utils/voiceMLEngine.js';

/* ------------------------------------------------------------------ */
/* Dashboard stats                                                     */
/* ------------------------------------------------------------------ */
const fillDailySeries = (rows, days, { revenue = false, attendees = false, organizers = false, orders = false }) => {
  const byDate = new Map(rows.map((r) => [String(r.date), r]));
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const row = byDate.get(key) || {};
    out.push({
      date: key,
      ...(revenue && { revenue: Number(row.revenue) || 0 }),
      ...(orders && { orders: Number(row.orders) || 0 }),
      ...(attendees && { attendees: Number(row.attendees) || 0 }),
      ...(organizers && { organizers: Number(row.organizers) || 0 }),
    });
  }
  return out;
};

const sumRange = (series, startIdx, endIdx) =>
  series.slice(startIdx, endIdx).reduce((acc, s) => acc + (Number(s.revenue) || 0), 0);

export const getDashboardStats = async (_req, res) => {
  try {
    const [[usersRow]] = await pool.execute(`SELECT COUNT(*) AS total FROM users`);
    const [[organizersRow]] = await pool.execute(`SELECT COUNT(*) AS total FROM users WHERE role = 'organizer'`);
    const [[eventsRow]] = await pool.execute(`SELECT COUNT(*) AS total FROM events`);
    const [[ordersRow]] = await pool.execute(
      `SELECT COUNT(*) AS total, COALESCE(SUM(total_amount),0) AS revenue FROM orders WHERE payment_status = 'completed'`,
    );
    const [[ticketsRow]] = await pool.execute(`SELECT COUNT(*) AS total FROM tickets`);
    const [[ticketsTodayRow]] = await pool.execute(
      `SELECT COUNT(*) AS total FROM tickets WHERE DATE(created_at) = CURRENT_DATE`,
    );
    const [[pendingOrgsRow]] = await pool.execute(
      `SELECT COUNT(*) AS total FROM users WHERE role = 'organizer' AND is_approved = FALSE AND status = 'pending'`,
    );
    const [[pendingWithdrawalsRow]] = await pool.execute(`SELECT COUNT(*) AS total FROM withdrawals WHERE status = 'pending'`);
    const [[pendingEventsRow]] = await pool.execute(`SELECT COUNT(*) AS total FROM events WHERE status = 'pending'`);

    // Last 30 days of completed orders (revenue + volume).
    const [dailyRevenue] = await pool.execute(
      `SELECT DATE(created_at) AS date, COALESCE(SUM(total_amount),0) AS revenue, COUNT(*) AS orders
       FROM orders WHERE payment_status = 'completed'
         AND created_at >= CURRENT_DATE - INTERVAL '29 days'
       GROUP BY DATE(created_at) ORDER BY date ASC`,
    );
    const revenueSeries = fillDailySeries(dailyRevenue, 30, { revenue: true, orders: true });

    // Last 14 days of new signups, split by role.
    const [dailySignups] = await pool.execute(
      `SELECT DATE(created_at) AS date,
              SUM(CASE WHEN role = 'attendee' THEN 1 ELSE 0 END) AS attendees,
              SUM(CASE WHEN role = 'organizer' THEN 1 ELSE 0 END) AS organizers
       FROM users WHERE created_at >= CURRENT_DATE - INTERVAL '13 days'
       GROUP BY DATE(created_at) ORDER BY date ASC`,
    );
    const growthSeries = fillDailySeries(dailySignups, 14, { attendees: true, organizers: true });

    const last7 = sumRange(revenueSeries, revenueSeries.length - 7, revenueSeries.length);
    const prev7 = sumRange(revenueSeries, revenueSeries.length - 14, revenueSeries.length - 7);
    const revenueTrend = prev7 > 0 ? ((last7 - prev7) / prev7) * 100 : null;

    const [pendingEvents] = await pool.execute(
      `SELECT e.id, e.title, e.category, e.start_date, e.banner_image AS thumbnail, e.created_at,
              u.name AS organizer_name
       FROM events e JOIN users u ON u.id = e.organizer_id
       WHERE e.status = 'pending'
       ORDER BY e.created_at DESC LIMIT 8`,
    );

    const [recentEvents] = await pool.execute(
      `SELECT e.id, e.title, e.category, e.status, e.start_date, e.created_at,
              u.name AS organizer_name
       FROM events e JOIN users u ON u.id = e.organizer_id
       ORDER BY e.created_at DESC LIMIT 6`,
    );

    const [recentUsers] = await pool.execute(
      `SELECT id, name, email, role, status, created_at FROM users ORDER BY created_at DESC LIMIT 6`,
    );

    const activity = [
      ...recentUsers.map((u) => ({
        type: 'user',
        label: `${u.name} joined as ${u.role}`,
        role: u.role,
        time: u.created_at,
      })),
      ...recentEvents.map((e) => ({
        type: 'event',
        label: `${e.title}`,
        organizer: e.organizer_name,
        time: e.created_at,
      })),
    ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 10);

    res.json({
      overview: {
        totalUsers: usersRow.total,
        totalOrganizers: organizersRow.total,
        totalEvents: eventsRow.total,
        totalOrders: ordersRow.total,
        totalRevenue: Number(ordersRow.revenue),
        ticketsSold: ticketsRow.total,
        ticketsSoldToday: ticketsTodayRow.total,
        pendingOrganizers: pendingOrgsRow.total,
        pendingWithdrawals: pendingWithdrawalsRow.total,
        pendingEvents: pendingEventsRow.total,
        revenueTrend,
        last7Revenue: last7,
      },
      revenueSeries,
      growthSeries,
      pendingEvents,
      recentEvents,
      recentUsers,
      activity,
    });
  } catch (err) {
    console.error('[adminController.getDashboardStats]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* Users                                                               */
/* ------------------------------------------------------------------ */
const userSortClause = (sort) => {
  if (sort === 'oldest') return 'ORDER BY u.created_at ASC';
  if (sort === 'name') return 'ORDER BY u.name ASC';
  return 'ORDER BY u.created_at DESC';
};

export const getUsers = async (req, res) => {
  try {
    const { role, status, search, sort, page = 1, limit = 20 } = req.query;
    const conditions = [];
    const params = [];

    if (role && role !== 'all') {
      conditions.push('u.role = ?');
      params.push(role);
    }

    if (status && status !== 'all') {
      if (status === 'pending') {
        conditions.push("u.role = ? AND (u.is_approved = FALSE OR u.is_approved IS NULL) AND u.status != 'rejected' AND u.status != 'suspended' AND u.status != 'active'");
        params.push('organizer');
      } else if (status === 'active') {
        conditions.push('u.status = ?');
        params.push('active');
      } else if (status === 'approved') {
        conditions.push("u.role = ? AND (u.is_approved = TRUE OR u.status = 'active')");
        params.push('organizer');
      } else if (status === 'suspended' || status === 'rejected') {
        conditions.push('u.status = ?');
        params.push(status);
      }
    }

    if (search) {
      conditions.push('(u.name ILIKE ? OR u.email ILIKE ? OR op.organization_name ILIKE ?)');
      const q = `%${search}%`;
      params.push(q, q, q);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
    const offset = (pageNum - 1) * limitNum;

    const [countRows] = await pool.execute(
      `SELECT COUNT(*) AS total FROM users u LEFT JOIN organizer_profiles op ON op.user_id = u.id ${where}`,
      params,
    );
    const totalCount = Number(countRows[0]?.total || 0);

    const [rows] = await pool.execute(
      `SELECT u.id, u.name, u.email, u.role, u.phone, u.status, u.is_approved, u.email_verified,
              u.suspend_reason, u.suspended_at, u.location, u.bio,
              COALESCE(u.avatar_url, u.avatar) AS avatar, u.created_at,
              (SELECT COUNT(*) FROM events e WHERE e.organizer_id = u.id) AS events_count,
              (SELECT COUNT(*) FROM tickets t WHERE t.user_id = u.id) AS tickets_count,
              op.organization_name, op.description AS org_description, op.website, op.logo_url, op.is_verified AS org_is_verified,
              op.category AS org_category, op.city AS org_city
       FROM users u
       LEFT JOIN organizer_profiles op ON op.user_id = u.id
       ${where}
       ${userSortClause(sort)}
       LIMIT ${limitNum} OFFSET ${offset}`,
      params,
    );

    const formattedUsers = rows.map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      phone: u.phone,
      status: u.status,
      is_approved: u.is_approved,
      email_verified: u.email_verified,
      avatar: u.avatar,
      createdAt: u.created_at,
      location: u.org_city || u.location || null,
      city: u.org_city || u.location || null,
      category: u.org_category || null,
      bio: u.org_description || u.bio || null,
      eventsCount: Number(u.events_count) || 0,
      ticketsCount: Number(u.tickets_count) || 0,
      isSuspended: u.status === 'suspended',
      suspendReason: u.suspend_reason || null,
      suspendedAt: u.suspended_at || null,
      organizationName: u.organization_name || u.name,
      organization: {
        name: u.organization_name || u.name,
        category: u.org_category || null,
        city: u.org_city || u.location || null,
        description: u.org_description || u.bio || null,
        website: u.website || null,
        logoUrl: u.logo_url || null,
        isVerified: !!u.org_is_verified,
      },
    }));

    res.json({
      users: formattedUsers,
      pagination: { page: pageNum, limit: limitNum, total: totalCount, totalPages: Math.ceil(totalCount / limitNum) || 1 },
    });
  } catch (err) {
    console.error('[adminController.getUsers]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const getUser = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      `SELECT u.*, op.organization_name, op.description AS org_description, op.website, op.category AS org_category, op.city AS org_city, op.country AS org_country, op.logo_url, op.banner_url, op.social_links, op.is_verified AS org_is_verified,
              (SELECT COUNT(*) FROM events e WHERE e.organizer_id = u.id) AS events_count,
              (SELECT COUNT(*) FROM tickets t WHERE t.user_id = u.id) AS tickets_count
       FROM users u
       LEFT JOIN organizer_profiles op ON op.user_id = u.id
       WHERE u.id = ?`,
      [id],
    );
    const user = rows[0];
    if (!user) return res.status(404).json({ message: 'User not found' });
    const { password, reset_token, reset_expires, ...safe } = user;
    res.json({
      user: {
        ...safe,
        passwordHash: password || null,
        createdAt: safe.created_at,
        updatedAt: safe.updated_at,
        lastLoginAt: safe.last_login_at,
        emailVerified: safe.email_verified === 1 || safe.email_verified === true,
        isApproved: safe.is_approved === 1 || safe.is_approved === true,
        eventsCount: Number(safe.events_count) || 0,
        ticketsCount: Number(safe.tickets_count) || 0,
        isSuspended: safe.status === 'suspended',
        suspendReason: safe.suspend_reason || null,
        suspendedAt: safe.suspended_at || null,
        organizationName: safe.organization_name || safe.name,
        category: safe.org_category || null,
        city: safe.org_city || safe.location || null,
        organization: {
          name: safe.organization_name || safe.name,
          category: safe.org_category || null,
          city: safe.org_city || safe.location || null,
          description: safe.org_description || safe.bio || null,
          website: safe.website || null,
          logoUrl: safe.logo_url || null,
          bannerUrl: safe.banner_url || null,
          socialLinks: safe.social_links || null,
          isVerified: !!safe.org_is_verified,
        },
      },
    });
  } catch (err) {
    console.error('[adminController.getUser]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const rejectOrganizer = async (req, res) => {
  try {
    const { id } = req.params;
    const { rejectionReason, reason } = req.body || {};
    const rReason = (rejectionReason || reason || 'Application did not meet verification criteria').toString().trim().slice(0, 500);

    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    const user = rows[0];
    if (!user) return res.status(404).json({ message: 'Organizer not found' });
    if (user.role !== 'organizer') return res.status(400).json({ message: 'Only organizer accounts can be rejected' });

    await pool.execute(`UPDATE users SET is_approved = FALSE, status = 'rejected', suspend_reason = ? WHERE id = ?`, [rReason, id]);
    await pool.execute(`UPDATE organizer_profiles SET is_verified = FALSE WHERE user_id = ?`, [id]);

    await sendNotification({
      userId: Number(id),
      title: 'Organizer Application Update',
      message: `Your organizer application was not approved. Reason: ${rReason}`,
      type: 'account',
    });

    if (user.phone) {
      try {
        sendSMS(
          user.phone,
          `Tribes & Cliqs: Your organizer application was not approved. Reason: ${rReason}`
        ).catch((err) => console.warn('[adminController.rejectOrganizer] SMS send error:', err.message));
      } catch {
        /* ignore */
      }
    }

    if (user.email) {
      try {
        sendEmail({
          to: user.email,
          subject: 'Tribes & Cliqs Organizer Application Update',
          html: `<div style="font-family:sans-serif;color:#1C232B;padding:24px;">
            <h2>Organizer Application Update</h2>
            <p>Dear ${user.name},</p>
            <p>Thank you for your interest in becoming an organizer on Tribes &amp; Cliqs.</p>
            <p>After reviewing your submission, our team was unable to approve your application at this time.</p>
            <div style="background:#f4f4f5;border-left:4px solid #ef4444;padding:12px;margin:16px 0;">
              <strong>Feedback:</strong> ${rReason}
            </div>
            <p>You can update your organizer profile details and re-apply from your dashboard or profile settings.</p>
            <p>Best regards,<br/>The Tribes &amp; Cliqs Team</p>
          </div>`,
        }).catch((err) => console.warn('[adminController.rejectOrganizer] Email send error:', err.message));
      } catch {
        /* ignore */
      }
    }

    await logAudit({ userId: req.user.id, action: 'reject_organizer', entityType: 'user', entityId: Number(id), details: { reason: rReason } });
    res.json({ message: 'Organizer application rejected', status: 'rejected' });
  } catch (err) {
    console.error('[adminController.rejectOrganizer]', err);
    res.status(500).json({ message: 'Server error rejecting organizer' });
  }
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const updateUser = async (req, res) => {
  try {
    const { id } = req.params;

    // Approve / reject shortcuts used by moderation flows.
    if (req.body.isRejected || req.body.status === 'rejected') {
      return rejectOrganizer(req, res);
    }
    if (req.body.is_approved === 1 || req.body.isApproved === true) {
      return approveOrganizer(req, res);
    }

    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    const target = rows[0];
    if (!target) return res.status(404).json({ message: 'User not found' });

    const allowed = ['name', 'email', 'role', 'phone', 'status', 'is_approved', 'bio', 'location'];
    const fields = [];
    const values = [];
    const changed = {};

    const isMasterAdmin = req.user.role === 'system_admin' || req.user.role === 'superadmin';
    const isTargetAdmin = target.role === 'admin' || target.role === 'system_admin' || target.role === 'superadmin';

    // System Admin accounts cannot be modified by others
    if ((target.role === 'system_admin' || target.role === 'superadmin') && target.id !== req.user.id) {
      return res.status(400).json({ message: 'System Admin accounts cannot be modified' });
    }

    // Only System Admins can modify Admin accounts
    if (isTargetAdmin && !isMasterAdmin) {
      return res.status(400).json({ message: 'Admin accounts cannot be modified' });
    }

    for (const key of allowed) {
      if (req.body[key] === undefined) continue;
      let value = req.body[key];
      if (key === 'role') {
        const allowedRoles = isMasterAdmin ? ['attendee', 'organizer', 'admin'] : ['attendee', 'organizer'];
        if (!allowedRoles.includes(value)) {
          return res.status(400).json({ message: isMasterAdmin ? 'Role must be attendee, organizer, or admin' : 'Role must be attendee or organizer' });
        }
      }
      if (key === 'email' && typeof value === 'string' && !EMAIL_RE.test(value.trim())) {
        return res.status(400).json({ message: 'Invalid email address' });
      }
      if (key === 'email') value = value.trim();
      fields.push(`${key} = ?`);
      values.push(value);
      changed[key] = value;
    }

    const orgName = req.body.organization_name ?? req.body.organizationName;
    const orgCategory = req.body.category ?? req.body.org_category;
    const orgCity = req.body.city ?? req.body.org_city;
    const orgWebsite = req.body.website ?? req.body.org_website;
    const orgDesc = req.body.description ?? req.body.org_description;
    const hasOrgUpdates = [orgName, orgCategory, orgCity, orgWebsite, orgDesc].some((v) => v !== undefined);

    if (!fields.length && !hasOrgUpdates) {
      return res.status(400).json({ message: 'No fields to update' });
    }

    if (fields.length) {
      values.push(id);
      await pool.execute(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`, values);
    }

    // Promoting someone to organizer or updating organizer details
    const isOrganizer = (changed.role || target.role) === 'organizer';
    if (isOrganizer) {
      const [existing] = await pool.execute('SELECT id FROM organizer_profiles WHERE user_id = ?', [id]);
      if (!existing.length) {
        await pool.execute(
          'INSERT INTO organizer_profiles (user_id, organization_name, category, city, website, description) VALUES (?, ?, ?, ?, ?, ?)',
          [Number(id), orgName || changed.name || target.name, orgCategory || null, orgCity || null, orgWebsite || null, orgDesc || null],
        );
      } else if (hasOrgUpdates) {
        const orgFields = [];
        const orgVals = [];
        if (orgName !== undefined) { orgFields.push('organization_name = ?'); orgVals.push(orgName); changed.organization_name = orgName; }
        if (orgCategory !== undefined) { orgFields.push('category = ?'); orgVals.push(orgCategory); changed.category = orgCategory; }
        if (orgCity !== undefined) { orgFields.push('city = ?'); orgVals.push(orgCity); changed.city = orgCity; }
        if (orgWebsite !== undefined) { orgFields.push('website = ?'); orgVals.push(orgWebsite); changed.website = orgWebsite; }
        if (orgDesc !== undefined) { orgFields.push('description = ?'); orgVals.push(orgDesc); changed.description = orgDesc; }
        if (orgFields.length) {
          orgVals.push(id);
          await pool.execute(`UPDATE organizer_profiles SET ${orgFields.join(', ')} WHERE user_id = ?`, orgVals);
        }
      }
    }

    await logAudit({
      userId: req.user.id,
      action: 'admin_update_user',
      entityType: 'user',
      entityId: Number(id),
      details: { changed },
    });
    res.json({ message: 'User updated' });
  } catch (err) {
    console.error('[adminController.updateUser]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const suspendUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body || {};
    const suspendReason = (reason || 'Violation of platform policy').toString().trim().slice(0, 500);

    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    const user = rows[0];
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (user.role === 'system_admin' || user.role === 'superadmin') {
      return res.status(400).json({ message: 'System Admin accounts cannot be suspended' });
    }
    const isMasterAdmin = req.user.role === 'system_admin' || req.user.role === 'superadmin';
    if (user.role === 'admin' && !isMasterAdmin) {
      return res.status(400).json({ message: 'Admin accounts cannot be suspended' });
    }
    if (user.status === 'suspended') return res.status(400).json({ message: 'User is already suspended' });

    await pool.execute(
      `UPDATE users SET status = 'suspended', suspend_reason = ?, suspended_at = NOW() WHERE id = ?`,
      [suspendReason, id],
    );
    if (user.role === 'organizer') {
      await pool.execute('UPDATE organizer_profiles SET is_verified = FALSE WHERE user_id = ?', [id]);
    }
    await sendNotification({
      userId: Number(id),
      title: 'Account suspended',
      message: `Your account has been suspended. Reason: ${suspendReason}`,
      type: 'account',
    });
    await logAudit({ userId: req.user.id, action: 'suspend_user', entityType: 'user', entityId: Number(id), details: { reason: suspendReason } });
    res.json({ message: 'User suspended' });
  } catch (err) {
    console.error('[adminController.suspendUser]', err);
    res.status(500).json({ message: 'Server error' });
  }
};


/* ------------------------------------------------------------------ */
/* Approve organizer                                                   */
/* ------------------------------------------------------------------ */
export const approveOrganizer = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    const user = rows[0];
    if (!user) return res.status(404).json({ message: 'Organizer not found' });
    if (user.role !== 'organizer') return res.status(400).json({ message: 'Only organizer accounts can be approved' });

    await pool.execute(`UPDATE users SET is_approved = TRUE, status = 'active' WHERE id = ?`, [id]);
    await pool.execute(`UPDATE organizer_profiles SET is_verified = TRUE, approved_at = NOW() WHERE user_id = ?`, [id]);

    // Send Approval Email
    try {
      sendOrganizerApprovalEmail(user.email, user.name);
    } catch (e) {
      console.warn('[adminController.approveOrganizer] Email send skipped:', e.message);
    }

    // Send Approval SMS
    if (user.phone) {
      try {
        sendSMS(
          user.phone,
          `Tribes & Cliqs: Congratulations ${user.name}! Your organizer account has been approved by the Admin. You can now log in and manage your events & ticket sales.`
        ).catch((err) => console.warn('[adminController.approveOrganizer] SMS send error:', err.message));
      } catch {
        /* ignore */
      }
    }

    await sendNotification({
      userId: Number(id),
      title: 'Organizer Account Approved!',
      message: 'Congratulations! Your organizer account has been approved by the Admin. You now have full access to create events, sell tickets, and manage your dashboard.',
      type: 'account',
    });

    await logAudit({ userId: req.user.id, action: 'approve_organizer', entityType: 'user', entityId: Number(id) });
    res.json({ message: 'Organizer approved successfully' });
  } catch (err) {
    console.error('[adminController.approveOrganizer]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* Events (admin)                                                      */
/* ------------------------------------------------------------------ */
export const getEvents = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const conditions = [];
    const params = [];
    if (status === 'changes_requested') {
      conditions.push('e.approval_status = ?');
      params.push('changes_requested');
    } else if (status && status !== 'all') {
      conditions.push('e.status = ?');
      params.push(status);
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
    const offset = (pageNum - 1) * limitNum;

    const [countRows] = await pool.execute(`SELECT COUNT(*) AS total FROM events e ${where}`, params);
    const [rows] = await pool.execute(
      `SELECT e.*, u.name AS organizer_name
       FROM events e JOIN users u ON u.id = e.organizer_id
       ${where}
       ORDER BY e.created_at DESC
       LIMIT ${limitNum} OFFSET ${offset}`,
      params,
    );

    res.json({
      events: rows,
      pagination: { page: pageNum, limit: limitNum, total: countRows[0].total, totalPages: Math.ceil(countRows[0].total / limitNum) },
    });
  } catch (err) {
    console.error('[adminController.getEvents]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const approveEvent = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute(
      `UPDATE events SET status = 'published', approval_status = 'approved', rejection_reason = NULL WHERE id = ?`,
      [id],
    );
    const [rows] = await pool.execute(
      `SELECT e.organizer_id, e.title, u.email
       FROM events e JOIN users u ON u.id = e.organizer_id
       WHERE e.id = ?`,
      [id],
    );
    if (rows[0]) {
      sendNotification({
        userId: rows[0].organizer_id,
        title: 'Event approved',
        message: `Your event "${rows[0].title}" has been approved and is now live.`,
        type: 'event',
      });
      if (rows[0].email) {
        sendEventApprovalEmail(rows[0].email, { id, title: rows[0].title }).catch(() => {});
      }
    }
    await logAudit({ userId: req.user.id, action: 'approve_event', entityType: 'event', entityId: Number(id) });
    res.json({ message: 'Event approved and published' });
  } catch (err) {
    console.error('[adminController.approveEvent]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const requestEventChanges = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason, notes, feedback } = req.body;
    const feedbackText = String(reason || notes || feedback || 'Please review and adjust event details').trim();

    await pool.execute(
      `UPDATE events SET status = 'draft', approval_status = 'changes_requested', rejection_reason = ? WHERE id = ?`,
      [feedbackText, id],
    );

    const [rows] = await pool.execute(
      `SELECT e.organizer_id, e.title, u.email, u.phone
       FROM events e JOIN users u ON u.id = e.organizer_id
       WHERE e.id = ?`,
      [id],
    );

    if (rows[0]) {
      sendNotification({
        userId: rows[0].organizer_id,
        title: 'Changes requested for your event',
        message: `Admin requested changes for "${rows[0].title}": ${feedbackText}`,
        type: 'event',
      });
      if (rows[0].email) {
        sendEmail(
          rows[0].email,
          `Changes requested: ${rows[0].title} — Tribes & Cliqs`,
          `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #111417;">Event Review Feedback</h2>
            <p>Hello,</p>
            <p>Our review team reviewed your event submission for <strong>${rows[0].title}</strong> and has requested a few adjustments before it can be published:</p>
            <div style="background: #FFFBEB; border-left: 4px solid #F59E0B; padding: 14px 18px; margin: 20px 0; border-radius: 4px;">
              <strong style="color: #92400E; display: block; margin-bottom: 6px;">Admin Feedback:</strong>
              <p style="color: #78350F; margin: 0;">${feedbackText}</p>
            </div>
            <p>Please log in to your organizer dashboard to make the requested edits and resubmit for review.</p>
            <p style="margin-top: 24px; color: #6B7278; font-size: 13px;">Tribes & Cliqs Event Operations Team</p>
          </div>`
        ).catch(() => {});
      }
      if (rows[0].phone) {
        sendSMS(
          rows[0].phone,
          `Tribes & Cliqs: Admin requested changes on "${rows[0].title}". Feedback: ${feedbackText.slice(0, 80)}. Check dashboard to edit and resubmit.`
        ).catch(() => {});
      }
    }

    await logAudit({
      userId: req.user.id,
      action: 'request_event_changes',
      entityType: 'event',
      entityId: Number(id),
      details: { reason: feedbackText }
    });

    res.json({ message: 'Changes requested from organizer', feedback: feedbackText });
  } catch (err) {
    console.error('[adminController.requestEventChanges]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* Suspend / restore an event                                          */
/* Suspending takes a live (published) event offline: it disappears
 * from public listings and can no longer be booked, without deleting it.
 * Restoring puts it back to published.                              */
/* ------------------------------------------------------------------ */
export const suspendEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT organizer_id, title, status FROM events WHERE id = ?', [id]);
    const event = rows[0];
    if (!event) return res.status(404).json({ message: 'Event not found' });

    if (event.status !== 'published') {
      return res.status(400).json({ message: 'Only published events can be suspended' });
    }

    await pool.execute(`UPDATE events SET status = 'suspended' WHERE id = ?`, [id]);
    sendNotification({
      userId: event.organizer_id,
      title: 'Event suspended',
      message: `Your event "${event.title}" has been suspended and is no longer visible or bookable. Contact support for details.`,
      type: 'event',
    });
    await logAudit({
      userId: req.user.id,
      action: 'suspend_event',
      entityType: 'event',
      entityId: Number(id),
      details: { title: event.title },
    });

    res.json({ message: 'Event suspended' });
  } catch (err) {
    console.error('[adminController.suspendEvent]', err);
    res.status(500).json({ message: 'Server error suspending event' });
  }
};

export const unsuspendEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT organizer_id, title, status FROM events WHERE id = ?', [id]);
    const event = rows[0];
    if (!event) return res.status(404).json({ message: 'Event not found' });

    if (event.status !== 'suspended') {
      return res.status(400).json({ message: 'Only suspended events can be restored' });
    }

    await pool.execute(`UPDATE events SET status = 'published' WHERE id = ?`, [id]);
    sendNotification({
      userId: event.organizer_id,
      title: 'Event restored',
      message: `Your event "${event.title}" has been restored and is live again.`,
      type: 'event',
    });
    await logAudit({
      userId: req.user.id,
      action: 'unsuspend_event',
      entityType: 'event',
      entityId: Number(id),
      details: { title: event.title },
    });

    res.json({ message: 'Event restored' });
  } catch (err) {
    console.error('[adminController.unsuspendEvent]', err);
    res.status(500).json({ message: 'Server error restoring event' });
  }
};

/* ------------------------------------------------------------------ */
/* Feature / unfeature an event (homepage spotlight)                   */
/* ------------------------------------------------------------------ */
export const featureEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const featured = req.body.featured === true || req.body.featured === 1 || req.body.featured === '1';
    const [rows] = await pool.execute('SELECT id, title, status FROM events WHERE id = ?', [id]);
    const event = rows[0];
    if (!event) return res.status(404).json({ message: 'Event not found' });

    await pool.execute('UPDATE events SET is_featured = ? WHERE id = ?', [featured === true, id]);
    await logAudit({
      userId: req.user.id,
      action: featured ? 'feature_event' : 'unfeature_event',
      entityType: 'event',
      entityId: Number(id),
      details: { title: event.title, status: event.status, is_featured: featured },
    });

    res.json({ message: featured ? 'Event featured' : 'Event unfeatured', is_featured: featured });
  } catch (err) {
    console.error('[adminController.featureEvent]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const rejectEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body || {};
    const reasonText = String(reason || 'Violates platform guidelines').trim();
    await pool.execute(
      `UPDATE events SET status = 'rejected', approval_status = 'rejected', rejection_reason = ? WHERE id = ?`,
      [reasonText, id],
    );
    const [rows] = await pool.execute(
      `SELECT e.organizer_id, e.title, u.email
       FROM events e JOIN users u ON u.id = e.organizer_id
       WHERE e.id = ?`,
      [id],
    );
    if (rows[0]) {
      sendNotification({
        userId: rows[0].organizer_id,
        title: 'Event rejected',
        message: `Your event "${rows[0].title}" was rejected. Reason: ${reason || 'not specified'}`,
        type: 'event',
      });
      if (rows[0].email) {
        sendEventRejectionEmail(rows[0].email, { id, title: rows[0].title }, reason).catch(() => {});
      }
    }
    await logAudit({ userId: req.user.id, action: 'reject_event', entityType: 'event', entityId: Number(id), details: { reason } });
    res.json({ message: 'Event rejected' });
  } catch (err) {
    console.error('[adminController.rejectEvent]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* Categories                                                           */
/* ------------------------------------------------------------------ */
export const getCategories = async (_req, res) => {
  try {
    const [rows] = await pool.execute(`SELECT * FROM categories ORDER BY name ASC`);
    res.json({ categories: rows });
  } catch (err) {
    console.error('[adminController.getCategories]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const createCategory = async (req, res) => {
  try {
    const { name, slug, icon } = req.body;
    if (!name) return res.status(400).json({ message: 'name is required' });
    const finalSlug = slug || name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const [result] = await pool.execute(
      `INSERT INTO categories (name, slug, icon, is_active) VALUES (?, ?, ?, 1)`,
      [name, finalSlug, icon || null],
    );
    res.status(201).json({ message: 'Category created', categoryId: result.insertId });
  } catch (err) {
    console.error('[adminController.createCategory]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const updateCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const allowed = ['name', 'slug', 'icon', 'is_active'];
    const fields = [];
    const values = [];
    for (const key of allowed) {
      if (req.body[key] !== undefined) { fields.push(`${key} = ?`); values.push(req.body[key]); }
    }
    if (!fields.length) return res.status(400).json({ message: 'No fields to update' });
    values.push(id);
    await pool.execute(`UPDATE categories SET ${fields.join(', ')} WHERE id = ?`, values);
    res.json({ message: 'Category updated' });
  } catch (err) {
    console.error('[adminController.updateCategory]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute(`DELETE FROM categories WHERE id = ?`, [id]);
    res.json({ message: 'Category deleted' });
  } catch (err) {
    console.error('[adminController.deleteCategory]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* Payments & Settlements (Admin)                                      */
/* ------------------------------------------------------------------ */
export const getPayments = async (req, res) => {
  try {
    const { type, status, method, search, from, to, page = 1, limit = 20 } = req.query;

    // Handle legacy calls requesting withdrawals through /payments?type=withdrawal
    if (type === 'withdrawal') {
      return getWithdrawals(req, res);
    }

    const conditions = [];
    const params = [];

    // If legacy /payments?type=refund is passed
    const activeStatus = type === 'refund' ? 'refunded' : status;

    if (activeStatus && activeStatus !== 'all') {
      conditions.push('o.payment_status = ?');
      params.push(activeStatus);
    }
    if (method && method !== 'all') {
      conditions.push('o.payment_method = ?');
      params.push(method);
    }
    if (search && search.trim()) {
      const q = `%${search.trim()}%`;
      conditions.push('(e.title ILIKE ? OR u.name ILIKE ? OR u.email ILIKE ? OR o.payment_reference ILIKE ? OR CAST(o.id AS TEXT) ILIKE ?)');
      params.push(q, q, q, q, q);
    }
    if (from && to) {
      conditions.push('o.created_at BETWEEN ? AND ?');
      params.push(from, to);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
    const offset = (pageNum - 1) * limitNum;

    const [countRows] = await pool.execute(
      `SELECT COUNT(*) AS total
       FROM orders o
       LEFT JOIN events e ON e.id = o.event_id
       LEFT JOIN users u ON u.id = o.user_id
       ${where}`,
      params,
    );

    const [rows] = await pool.execute(
      `SELECT o.id, o.payment_reference AS reference, o.total_amount AS amount,
              o.discount_amount, o.payment_method, o.payment_status AS status,
              o.refund_request_status, o.refund_requested_at,
              o.created_at, o.updated_at,
              e.id AS event_id, e.title AS event_title,
              u.id AS user_id, u.name AS buyer_name, u.email AS buyer_email, u.phone AS buyer_phone,
              r.id AS refund_id, r.status AS refund_status, r.policy_circumstance,
              r.clause_number, r.organizer_deadline, r.reason AS refund_reason,
              r.admin_notes AS refund_admin_notes
       FROM orders o
       LEFT JOIN events e ON e.id = o.event_id
       LEFT JOIN users u ON u.id = o.user_id
       LEFT JOIN LATERAL (
         SELECT id, status, policy_circumstance, clause_number, organizer_deadline, reason, admin_notes
         FROM refunds
         WHERE order_id = o.id
         ORDER BY id DESC
         LIMIT 1
       ) r ON TRUE
       ${where}
       ORDER BY o.created_at DESC
       LIMIT ${limitNum} OFFSET ${offset}`,
      params,
    );

    // Summary metrics (wrapped in try-catch to guarantee no 500)
    let summary = {
      totalTransactions: 0,
      grossVolume: 0,
      platformRevenue: 0,
      pendingWithdrawals: 0,
      refunds: 0,
      refundsCount: 0,
    };

    try {
      const [[summaryRow]] = await pool.execute(
        `SELECT
           COUNT(CASE WHEN payment_status = 'completed' THEN 1 END) AS total_transactions,
           COALESCE(SUM(CASE WHEN payment_status = 'completed' THEN (total_amount - discount_amount) ELSE 0 END), 0) AS gross_volume,
           COALESCE(SUM(CASE WHEN payment_status = 'completed' THEN (total_amount - discount_amount) * 0.05 ELSE 0 END), 0) AS platform_revenue,
           COUNT(CASE WHEN payment_status = 'refunded' THEN 1 END) AS total_refunds_count,
           COALESCE(SUM(CASE WHEN payment_status = 'refunded' THEN total_amount ELSE 0 END), 0) AS total_refunds_amount
         FROM orders`,
      );

      const [[wdRow]] = await pool.execute(
        `SELECT COALESCE(SUM(amount), 0) AS pending_withdrawals FROM withdrawals WHERE status = 'pending'`,
      );

      summary = {
        totalTransactions: Number(summaryRow?.total_transactions || 0),
        grossVolume: Number(summaryRow?.gross_volume || 0),
        platformRevenue: Number(summaryRow?.platform_revenue || 0),
        pendingWithdrawals: Number(wdRow?.pending_withdrawals || 0),
        refunds: Number(summaryRow?.total_refunds_amount || 0),
        refundsCount: Number(summaryRow?.total_refunds_count || 0),
      };
    } catch (metricErr) {
      console.warn('[adminController.getPayments] summary metrics note:', metricErr.message);
    }

    const formatted = rows.map((r) => {
      const clause = getPolicyClause(r.policy_circumstance || r.clause_number);
      return {
        id: r.id,
        reference: r.reference || `#${r.id}`,
        amount: Number(r.amount),
        discountAmount: Number(r.discount_amount || 0),
        netAmount: Number(r.amount) - Number(r.discount_amount || 0),
        method: r.payment_method || 'card',
        paymentMethod: r.payment_method || 'card',
        status: r.status,
        currency: 'GHS',
        createdAt: r.created_at,
        date: r.created_at,
        eventId: r.event_id,
        eventTitle: r.event_title || '—',
        userId: r.user_id,
        userName: r.buyer_name || 'Guest',
        userEmail: r.buyer_email || '—',
        userPhone: r.buyer_phone || '',
        user: { name: r.buyer_name || 'Guest', email: r.buyer_email || '—' },
        event: { title: r.event_title || '—' },
        refundId: r.refund_id || null,
        refundStatus: r.refund_status || null,
        policyCircumstance: r.policy_circumstance || null,
        clauseNumber: r.clause_number || clause?.clauseNumber || null,
        policyClause: clause || null,
        policyTitle: clause ? `Clause ${clause.clauseNumber}: ${clause.shortTitle}` : null,
        organizerDeadline: r.organizer_deadline || null,
        refundReason: r.refund_reason || null,
        refundAdminNotes: r.refund_admin_notes || null,
        refundRequestStatus: r.refund_request_status || null,
        refundRequestedAt: r.refund_requested_at || null,
      };
    });

    res.json({
      payments: formatted,
      transactions: formatted,
      refunds: type === 'refund' ? formatted : undefined,
      summary,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: Number(countRows[0]?.total || 0),
        totalPages: Math.ceil(Number(countRows[0]?.total || 0) / limitNum) || 1,
      },
    });
  } catch (err) {
    console.error('[adminController.getPayments]', err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

/* ------------------------------------------------------------------ */
/* Withdrawals & Payouts (Admin)                                       */
/* ------------------------------------------------------------------ */
export const getWithdrawals = async (req, res) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;
    const conditions = [];
    const params = [];

    if (status && status !== 'all') {
      conditions.push('w.status = ?');
      params.push(status);
    }
    if (search && search.trim()) {
      const q = `%${search.trim()}%`;
      conditions.push('(u.name ILIKE ? OR u.email ILIKE ? OR w.reference ILIKE ? OR w.account_number ILIKE ? OR w.account_name ILIKE ?)');
      params.push(q, q, q, q, q);
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
    const offset = (pageNum - 1) * limitNum;

    const [countRows] = await pool.execute(
      `SELECT COUNT(*) AS total FROM withdrawals w JOIN users u ON u.id = w.organizer_id ${where}`,
      params,
    );
    const [rows] = await pool.execute(
      `SELECT w.*, u.name AS organizer_name, u.email AS organizer_email, u.phone AS organizer_phone,
              op.organization_name, op.payout_method, op.mobile_money
       FROM withdrawals w
       JOIN users u ON u.id = w.organizer_id
       LEFT JOIN organizer_profiles op ON op.user_id = w.organizer_id
       ${where}
       ORDER BY w.created_at DESC
       LIMIT ${limitNum} OFFSET ${offset}`,
      params,
    );

    res.json({
      withdrawals: rows.map((w) => ({
        id: w.id,
        organizerId: w.organizer_id,
        organizerName: w.organization_name || w.organizer_name || 'Organizer',
        organizerEmail: w.organizer_email,
        organizerPhone: w.organizer_phone,
        amount: Number(w.amount),
        status: w.status,
        bank: w.bank_name || 'Bank Transfer',
        bankName: w.bank_name || 'Bank Transfer',
        accountNumber: w.account_number,
        accountName: w.account_name,
        reference: w.reference,
        notes: w.notes,
        rejectionReason: w.rejection_reason,
        processedAt: w.processed_at,
        createdAt: w.created_at,
        requestedAt: w.created_at,
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: Number(countRows[0].total),
        totalPages: Math.ceil(Number(countRows[0].total) / limitNum),
      },
    });
  } catch (err) {
    console.error('[adminController.getWithdrawals]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const approveWithdrawal = async (req, res) => {
  try {
    const { id } = req.params;
    const { reference, notes } = req.body || {};

    const [wRows] = await pool.execute('SELECT * FROM withdrawals WHERE id = ?', [id]);
    if (!wRows[0]) {
      return res.status(404).json({ message: 'Withdrawal request not found' });
    }
    const withdrawal = wRows[0];
    if (withdrawal.status === 'approved' || withdrawal.status === 'paid') {
      return res.status(400).json({ message: 'Withdrawal has already been approved' });
    }

    const finalRef = reference || withdrawal.reference || `WD-${Date.now().toString().slice(-6)}`;
    await pool.execute(
      `UPDATE withdrawals
       SET status = 'approved', reference = COALESCE(?, reference), notes = COALESCE(?, notes), processed_at = NOW()
       WHERE id = ?`,
      [finalRef, notes || null, id],
    );

    // Record in wallet transactions
    await pool.execute(
      `INSERT INTO wallet_transactions (organizer_id, type, description, amount, status, reference)
       VALUES (?, 'withdrawal', ?, ?, 'completed', ?)`,
      [withdrawal.organizer_id, `Withdrawal to ${withdrawal.bank_name || 'Payout Account'}`, withdrawal.amount, finalRef],
    );

    await sendNotification({
      userId: withdrawal.organizer_id,
      title: 'Withdrawal Approved & Disbursed',
      message: `Your payout of GHS ${Number(withdrawal.amount).toFixed(2)} (${withdrawal.bank_name || 'Bank/MoMo'}) has been approved and processed. Ref: ${finalRef}`,
      type: 'withdrawal',
    });

    await logAudit({
      userId: req.user.id,
      action: 'approve_withdrawal',
      entityType: 'withdrawal',
      entityId: Number(id),
      details: { amount: withdrawal.amount, reference: finalRef, notes },
    });

    res.json({ message: 'Withdrawal approved successfully' });
  } catch (err) {
    console.error('[adminController.approveWithdrawal]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const rejectWithdrawal = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason = 'Payout details could not be verified' } = req.body || {};

    const [wRows] = await pool.execute('SELECT * FROM withdrawals WHERE id = ?', [id]);
    if (!wRows[0]) {
      return res.status(404).json({ message: 'Withdrawal request not found' });
    }
    const withdrawal = wRows[0];
    if (withdrawal.status === 'approved' || withdrawal.status === 'paid') {
      return res.status(400).json({ message: 'Cannot reject an already approved withdrawal' });
    }

    await pool.execute(
      `UPDATE withdrawals
       SET status = 'rejected', rejection_reason = ?, processed_at = NOW()
       WHERE id = ?`,
      [reason, id],
    );

    await sendNotification({
      userId: withdrawal.organizer_id,
      title: 'Withdrawal Request Rejected',
      message: `Your withdrawal request of GHS ${Number(withdrawal.amount).toFixed(2)} was rejected. Reason: ${reason}. The funds remain available in your wallet.`,
      type: 'withdrawal',
    });

    await logAudit({
      userId: req.user.id,
      action: 'reject_withdrawal',
      entityType: 'withdrawal',
      entityId: Number(id),
      details: { amount: withdrawal.amount, reason },
    });

    res.json({ message: 'Withdrawal rejected' });
  } catch (err) {
    console.error('[adminController.rejectWithdrawal]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* Reports                                                             */
/* ------------------------------------------------------------------ */
export const getReports = async (req, res) => {
  try {
    const { from, to } = req.query;
    let dateFilter = '';
    const params = [];
    if (from && to) { dateFilter = `AND o.created_at BETWEEN ? AND ?`; params.push(from, to); }

    const [[totals]] = await pool.execute(
      `SELECT COUNT(*) AS orders,
              COALESCE(SUM(o.total_amount),0) AS gross,
              COALESCE(SUM(o.discount_amount),0) AS discounts
       FROM orders o WHERE o.payment_status = 'completed' ${dateFilter}`,
      params,
    );

    const [byCategory] = await pool.execute(
      `SELECT e.category, COUNT(o.id) AS orders, COALESCE(SUM(o.total_amount - o.discount_amount),0) AS revenue
       FROM orders o
       JOIN events e ON e.id = o.event_id
       WHERE o.payment_status = 'completed' ${dateFilter}
       GROUP BY e.category
       ORDER BY revenue DESC`,
      params,
    );

    const [topOrganizers] = await pool.execute(
      `SELECT u.id, u.name, COUNT(e.id) AS events, COALESCE(SUM(o.total_amount - o.discount_amount),0) AS revenue
       FROM users u
       JOIN events e ON e.organizer_id = u.id
       LEFT JOIN orders o ON o.event_id = e.id AND o.payment_status = 'completed' ${dateFilter}
       WHERE u.role = 'organizer'
       GROUP BY u.id, u.name
       ORDER BY revenue DESC
       LIMIT 10`,
      params,
    );

    res.json({ totals, byCategory, topOrganizers });
  } catch (err) {
    console.error('[adminController.getReports]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* Support tickets                                                     */
/* ------------------------------------------------------------------ */
export const getSupportTickets = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const conditions = [];
    const params = [];
    if (status && status !== 'all') { conditions.push('s.status = ?'); params.push(status); }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
    const offset = (pageNum - 1) * limitNum;

    const [countRows] = await pool.execute(`SELECT COUNT(*) AS total FROM support_tickets s ${where}`, params);
    const [rows] = await pool.execute(
      `SELECT s.*, u.name AS user_name, u.email AS user_email
       FROM support_tickets s
       JOIN users u ON u.id = s.user_id
       ${where}
       ORDER BY s.created_at DESC
       LIMIT ${limitNum} OFFSET ${offset}`,
      params,
    );

    res.json({
      tickets: rows.map((r) => ({ ...r, user: { name: r.user_name, email: r.user_email } })),
      pagination: { page: pageNum, limit: limitNum, total: countRows[0].total, totalPages: Math.ceil(countRows[0].total / limitNum) },
    });
  } catch (err) {
    console.error('[adminController.getSupportTickets]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const resolveSupportTicket = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute(`UPDATE support_tickets SET status = 'resolved' WHERE id = ?`, [id]);
    const [rows] = await pool.execute('SELECT user_id FROM support_tickets WHERE id = ?', [id]);
    if (rows[0]) {
      sendNotification({ userId: rows[0].user_id, title: 'Support ticket resolved', message: 'Your support ticket has been marked as resolved.', type: 'support' });
    }
    await logAudit({ userId: req.user.id, action: 'resolve_support_ticket', entityType: 'support_ticket', entityId: Number(id) });
    res.json({ message: 'Support ticket resolved' });
  } catch (err) {
    console.error('[adminController.resolveSupportTicket]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* Announcements                                                       */
/* ------------------------------------------------------------------ */
export const sendAnnouncement = async (req, res) => {
  try {
    const { title, message, target = 'all', target_role, channel = 'in-app', userId } = req.body;
    if (!title?.trim() || !message?.trim()) {
      return res.status(400).json({ message: 'Title and message are required' });
    }

    const effectiveTarget = (target_role || target || 'all').toLowerCase();
    const effectiveChannel = channel || req.body.type || 'in-app';

    // 1. Insert announcement record into announcements table
    const [insRes] = await pool.execute(
      `INSERT INTO announcements (title, message, target_role, channel, created_by, sent_count)
       VALUES (?, ?, ?, ?, ?, 0)
       RETURNING id, created_at`,
      [title.trim(), message.trim(), effectiveTarget, effectiveChannel, req.user.id]
    );
    const announcementId = insRes[0]?.id;

    // 2. Identify target user IDs
    let userIds = [];
    if (effectiveTarget === 'all') {
      const [rows] = await pool.execute(`SELECT id FROM users WHERE status = 'active'`);
      userIds = rows.map((r) => r.id);
    } else if (effectiveTarget === 'attendees' || effectiveTarget === 'attendee') {
      const [rows] = await pool.execute(`SELECT id FROM users WHERE status = 'active' AND role = 'attendee'`);
      userIds = rows.map((r) => r.id);
    } else if (effectiveTarget === 'organizers' || effectiveTarget === 'organizer') {
      const [rows] = await pool.execute(`SELECT id FROM users WHERE status = 'active' AND role = 'organizer'`);
      userIds = rows.map((r) => r.id);
    } else if (effectiveTarget === 'admins' || effectiveTarget === 'admin') {
      const [rows] = await pool.execute(`SELECT id FROM users WHERE status = 'active' AND role IN ('admin', 'system_admin', 'superadmin')`);
      userIds = rows.map((r) => r.id);
    } else if (effectiveTarget === 'specific' && userId) {
      const [rows] = await pool.execute(`SELECT id FROM users WHERE id = ? OR email = ?`, [userId, userId]);
      userIds = rows.map((r) => r.id);
    }

    // 3. Dispatch in-app notifications
    if (userIds.length > 0) {
      await sendNotificationToMany(userIds, {
        title: title.trim(),
        message: message.trim(),
        type: 'announcement',
        link: '/attendee/tickets',
      });
    }

    // 4. Update sent count
    if (announcementId) {
      await pool.execute(`UPDATE announcements SET sent_count = ? WHERE id = ?`, [userIds.length, announcementId]);
    }

    await logAudit({
      userId: req.user.id,
      action: 'send_announcement',
      entityType: 'announcement',
      entityId: announcementId,
      details: { title, target: effectiveTarget, channel: effectiveChannel, recipients: userIds.length },
    });

    res.status(201).json({
      message: 'Announcement broadcast dispatched successfully',
      announcementId,
      recipients: userIds.length,
      announcement: {
        id: announcementId,
        title: title.trim(),
        message: message.trim(),
        target_role: effectiveTarget,
        channel: effectiveChannel,
        sent_count: userIds.length,
        created_at: insRes[0]?.created_at || new Date().toISOString(),
      },
    });
  } catch (err) {
    console.error('[adminController.sendAnnouncement]', err);
    res.status(500).json({ message: 'Server error while dispatching broadcast' });
  }
};

/* ------------------------------------------------------------------ */
/* Broadcast History / Announcements Query                            */
/* ------------------------------------------------------------------ */
export const getAdminAnnouncements = async (req, res) => {
  try {
    const { page = 1, limit = 15 } = req.query;
    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 15, 1), 100);
    const offset = (pageNum - 1) * limitNum;

    const [countRows] = await pool.execute(`SELECT COUNT(*) AS total FROM announcements`);
    const total = Number(countRows[0]?.total || 0);

    const [rows] = await pool.execute(
      `SELECT a.*, u.name AS sender_name, u.email AS sender_email
       FROM announcements a
       LEFT JOIN users u ON a.created_by = u.id
       ORDER BY a.created_at DESC
       LIMIT ${limitNum} OFFSET ${offset}`
    );

    res.json({
      announcements: rows,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum) || 1,
      },
    });
  } catch (err) {
    console.error('[adminController.getAdminAnnouncements]', err);
    res.status(500).json({ message: 'Failed to fetch broadcast history' });
  }
};

/* ------------------------------------------------------------------ */
/* Notification Templates                                             */
/* ------------------------------------------------------------------ */
export const getNotificationTemplates = async (req, res) => {
  try {
    const [rows] = await pool.execute(`SELECT * FROM notification_templates ORDER BY id ASC`);
    if (rows && rows.length > 0) {
      return res.json({ templates: rows });
    }

    // Seed default standard templates if table is empty (check constraint: 'email', 'sms', 'push', 'in_app')
    const defaults = [
      ['Welcome Onboarding', 'Welcome to Tribes & Cliqs', 'Welcome to Tribes & Cliqs! Discover upcoming concerts, meetups, and cultural events.', 'email'],
      ['Event 24-Hour Reminder', 'Reminder: Your Event Starts in 24 Hours', 'Your event is happening tomorrow! Please make sure to arrive 30 minutes early with your digital pass ready.', 'push'],
      ['Payment & Ticket Confirmation', 'Order Confirmed - Your Ticket Is Ready', 'Thank you for your order! Your digital ticket is confirmed and available in your wallet.', 'email'],
      ['Organizer Account Approved', 'Organizer Account Approved', 'Congratulations! Your organizer KYC verification has been approved. You can now publish events and receive payouts.', 'email'],
      ['System Maintenance Notice', 'Scheduled Platform Maintenance Notice', 'Tribes & Cliqs will undergo scheduled maintenance tonight between 02:00 AM and 03:00 AM UTC.', 'in_app'],
    ];

    for (const [name, subject, body, type] of defaults) {
      await pool.execute(
        `INSERT INTO notification_templates (name, subject, body, type) VALUES (?, ?, ?, ?)`,
        [name, subject, body, type]
      );
    }

    const [seeded] = await pool.execute(`SELECT * FROM notification_templates ORDER BY id ASC`);
    const mapped = (seeded || []).map((t) => ({ ...t, type: t.type === 'in_app' ? 'in-app' : t.type }));
    res.json({ templates: mapped });
  } catch (err) {
    console.error('[adminController.getNotificationTemplates]', err);
    res.status(500).json({ message: 'Failed to load notification templates' });
  }
};

/* ------------------------------------------------------------------ */
/* Admin Notifications                                                */
/* ------------------------------------------------------------------ */
export const getAdminNotifications = async (req, res) => {
  try {
    const { page = 1, limit = 20, unreadOnly = 'false', category = 'all', search = '' } = req.query;
    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
    const offset = (pageNum - 1) * limitNum;

    const conditions = ['(user_id = ? OR user_id IS NULL)'];
    const params = [req.user.id];

    if (unreadOnly === 'true') {
      conditions.push('is_read = FALSE');
    }

    if (category && category !== 'all') {
      if (category === 'payments') {
        conditions.push(`type IN ('payment', 'withdrawal', 'refund')`);
      } else if (category === 'organizers' || category === 'account') {
        conditions.push(`type = 'account'`);
      } else if (category === 'events' || category === 'tickets') {
        conditions.push(`type IN ('ticket', 'price_change', 'update')`);
      } else if (category === 'support') {
        conditions.push(`type = 'support'`);
      } else if (category === 'system') {
        conditions.push(`type IN ('system', 'announcement', 'marketing', 'info')`);
      } else {
        conditions.push(`type = ?`);
        params.push(category);
      }
    }

    if (search && search.trim()) {
      conditions.push(`(title ILIKE ? OR message ILIKE ?)`);
      const term = `%${search.trim()}%`;
      params.push(term, term);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const [countRows] = await pool.execute(
      `SELECT COUNT(*) AS total FROM notifications ${whereClause}`,
      params
    );

    const [unreadCountRows] = await pool.execute(
      `SELECT COUNT(*) AS unread FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = FALSE`,
      [req.user.id]
    );

    // Category breakdown counts for tabs
    const [countsByType] = await pool.execute(
      `SELECT type, COUNT(*) AS count
       FROM notifications
       WHERE (user_id = ? OR user_id IS NULL)
       GROUP BY type`,
      [req.user.id]
    );

    const counts = { all: Number(countRows[0]?.total || 0), payments: 0, organizers: 0, events: 0, support: 0, system: 0 };
    (countsByType || []).forEach((c) => {
      const cnt = Number(c.count);
      if (['payment', 'withdrawal', 'refund'].includes(c.type)) counts.payments += cnt;
      else if (c.type === 'account') counts.organizers += cnt;
      else if (['ticket', 'price_change', 'update'].includes(c.type)) counts.events += cnt;
      else if (c.type === 'support') counts.support += cnt;
      else counts.system += cnt;
    });

    const [rows] = await pool.execute(
      `SELECT * FROM notifications ${whereClause} ORDER BY created_at DESC LIMIT ${limitNum} OFFSET ${offset}`,
      params
    );

    res.json({
      notifications: rows,
      unreadCount: Number(unreadCountRows[0]?.unread || 0),
      counts,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: Number(countRows[0]?.total || 0),
        totalPages: Math.ceil(Number(countRows[0]?.total || 0) / limitNum) || 1,
      },
    });
  } catch (err) {
    console.error('[adminController.getAdminNotifications]', err);
    res.status(500).json({ message: 'Failed to fetch admin notifications' });
  }
};

export const markAdminNotificationsRead = async (req, res) => {
  try {
    const id = req.params.id || req.body.id;
    if (!id || id === 'all') {
      await pool.execute(
        `UPDATE notifications SET is_read = TRUE WHERE (user_id = ? OR user_id IS NULL)`,
        [req.user.id]
      );
    } else {
      await pool.execute(
        `UPDATE notifications SET is_read = TRUE WHERE id = ? AND (user_id = ? OR user_id IS NULL)`,
        [id, req.user.id]
      );
    }
    res.json({ message: 'Notifications marked as read' });
  } catch (err) {
    console.error('[adminController.markAdminNotificationsRead]', err);
    res.status(500).json({ message: 'Failed to update notification status' });
  }
};

export const deleteAdminNotification = async (req, res) => {
  try {
    const { id } = req.params;
    if (id === 'clear-read') {
      const [resDel] = await pool.execute(
        `DELETE FROM notifications WHERE is_read = TRUE AND (user_id = ? OR user_id IS NULL)`,
        [req.user.id]
      );
      return res.json({ message: 'Read notifications cleared successfully' });
    }

    await pool.execute(
      `DELETE FROM notifications WHERE id = ? AND (user_id = ? OR user_id IS NULL)`,
      [id, req.user.id]
    );
    res.json({ message: 'Notification removed successfully' });
  } catch (err) {
    console.error('[adminController.deleteAdminNotification]', err);
    res.status(500).json({ message: 'Failed to remove notification' });
  }
};

/* ------------------------------------------------------------------ */
/* Audit logs                                                          */
/* ------------------------------------------------------------------ */
export const getAuditLogs = async (req, res) => {
  try {
    const { action, page = 1, limit = 50 } = req.query;
    const conditions = [];
    const params = [];
    if (action) { conditions.push('a.action = ?'); params.push(action); }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 200);
    const offset = (pageNum - 1) * limitNum;

    const [countRows] = await pool.execute(`SELECT COUNT(*) AS total FROM audit_logs a ${where}`, params);
    const [rows] = await pool.execute(
      `SELECT a.*, u.name AS user_name, u.email AS user_email
       FROM audit_logs a
       LEFT JOIN users u ON u.id = a.user_id
       ${where}
       ORDER BY a.created_at DESC
       LIMIT ${limitNum} OFFSET ${offset}`,
      params,
    );

    res.json({
      logs: rows,
      pagination: { page: pageNum, limit: limitNum, total: countRows[0].total, totalPages: Math.ceil(countRows[0].total / limitNum) },
    });
  } catch (err) {
    console.error('[adminController.getAuditLogs]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* System settings                                                     */
/* ------------------------------------------------------------------ */
// System settings are stored in a simple key/value table created on demand.
// For this build we persist them in the audit-friendly `categories`-style
// approach: a dedicated settings table is created lazily here.

const ensureSettingsTable = async () => {
  await pool.execute(
    `CREATE TABLE IF NOT EXISTS system_settings (
      id BIGSERIAL PRIMARY KEY,
      setting_key VARCHAR(100) NOT NULL UNIQUE,
      setting_value TEXT,
      category VARCHAR(60) DEFAULT 'general',
      updated_by BIGINT DEFAULT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )`,
  );
};

export const getSystemSettings = async (_req, res) => {
  try {
    await ensureSettingsTable();
    const [rows] = await pool.execute(`SELECT setting_key, setting_value, updated_at FROM system_settings`);
    const settings = {};
    for (const r of rows) settings[r.setting_key] = r.setting_value;
    res.json({ settings });
  } catch (err) {
    console.error('[adminController.getSystemSettings]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const updateSystemSettings = async (req, res) => {
  try {
    await ensureSettingsTable();
    const entries = Object.entries(req.body?.settings || req.body || {});
    if (!entries.length) return res.status(400).json({ message: 'No settings provided' });

    for (const [key, value] of entries) {
      // `updated_by` is deliberately omitted from the INSERT: the table created
      // by schema.sql predates that column, and referencing it makes saves 500
      // on existing installs. The column is still migrated in for new installs.
      await pool.execute(
        `INSERT INTO system_settings (setting_key, setting_value)
         VALUES (?, ?)
         ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value`,
        [key, String(value)],
      );
    }

    clearSettingsCache();
    await logAudit({ userId: req.user.id, action: 'update_system_settings', entityType: 'system', details: { keys: entries.map((e) => e[0]) } });
    res.json({ message: 'Settings updated successfully' });
  } catch (err) {
    console.error('[adminController.updateSystemSettings]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const testEmailSetting = async (req, res) => {
  try {
    const targetEmail = req.body?.targetEmail || req.user?.email;
    if (!targetEmail) return res.status(400).json({ message: 'Target email is required' });

    const result = await sendEmail({
      to: targetEmail,
      subject: 'Tribes & Cliqs — Email Settings Test',
      text: 'Congratulations! Your email provider is correctly configured and working.',
      html: `<h2>Email Test Successful</h2><p>Your email provider settings on Tribes & Cliqs are configured correctly and active.</p>`,
    });

    if (!result.success) {
      return res.status(400).json({ message: result.error || 'Failed to send test email' });
    }
    res.json({ message: `Test email sent successfully to ${targetEmail}!` });
  } catch (err) {
    console.error('[adminController.testEmailSetting]', err);
    res.status(500).json({ message: err.message || 'Server error sending test email' });
  }
};

export const testSmsSetting = async (req, res) => {
  try {
    const targetPhone = req.body?.targetPhone || req.user?.phone;
    if (!targetPhone) return res.status(400).json({ message: 'Target phone number is required' });

    const result = await sendSMS(
      targetPhone,
      'Tribes & Cliqs: SMS provider settings test successful! Your SMS gateway is active.',
    );

    if (!result.success) {
      return res.status(400).json({ message: result.error || 'Failed to send test SMS' });
    }
    res.json({ message: `Test SMS dispatched successfully to ${targetPhone}!`, data: result.data });
  } catch (err) {
    console.error('[adminController.testSmsSetting]', err);
    res.status(500).json({ message: err.message || 'Server error sending test SMS' });
  }
};

export const getSmsBalanceSetting = async (_req, res) => {
  try {
    const apiKey = await getSmsApiKey();
    if (!apiKey) return res.status(400).json({ message: 'SMS API Key not configured' });

    const url = `https://api.smsonlinegh.com/v5/account/balance?key=${apiKey}`;
    const response = await fetch(url, { headers: { Accept: 'application/json' } });
    const data = await response.json().catch(() => ({}));

    if (!response.ok || (data.handshake && data.handshake.id !== 0)) {
      return res.status(400).json({ message: data?.handshake?.label || 'Failed to retrieve SMS balance' });
    }
    res.json({ balance: data.data?.balance ?? 0, data: data.data });
  } catch (err) {
    console.error('[adminController.getSmsBalanceSetting]', err);
    res.status(500).json({ message: err.message || 'Server error fetching SMS balance' });
  }
};

export const testPaystackSetting = async (_req, res) => {
  try {
    const secretKey = await getPaystackSecretKey();
    if (!secretKey) return res.status(400).json({ message: 'Paystack Secret Key is not configured' });

    const response = await fetch('https://api.paystack.co/balance', {
      headers: { Authorization: `Bearer ${secretKey}` },
    });
    const data = await response.json().catch(() => ({}));

    if (!response.ok || !data.status) {
      return res.status(400).json({ message: data?.message || 'Invalid Paystack Secret Key' });
    }
    res.json({ message: 'Paystack connection verified successfully!', data: data.data });
  } catch (err) {
    console.error('[adminController.testPaystackSetting]', err);
    res.status(500).json({ message: err.message || 'Server error verifying Paystack' });
  }
};

/* ------------------------------------------------------------------ */
/* CMS Content                                                         */
/* ------------------------------------------------------------------ */
export const getContentPages = async (_req, res) => {
  try {
    const [banners] = await pool.execute(`SELECT * FROM banners ORDER BY sort_order ASC`);
    const [faqs] = await pool.execute(`SELECT * FROM faqs ORDER BY sort_order ASC`);
    const [blogPosts] = await pool.execute(`SELECT * FROM blog_posts ORDER BY created_at DESC`);
    res.json({ banners, faqs, blogPosts, pages: [] });
  } catch (err) {
    console.error('[adminController.getContentPages]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const createContentPage = async (_req, res) => {
  res.json({ message: 'Content created' });
};

export const updateContentPage = async (_req, res) => {
  res.json({ message: 'Content updated' });
};

export const deleteContentPage = async (_req, res) => {
  res.json({ message: 'Content deleted' });
};

/* ------------------------------------------------------------------ */
/* Support Tickets                                                     */
/* ------------------------------------------------------------------ */
export const getSupportTicket = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      `SELECT s.*, u.name AS user_name, u.email AS user_email
       FROM support_tickets s
       LEFT JOIN users u ON u.id = s.user_id
       WHERE s.id = ?`,
      [id],
    );
    if (!rows.length) return res.status(404).json({ message: 'Ticket not found' });

    const [replies] = await pool.execute(
      `SELECT sr.*, u.name AS author_name, u.email AS author_email, u.role AS author_role
       FROM support_replies sr
       LEFT JOIN users u ON u.id = sr.user_id
       WHERE sr.ticket_id = ?
       ORDER BY sr.created_at ASC`,
      [id],
    );

    res.json({ ticket: { ...rows[0], user: { name: rows[0].user_name, email: rows[0].user_email } }, replies });
  } catch (err) {
    console.error('[adminController.getSupportTicket]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const respondToSupportTicket = async (req, res) => {
  try {
    const { id } = req.params;
    const { message } = req.body;
    await pool.execute(
      'INSERT INTO support_replies (ticket_id, user_id, message, is_staff) VALUES (?, ?, ?, 1)',
      [id, req.user.id, message || 'Response sent from support.'],
    );
    res.json({ message: 'Response sent' });
  } catch (err) {
    console.error('[adminController.respondToSupportTicket]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const closeSupportTicket = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute("UPDATE support_tickets SET status = 'closed' WHERE id = ?", [id]);
    res.json({ message: 'Ticket closed' });
  } catch (err) {
    console.error('[adminController.closeSupportTicket]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

/* ------------------------------------------------------------------ */
/* User & Event Management Extra Actions                               */
/* ------------------------------------------------------------------ */
export const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    const user = rows[0];
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (user.role === 'system_admin' || user.role === 'superadmin') {
      return res.status(400).json({ message: 'System Admin accounts cannot be deleted' });
    }
    const isMasterAdmin = req.user.role === 'system_admin' || req.user.role === 'superadmin';
    if (user.role === 'admin' && !isMasterAdmin) {
      return res.status(400).json({ message: 'Admin accounts cannot be deleted' });
    }

    await logAudit({ userId: req.user.id, action: 'delete_user', entityType: 'user', entityId: Number(id), details: { name: user.name, email: user.email } });
    await pool.execute('DELETE FROM refresh_tokens WHERE user_id = ?', [id]);
    await pool.execute('DELETE FROM users WHERE id = ?', [id]);
    res.json({ message: 'User deleted successfully' });
  } catch (err) {
    console.error('[adminController.deleteUser]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const unsuspendUser = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    const user = rows[0];
    if (!user) return res.status(404).json({ message: 'User not found' });
    if (user.status !== 'suspended') return res.status(400).json({ message: 'User is not suspended' });

    await pool.execute(
      `UPDATE users SET status = 'active', suspend_reason = NULL, suspended_at = NULL WHERE id = ?`,
      [id],
    );
    if (user.role === 'organizer' && user.is_approved) {
      await pool.execute('UPDATE organizer_profiles SET is_verified = TRUE WHERE user_id = ?', [id]);
    }
    await sendNotification({
      userId: Number(id),
      title: 'Account reinstated',
      message: 'Your account has been reinstated. You can now use the platform again.',
      type: 'account',
    });
    await logAudit({ userId: req.user.id, action: 'unsuspend_user', entityType: 'user', entityId: Number(id) });
    res.json({ message: 'User unsuspended successfully' });
  } catch (err) {
    console.error('[adminController.unsuspendUser]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const verifyUser = approveOrganizer;

/* ------------------------------------------------------------------ */
/* Reset a user's password (admin)                                     */
/* ------------------------------------------------------------------ */
// Admins may set a new password for any non-admin account, or let the
// system generate a strong temporary one. The plaintext is never stored —
// only the bcrypt hash. Outstanding reset tokens are burned so stale
// links cannot override the fresh credential.
const generateTemporaryPassword = (len = 14) => {
  const lower = 'abcdefghijkmnopqrstuvwxyz';
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const digits = '23456789';
  const special = '!@#$%^&*';
  const all = lower + upper + digits + special;
  const pick = (s) => s[crypto.randomBytes(1)[0] % s.length];
  const required = [pick(lower), pick(upper), pick(digits), pick(special)];
  const bytes = crypto.randomBytes(len);
  let out = required.join('');
  for (let i = out.length; i < len; i++) out += all[bytes[i] % all.length];
  return out.split('').sort(() => crypto.randomBytes(1)[0] % 3 - 1).join('');
};

export const resetUserPassword = async (req, res) => {
  try {
    const { id } = req.params;
    const { password } = req.body || {};

    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    const user = rows[0];
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (user.role === 'system_admin' || user.role === 'superadmin') {
      if (user.id !== req.user.id) {
        return res.status(400).json({ message: 'System Admin passwords cannot be reset here' });
      }
    } else if (user.role === 'admin') {
      const isMasterAdmin = req.user.role === 'system_admin' || req.user.role === 'superadmin';
      if (!isMasterAdmin) {
        return res.status(400).json({ message: 'Admin account passwords cannot be reset here' });
      }
    }

    const generated = !password;
    const newPassword = generated ? generateTemporaryPassword() : String(password);

    const strength = validatePassword(newPassword);
    if (!strength.valid) {
      return res.status(400).json({ message: strength.message });
    }

    const hashed = await bcrypt.hash(newPassword, 12);
    await pool.execute('UPDATE users SET password = ? WHERE id = ?', [hashed, id]);

    // Burn outstanding reset tokens so old emailed links stop working.
    await pool.execute('UPDATE password_reset_tokens SET used = TRUE WHERE user_id = ?', [id]);

    // Revoke all sessions — force re-login everywhere
    await pool.execute('UPDATE refresh_tokens SET revoked = TRUE WHERE user_id = ?', [id]);

    await sendNotification({
      userId: Number(id),
      title: 'Password updated by administrator',
      message: 'Your password was reset by an administrator. Please log in using the new password.',
      type: 'account',
    });
    await logAudit({
      userId: req.user.id,
      action: 'admin_reset_password',
      entityType: 'user',
      entityId: Number(id),
      details: { generated, by: req.user.email },
    });

    res.json({
      message: generated ? 'Temporary password generated' : 'Password reset successfully',
      ...(generated ? { temporaryPassword: newPassword } : {}),
    });
  } catch (err) {
    console.error('[adminController.resetUserPassword]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const adminDeleteEvent = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute('DELETE FROM events WHERE id = ?', [id]);
    res.json({ message: 'Event deleted' });
  } catch (err) {
    console.error('[adminController.adminDeleteEvent]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const getPayment = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      `SELECT o.*, e.title AS event_title, e.venue AS event_venue,
              u.name AS buyer_name, u.email AS buyer_email, u.phone AS buyer_phone
       FROM orders o
       LEFT JOIN events e ON e.id = o.event_id
       LEFT JOIN users u ON u.id = o.user_id
       WHERE CAST(o.id AS TEXT) = ? OR o.payment_reference = ?`,
      [String(id), String(id)],
    );
    if (!rows.length) return res.status(404).json({ message: 'Payment not found' });

    const [items] = await pool.execute(
      `SELECT oi.*, tt.name AS ticket_name, tt.price AS unit_price
       FROM order_items oi
       LEFT JOIN ticket_types tt ON tt.id = oi.ticket_type_id
       WHERE oi.order_id = ?`,
      [rows[0].id],
    );

    res.json({ payment: { ...rows[0], items } });
  } catch (err) {
    console.error('[adminController.getPayment]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const refundPayment = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason, circumstance, policyCircumstance, adminNotes } = req.body || {};

    const [rows] = await pool.execute(
      `SELECT o.*, u.name AS buyer_name, u.email AS buyer_email, e.title AS event_title, e.organizer_id
       FROM orders o
       LEFT JOIN events e ON e.id = o.event_id
       LEFT JOIN users u ON u.id = o.user_id
       WHERE CAST(o.id AS TEXT) = ? OR o.payment_reference = ?`,
      [String(id), String(id)],
    );
    const order = rows[0];
    if (!order) return res.status(404).json({ message: 'Order not found' });

    if (order.payment_status === 'refunded') {
      return res.status(400).json({ message: 'Order has already been refunded' });
    }
    if (order.payment_status !== 'completed') {
      return res.status(400).json({ message: 'Only completed orders can be refunded' });
    }

    const selectedCircumstance = circumstance || policyCircumstance || '1_ORGANIZER_AUTHORIZED';
    const policyClause = getPolicyClause(selectedCircumstance);
    const clauseNum = policyClause?.clauseNumber || 1;
    const citation = formatPolicyCitation(selectedCircumstance);

    if (order.payment_reference) {
      const refundResult = await refundTransaction(order.payment_reference, Number(order.total_amount));
      if (!refundResult.status) {
        console.warn('[adminController.refundPayment] Paystack refund notice:', refundResult.error);
      }
    }

    await pool.execute(
      `UPDATE orders SET payment_status = 'refunded', order_status = 'refunded', refund_request_status = 'approved', updated_at = NOW() WHERE id = ?`,
      [order.id],
    );
    await pool.execute(
      `UPDATE tickets SET status = 'cancelled' WHERE order_item_id IN (SELECT id FROM order_items WHERE order_id = ?)`,
      [order.id],
    );

    // Update or insert into refunds ledger
    const [existingRefunds] = await pool.execute(`SELECT id FROM refunds WHERE order_id = ?`, [order.id]);
    if (existingRefunds.length > 0) {
      await pool.execute(
        `UPDATE refunds SET
           status = 'processed', policy_circumstance = ?, clause_number = ?,
           processed_by = ?, processed_at = NOW(), admin_notes = COALESCE(?, admin_notes)
         WHERE order_id = ?`,
        [selectedCircumstance, clauseNum, req.user.id, adminNotes || null, order.id],
      );
    } else {
      await pool.execute(
        `INSERT INTO refunds (
           order_id, user_id, event_id, organizer_id, amount, reason,
           policy_circumstance, clause_number, initiated_by, status,
           processed_by, processed_at, admin_notes, created_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'admin', 'processed', ?, NOW(), ?, NOW())`,
        [
          order.id,
          order.user_id,
          order.event_id,
          order.organizer_id || null,
          order.total_amount,
          reason || policyClause?.description || 'Admin processed refund',
          selectedCircumstance,
          clauseNum,
          req.user.id,
          adminNotes || null,
        ],
      );
    }

    // Notify buyer citing the official policy clause
    await sendNotification({
      userId: order.user_id,
      title: 'Order Refunded',
      message: `Your order #${order.id} has been refunded per ${citation}. Reason: ${reason || policyClause?.title}.`,
      type: 'refund',
    });

    // Notify organizer citing the official policy clause
    if (order.organizer_id) {
      await sendNotification({
        userId: order.organizer_id,
        title: 'Refund Issued by Platform',
        message: `TRIBESANDCLIQS has refunded Order #${order.id} for "${order.event_title || 'Event'}" per ${citation}.`,
        type: 'refund',
      });
    }

    await logAudit({
      userId: req.user.id,
      action: 'admin_refund_order',
      entityType: 'order',
      entityId: Number(order.id),
      details: {
        amount: order.total_amount,
        reason,
        circumstance: selectedCircumstance,
        clauseNumber: clauseNum,
        citation,
      },
    });

    res.json({
      message: `Payment refunded successfully under ${citation}.`,
      orderId: order.id,
      circumstance: selectedCircumstance,
      clause: policyClause,
    });
  } catch (err) {
    console.error('[adminController.refundPayment]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const processUnresponsiveRefunds = async (req, res) => {
  try {
    // Find all pending refund requests where organizer_deadline has passed (< NOW())
    const [pendingRows] = await pool.execute(
      `SELECT r.*, o.payment_reference, o.total_amount, o.user_id AS buyer_user_id,
              e.title AS event_title
       FROM refunds r
       JOIN orders o ON o.id = r.order_id
       JOIN events e ON e.id = r.event_id
       WHERE r.status = 'pending' AND r.organizer_deadline < NOW()`,
    );

    const processed = [];
    const circumstance = '5_BUYER_CIRCUMSTANCES_UNRESPONSIVE_ORGANIZER';
    const citation = formatPolicyCitation(circumstance);

    for (const reqRow of pendingRows) {
      if (reqRow.payment_reference) {
        const refundResult = await refundTransaction(reqRow.payment_reference, Number(reqRow.total_amount));
        if (!refundResult.status) {
          console.warn('[processUnresponsiveRefunds] Paystack refund note:', refundResult.error);
        }
      }

      await pool.execute(
        `UPDATE orders SET payment_status = 'refunded', order_status = 'refunded', refund_request_status = 'approved', updated_at = NOW() WHERE id = ?`,
        [reqRow.order_id],
      );
      await pool.execute(
        `UPDATE tickets SET status = 'cancelled' WHERE order_item_id IN (SELECT id FROM order_items WHERE order_id = ?)`,
        [reqRow.order_id],
      );
      await pool.execute(
        `UPDATE refunds SET
           status = 'processed', policy_circumstance = ?, clause_number = 5,
           processed_by = ?, processed_at = NOW(),
           admin_notes = COALESCE(admin_notes, 'Auto-processed under Clause 5: Organizer unresponsive > 1 day SLA')
         WHERE id = ?`,
        [circumstance, req.user.id, reqRow.id],
      );

      await sendNotification({
        userId: reqRow.buyer_user_id,
        title: 'Refund Approved — Organizer Unresponsive SLA',
        message: `Your refund for Order #${reqRow.order_id} has been issued under ${citation}.`,
        type: 'refund',
      });

      if (reqRow.organizer_id) {
        await sendNotification({
          userId: reqRow.organizer_id,
          title: 'Refund Executed (1-Day SLA Expired)',
          message: `Order #${reqRow.order_id} on "${reqRow.event_title}" was refunded under ${citation} due to no organizer response within 1 day.`,
          type: 'refund',
        });
      }

      await logAudit({
        userId: req.user.id,
        action: 'auto_refund_unresponsive_organizer',
        entityType: 'order',
        entityId: Number(reqRow.order_id),
        details: { refundRequestId: reqRow.id, amount: reqRow.total_amount, clauseNumber: 5 },
      });

      processed.push({ orderId: reqRow.order_id, refundId: reqRow.id });
    }

    res.json({
      message: `Processed ${processed.length} overdue refund requests under Clause 5 (Unresponsive Organizer).`,
      count: processed.length,
      processed,
    });
  } catch (err) {
    console.error('[adminController.processUnresponsiveRefunds]', err);
    res.status(500).json({ message: 'Server error processing overdue refunds' });
  }
};

export const getRevenueReport = async (_req, res) => {
  res.json({ report: [] });
};

export const getGrowthReport = async (_req, res) => {
  res.json({ report: [] });
};

/* ------------------------------------------------------------------ */
/* User Management Power Features                                       */
/* ------------------------------------------------------------------ */

// Get detailed activity log for a user
export const getUserActivity = async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 50, offset = 0 } = req.query;
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 200);

    const [rows] = await pool.execute(
      `SELECT * FROM user_activity_log WHERE user_id = ? ORDER BY created_at DESC LIMIT ${limitNum} OFFSET ${parseInt(offset, 10) || 0}`,
      [id],
    );
    const [countRows] = await pool.execute(
      'SELECT COUNT(*) AS total FROM user_activity_log WHERE user_id = ?',
      [id],
    );
    res.json({ activities: rows, total: countRows[0].total });
  } catch (err) {
    console.error('[adminController.getUserActivity]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get active sessions for a user
export const getUserSessions = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      `SELECT id, ip_address, user_agent, created_at, last_active
       FROM refresh_tokens
       WHERE user_id = ? AND revoked = FALSE AND used = FALSE AND expires_at > NOW()
       ORDER BY last_active DESC`,
      [id],
    );
    res.json({ sessions: rows });
  } catch (err) {
    console.error('[adminController.getUserSessions]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Force logout — revoke all sessions for a user
export const forceLogoutUser = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    if (!rows[0]) return res.status(404).json({ message: 'User not found' });

    await pool.execute('UPDATE refresh_tokens SET revoked = TRUE WHERE user_id = ?', [id]);
    await sendNotification({
      userId: Number(id),
      title: 'Signed out by administrator',
      message: 'An administrator has signed you out of all devices.',
      type: 'account',
    });
    await logAudit({
      userId: req.user.id, action: 'force_logout',
      entityType: 'user', entityId: Number(id),
    });
    res.json({ message: 'All sessions revoked' });
  } catch (err) {
    console.error('[adminController.forceLogoutUser]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Admin notes — add a note to a user
export const addAdminNote = async (req, res) => {
  try {
    const { id } = req.params;
    const { note } = req.body;
    if (!note || !note.trim()) return res.status(400).json({ message: 'Note is required' });

    const [result] = await pool.execute(
      'INSERT INTO admin_user_notes (user_id, admin_id, note) VALUES (?, ?, ?)',
      [id, req.user.id, note.trim()],
    );
    res.json({ message: 'Note added', noteId: result.insertId });
  } catch (err) {
    console.error('[adminController.addAdminNote]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Admin notes — get all notes for a user
export const getAdminNotes = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      `SELECT n.*, u.name AS admin_name, u.email AS admin_email
       FROM admin_user_notes n
       JOIN users u ON u.id = n.admin_id
       WHERE n.user_id = ?
       ORDER BY n.created_at DESC`,
      [id],
    );
    res.json({ notes: rows });
  } catch (err) {
    console.error('[adminController.getAdminNotes]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Admin notes — delete a note
export const deleteAdminNote = async (req, res) => {
  try {
    const { noteId } = req.params;
    await pool.execute('DELETE FROM admin_user_notes WHERE id = ?', [noteId]);
    res.json({ message: 'Note deleted' });
  } catch (err) {
    console.error('[adminController.deleteAdminNote]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Export users as CSV
export const exportUsers = async (req, res) => {
  try {
    const { role, status, search } = req.query;
    const conditions = [];
    const params = [];

    if (role && role !== 'all') conditions.push('u.role = ?') && params.push(role);
    if (status && status !== 'all') {
      if (status === 'pending') conditions.push("u.role = 'organizer' AND u.is_approved = FALSE AND u.status = 'pending'");
      else if (status === 'active') conditions.push("u.status = 'active'");
      else if (status === 'suspended') conditions.push('u.status = "suspended"');
    }
    if (search) {
      conditions.push('(u.name LIKE ? OR u.email LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const [rows] = await pool.execute(
      `SELECT u.id, u.name, u.email, u.role, u.phone, u.status, u.is_approved,
              u.email_verified, u.created_at, u.last_login_at,
              op.organization_name
       FROM users u
       LEFT JOIN organizer_profiles op ON op.user_id = u.id
       ${where}
       ORDER BY u.created_at DESC`,
      params,
    );

    const csvHeader = 'ID,Name,Email,Role,Phone,Status,Approved,Email Verified,Organization,Created,Last Login\n';
    const csvBody = rows.map((r) =>
      [r.id, `"${(r.name || '').replace(/"/g, '""')}"`, r.email, r.role, r.phone || '',
       r.status, r.is_approved ? 'Yes' : 'No', r.email_verified ? 'Yes' : 'No',
       `"${(r.organization_name || '').replace(/"/g, '""')}"`,
       r.created_at || '', r.last_login_at || ''].join(',')
    ).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="users-export.csv"');
    res.send(csvHeader + csvBody);
  } catch (err) {
    console.error('[adminController.exportUsers]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Bulk role change
export const bulkRoleChange = async (req, res) => {
  try {
    const { ids, role } = req.body;
    if (!ids?.length || !role) return res.status(400).json({ message: 'ids and role are required' });
    if (!['attendee', 'organizer'].includes(role)) return res.status(400).json({ message: 'Invalid role' });

    const placeholders = ids.map(() => '?').join(',');
    // Don't touch admin accounts
    await pool.execute(
      `UPDATE users SET role = ? WHERE id IN (${placeholders}) AND role != 'admin'`,
      [role, ...ids],
    );

    // Ensure organizer profiles exist for promoted users
    if (role === 'organizer') {
      for (const uid of ids) {
        const [existing] = await pool.execute('SELECT id FROM organizer_profiles WHERE user_id = ?', [uid]);
        if (!existing.length) {
          const [u] = await pool.execute('SELECT name FROM users WHERE id = ?', [uid]);
          await pool.execute(
            'INSERT INTO organizer_profiles (user_id, organization_name) VALUES (?, ?)',
            [uid, u[0]?.name || 'Unknown'],
          );
        }
      }
    }

    await logAudit({
      userId: req.user.id, action: 'bulk_role_change',
      entityType: 'user', entityId: 0,
      details: { ids, role },
    });
    res.json({ message: `${ids.length} users updated to ${role}` });
  } catch (err) {
    console.error('[adminController.bulkRoleChange]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Bulk delete
export const bulkDeleteUsers = async (req, res) => {
  try {
    const { ids } = req.body;
    if (!ids?.length) return res.status(400).json({ message: 'ids array is required' });

    const placeholders = ids.map(() => '?').join(',');
    // Don't delete admin accounts
    await pool.execute(
      `DELETE FROM refresh_tokens WHERE user_id IN (${placeholders})`,
      [...ids],
    );
    const [result] = await pool.execute(
      `DELETE FROM users WHERE id IN (${placeholders}) AND role != 'admin'`,
      [...ids],
    );

    await logAudit({
      userId: req.user.id, action: 'bulk_delete_users',
      entityType: 'user', entityId: 0,
      details: { ids, deleted: result.affectedRows },
    });
    res.json({ message: `${result.affectedRows} users deleted` });
  } catch (err) {
    console.error('[adminController.bulkDeleteUsers]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// User management stats — overview bar numbers
export const getUserManagementStats = async (_req, res) => {
  try {
    const [[total]] = await pool.execute('SELECT COUNT(*) AS count FROM users');
    const [[active]] = await pool.execute("SELECT COUNT(*) AS count FROM users WHERE status = 'active'");
    const [[suspended]] = await pool.execute("SELECT COUNT(*) AS count FROM users WHERE status = 'suspended'");
    const [[pending]] = await pool.execute(
      "SELECT COUNT(*) AS count FROM users WHERE role = 'organizer' AND (is_approved = FALSE OR is_approved IS NULL) AND status != 'rejected' AND status != 'suspended' AND status != 'active'",
    );
    const [[organizers]] = await pool.execute("SELECT COUNT(*) AS count FROM users WHERE role = 'organizer'");
    const [[attendees]] = await pool.execute("SELECT COUNT(*) AS count FROM users WHERE role = 'attendee'");
    const [[verified]] = await pool.execute('SELECT COUNT(*) AS count FROM users WHERE email_verified = TRUE');
    const [[recentWeek]] = await pool.execute("SELECT COUNT(*) AS count FROM users WHERE created_at >= NOW() - INTERVAL '7 days'");

    res.json({
      stats: {
        total: Number(total?.count || 0),
        active: Number(active?.count || 0),
        suspended: Number(suspended?.count || 0),
        pendingOrganizers: Number(pending?.count || 0),
        organizers: Number(organizers?.count || 0),
        attendees: Number(attendees?.count || 0),
        verified: Number(verified?.count || 0),
        joinedThisWeek: Number(recentWeek?.count || 0),
      },
    });
  } catch (err) {
    console.error('[adminController.getUserManagementStats]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// User stats — detailed breakdown for the user detail panel
export const getUserStats = async (req, res) => {
  try {
    const { id } = req.params;

    const safeQuery = async (sql, params = []) => {
      try { const [rows] = await pool.execute(sql, params); return rows[0] || { count: 0, revenue: 0 }; }
      catch { return { count: 0, revenue: 0 }; }
    };

    const orders = await safeQuery(
      'SELECT COUNT(*) AS count, COALESCE(SUM(total_amount), 0) AS revenue FROM orders WHERE user_id = ?',
      [id],
    );
    const events = await safeQuery('SELECT COUNT(*) AS count FROM events WHERE organizer_id = ?', [id]);
    const tickets = await safeQuery('SELECT COUNT(*) AS count FROM tickets WHERE user_id = ?', [id]);
    const reviews = await safeQuery('SELECT COUNT(*) AS count FROM reviews WHERE user_id = ?', [id]);
    const favorites = await safeQuery('SELECT COUNT(*) AS count FROM favorites WHERE user_id = ?', [id]);
    const sessions = await safeQuery(
      `SELECT COUNT(*) AS count FROM refresh_tokens WHERE user_id = ? AND revoked = FALSE AND used = FALSE AND expires_at > NOW()`,
      [id],
    );
    let recentLogins = [];
    try {
      const [logins] = await pool.execute(
        `SELECT action, created_at FROM audit_logs WHERE user_id = ? AND action IN ('login', 'admin_login') ORDER BY created_at DESC LIMIT 10`,
        [id],
      );
      recentLogins = logins || [];
    } catch { /* audit_logs table may not exist */ }

    res.json({
      stats: {
        orders: Number(orders?.count || 0),
        revenue: Number(orders?.revenue || 0),
        events: Number(events?.count || 0),
        tickets: Number(tickets?.count || 0),
        reviews: Number(reviews?.count || 0),
        favorites: Number(favorites?.count || 0),
        activeSessions: Number(sessions?.count || 0),
        recentLogins,
      },
    });
  } catch (err) {
    console.error('[adminController.getUserStats]', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const createAdminUser = async (req, res) => {
  try {
    const { name, email, password, phone } = req.body || {};
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email, and password are required' });
    }

    const cleanEmail = String(email).trim().toLowerCase();
    if (!EMAIL_RE.test(cleanEmail)) {
      return res.status(400).json({ message: 'Invalid email address' });
    }

    const [existing] = await pool.execute('SELECT id FROM users WHERE email = ?', [cleanEmail]);
    if (existing.length > 0) {
      return res.status(400).json({ message: 'A user with this email already exists' });
    }

    const strength = validatePassword(String(password));
    if (!strength.valid) {
      return res.status(400).json({ message: strength.message });
    }

    const hash = await bcrypt.hash(String(password), 12);
    const [result] = await pool.execute(
      `INSERT INTO users (name, email, password, role, phone, status, is_approved, email_verified)
       VALUES (?, ?, ?, 'admin', ?, 'active', TRUE, TRUE)`,
      [name.trim(), cleanEmail, hash, phone ? String(phone).trim() : null],
    );

    const newAdminId = result.insertId;

    await logAudit({
      userId: req.user.id,
      action: 'create_admin_user',
      entityType: 'user',
      entityId: Number(newAdminId),
      details: { name: name.trim(), email: cleanEmail, role: 'admin' },
    });

    res.status(201).json({
      message: 'Operations Admin created successfully',
      user: { id: newAdminId, name: name.trim(), email: cleanEmail, role: 'admin', status: 'active', is_approved: 1, email_verified: 1 },
    });
  } catch (err) {
    console.error('[adminController.createAdminUser]', err);
    res.status(500).json({ message: 'Failed to create admin user' });
  }
};

/* ------------------------------------------------------------------ */
/* AI Training & Knowledge Management                                 */
/* ------------------------------------------------------------------ */
export const getAITrainingData = async (_req, res) => {
  try {
    // Ensure table exists safely
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS ai_training_knowledge (
        id                      BIGSERIAL PRIMARY KEY,
        title                   VARCHAR(255) NOT NULL,
        category                VARCHAR(100) NOT NULL DEFAULT 'faq',
        keywords                TEXT,
        instruction_or_answer   TEXT NOT NULL,
        is_active               BOOLEAN DEFAULT TRUE,
        created_at              TIMESTAMPTZ DEFAULT NOW(),
        updated_at              TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    const [items] = await pool.execute(
      `SELECT * FROM ai_training_knowledge ORDER BY id DESC`
    );

    // Fetch custom system instruction & temperature from system_settings
    const [settings] = await pool.execute(
      `SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('ai_custom_instructions', 'ai_temperature')`
    );

    const config = {};
    for (const row of settings || []) {
      config[row.setting_key] = row.setting_value;
    }

    res.json({
      knowledge: items || [],
      customInstructions: config.ai_custom_instructions || '',
      temperature: config.ai_temperature ? Number(config.ai_temperature) : 0.7,
    });
  } catch (err) {
    console.error('[adminController.getAITrainingData]', err);
    res.status(500).json({ message: 'Failed to fetch AI training data' });
  }
};

export const createAIKnowledgeItem = async (req, res) => {
  try {
    const { title, category = 'faq', keywords = '', instruction_or_answer } = req.body;
    if (!title || !instruction_or_answer) {
      return res.status(400).json({ message: 'Title and training answer/instruction are required' });
    }

    const [result] = await pool.execute(
      `INSERT INTO ai_training_knowledge (title, category, keywords, instruction_or_answer, is_active)
       VALUES (?, ?, ?, ?, TRUE)`,
      [title.trim(), category.trim(), keywords.trim(), instruction_or_answer.trim()]
    );

    await logAudit({
      userId: req.user.id,
      action: 'create_ai_knowledge_item',
      entityType: 'ai_knowledge',
      entityId: Number(result.insertId),
      details: { title, category },
    });

    res.status(201).json({
      message: 'Knowledge item created successfully',
      item: {
        id: result.insertId,
        title,
        category,
        keywords,
        instruction_or_answer,
        is_active: true,
      },
    });
  } catch (err) {
    console.error('[adminController.createAIKnowledgeItem]', err);
    res.status(500).json({ message: 'Failed to create AI knowledge item' });
  }
};

export const updateAIKnowledgeItem = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, category, keywords, instruction_or_answer, is_active } = req.body;

    const [existing] = await pool.execute(
      `SELECT * FROM ai_training_knowledge WHERE id = ?`,
      [id]
    );
    if (!existing[0]) {
      return res.status(404).json({ message: 'Knowledge item not found' });
    }

    const newTitle = title !== undefined ? title.trim() : existing[0].title;
    const newCategory = category !== undefined ? category.trim() : existing[0].category;
    const newKeywords = keywords !== undefined ? keywords.trim() : existing[0].keywords;
    const newInstruction = instruction_or_answer !== undefined ? instruction_or_answer.trim() : existing[0].instruction_or_answer;
    const newActive = is_active !== undefined ? Boolean(is_active) : existing[0].is_active;

    await pool.execute(
      `UPDATE ai_training_knowledge
       SET title = ?, category = ?, keywords = ?, instruction_or_answer = ?, is_active = ?, updated_at = NOW()
       WHERE id = ?`,
      [newTitle, newCategory, newKeywords, newInstruction, newActive, id]
    );

    res.json({
      message: 'Knowledge item updated successfully',
      item: {
        id: Number(id),
        title: newTitle,
        category: newCategory,
        keywords: newKeywords,
        instruction_or_answer: newInstruction,
        is_active: newActive,
      },
    });
  } catch (err) {
    console.error('[adminController.updateAIKnowledgeItem]', err);
    res.status(500).json({ message: 'Failed to update AI knowledge item' });
  }
};

export const deleteAIKnowledgeItem = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute(`DELETE FROM ai_training_knowledge WHERE id = ?`, [id]);
    await logAudit({
      userId: req.user.id,
      action: 'delete_ai_knowledge_item',
      entityType: 'ai_knowledge',
      entityId: Number(id),
    });
    res.json({ message: 'Knowledge item deleted successfully' });
  } catch (err) {
    console.error('[adminController.deleteAIKnowledgeItem]', err);
    res.status(500).json({ message: 'Failed to delete AI knowledge item' });
  }
};

export const updateAISettings = async (req, res) => {
  try {
    const { customInstructions = '', temperature = 0.7 } = req.body;

    await pool.execute(
      `INSERT INTO system_settings (setting_key, setting_value)
       VALUES ('ai_custom_instructions', ?)
       ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()`,
      [customInstructions]
    );

    await pool.execute(
      `INSERT INTO system_settings (setting_key, setting_value)
       VALUES ('ai_temperature', ?)
       ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()`,
      [String(temperature)]
    );

    await logAudit({
      userId: req.user.id,
      action: 'update_ai_settings',
      entityType: 'system_settings',
      details: { customInstructionsLength: customInstructions.length, temperature },
    });

    res.json({ message: 'AI settings updated successfully' });
  } catch (err) {
    console.error('[adminController.updateAISettings]', err);
    res.status(500).json({ message: 'Failed to update AI settings' });
  }
};

export const testAIPrompt = async (req, res) => {
  try {
    const { message, customInstructions, temperature = 0.7 } = req.body;
    const testQuery = (message || '').trim();
    if (!testQuery) {
      return res.status(400).json({ message: 'Test message is required' });
    }

    const [items] = await pool.execute(
      `SELECT * FROM ai_training_knowledge WHERE is_active = TRUE`
    );

    const [events] = await pool.execute(`
      SELECT e.id, e.title, e.start_date, e.venue, e.city, e.category,
             COALESCE(MIN(tt.price), 0) AS min_price
      FROM events e
      LEFT JOIN ticket_types tt ON tt.event_id = e.id
      WHERE e.status = 'published'
      GROUP BY e.id
      ORDER BY e.start_date ASC
      LIMIT 6
    `);

    const knowledgeSummary = (items || []).map((k) => `[${k.category.toUpperCase()}] ${k.title}: ${k.instruction_or_answer}`).join('\n');
    const eventsSummary = (events || []).map((e) => `- ${e.title} (${e.category}) on ${e.start_date} at ${e.venue || e.city} (From GHS ${e.min_price})`).join('\n');

    const prompt = `You are Cliq Concierge, the official event guide for Tribes & Cliqs in Ghana.
${customInstructions || 'Tone: Friendly, concise, insider host. Avoid robotic lists or emoji spam. Keep responses short and punchy (1 to 3 sentences).'}

Trained Knowledge Base:
${knowledgeSummary}

Live Published Events:
${eventsSummary}
`;

    const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
    if (GEMINI_API_KEY) {
      try {
        const geminiRes = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ role: 'user', parts: [{ text: testQuery }] }],
              systemInstruction: { parts: [{ text: prompt }] },
              generationConfig: { temperature: Number(temperature), maxOutputTokens: 250 },
            }),
            signal: AbortSignal.timeout(8000),
          }
        );

        if (geminiRes.ok) {
          const geminiData = await geminiRes.json();
          const reply = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (reply) {
            return res.json({
              reply: reply.trim(),
              contextUsed: { knowledgeCount: items?.length || 0, eventsCount: events?.length || 0 },
            });
          }
        }
      } catch (geminiError) {
        console.warn('[testAIPrompt] Gemini API returned error, falling back to trained knowledge base:', geminiError.message);
      }
    }

    // Local Trained Knowledge Base Fallback
    const lower = testQuery.toLowerCase();
    let matchedAnswer = null;

    for (const item of items || []) {
      const keys = (item.keywords || '').toLowerCase().split(',').map((k) => k.trim()).filter(Boolean);
      const titleMatch = lower.includes(item.title.toLowerCase());
      const keyMatch = keys.some((k) => lower.includes(k));

      if (titleMatch || keyMatch) {
        matchedAnswer = item.instruction_or_answer;
        break;
      }
    }

    if (matchedAnswer) {
      return res.json({
        reply: matchedAnswer,
        contextUsed: { knowledgeCount: items?.length || 0, eventsCount: events?.length || 0, engine: 'local_rules' },
      });
    }

    // If query asks about events
    if (lower.includes('event') || lower.includes('concert') || lower.includes('happening') || lower.includes('show')) {
      const eventList = (events || []).slice(0, 3).map((e) => `• ${e.title} at ${e.venue || e.city} (from GHS ${e.min_price})`).join('\n');
      return res.json({
        reply: `Here are some of the upcoming events right now:\n${eventList || 'No published events at the moment.'}`,
        contextUsed: { knowledgeCount: items?.length || 0, eventsCount: events?.length || 0, engine: 'local_events' },
      });
    }

    res.json({
      reply: `Hey! I can help you discover upcoming concerts, shows, and festivals, or assist with your tickets, transfers, and receipts. How can I help you today?`,
      contextUsed: { knowledgeCount: items?.length || 0, eventsCount: events?.length || 0, engine: 'local_default' },
    });
  } catch (err) {
    console.error('[adminController.testAIPrompt]', err);
    res.status(500).json({ message: 'Response test failed' });
  }
};

/* ------------------------------------------------------------------ */
/* Voice Agent Deep Learning & ML Training Management                */
/* ------------------------------------------------------------------ */

let voiceTablesInitialized = false;

export async function ensureVoiceTables() {
  if (voiceTablesInitialized) return;
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS voice_model_config (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value TEXT NOT NULL,
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    await pool.execute(`
      CREATE TABLE IF NOT EXISTS voice_pronunciation_lexicon (
        id BIGSERIAL PRIMARY KEY,
        heard VARCHAR(255) NOT NULL,
        replacement VARCHAR(255) NOT NULL,
        category VARCHAR(100) DEFAULT 'general',
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    await pool.execute(`
      CREATE TABLE IF NOT EXISTS voice_training_samples (
        id BIGSERIAL PRIMARY KEY,
        text TEXT NOT NULL,
        intent VARCHAR(100) NOT NULL,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Seed default phonetic lexicon if empty
    const [lexRows] = await pool.execute(`SELECT COUNT(*) AS total FROM voice_pronunciation_lexicon`);
    const lexTotal = parseInt(lexRows?.[0]?.total || 0, 10);
    if (lexTotal === 0) {
      for (const item of DEFAULT_PHONETIC_LEXICON) {
        await pool.execute(
          `INSERT INTO voice_pronunciation_lexicon (heard, replacement, category, is_active)
           VALUES (?, ?, ?, TRUE)`,
          [item.heard, item.replacement, item.category || 'general']
        );
      }
    }

    // Seed default voice training samples if empty
    const [sampleRows] = await pool.execute(`SELECT COUNT(*) AS total FROM voice_training_samples`);
    const sampleTotal = parseInt(sampleRows?.[0]?.total || 0, 10);
    if (sampleTotal === 0) {
      for (const s of DEFAULT_TRAINING_SAMPLES) {
        await pool.execute(
          `INSERT INTO voice_training_samples (text, intent, is_active)
           VALUES (?, ?, TRUE)`,
          [s.text, s.intent]
        );
      }
    }

    voiceTablesInitialized = true;
  } catch (err) {
    console.error('[ensureVoiceTables] error:', err.message);
  }
}

export const getVoiceModelData = async (_req, res) => {
  try {
    await ensureVoiceTables();

    const [lexicon] = await pool.execute(
      `SELECT * FROM voice_pronunciation_lexicon ORDER BY id DESC`
    );

    const [samples] = await pool.execute(
      `SELECT * FROM voice_training_samples ORDER BY id DESC`
    );

    const [configRows] = await pool.execute(
      `SELECT setting_key, setting_value FROM voice_model_config`
    );

    const config = {};
    for (const row of configRows || []) {
      config[row.setting_key] = row.setting_value;
    }

    res.json({
      modelMetrics: {
        version: config.voice_model_version || voiceModel.version,
        accuracy: config.voice_accuracy ? parseFloat(config.voice_accuracy) : voiceModel.accuracy,
        totalSamples: samples?.length || voiceModel.totalSamples,
        classesCount: voiceModel.classes.length,
        trainedAt: config.voice_trained_at || voiceModel.trainedAt,
        confidenceThreshold: config.voice_confidence_threshold ? parseFloat(config.voice_confidence_threshold) : 0.55,
        cadence: config.voice_cadence || 'direct_punchy',
        speechRate: config.voice_speech_rate ? parseFloat(config.voice_speech_rate) : 1.05,
        pitch: config.voice_pitch ? parseFloat(config.voice_pitch) : 1.0,
        language: config.voice_language || 'en-GH',
      },
      pronunciationLexicon: lexicon || [],
      trainingSamples: samples || [],
      classes: voiceModel.classes,
    });
  } catch (err) {
    console.error('[adminController.getVoiceModelData]', err);
    res.status(500).json({ message: 'Failed to fetch voice model data' });
  }
};

export const trainVoiceModel = async (req, res) => {
  try {
    await ensureVoiceTables();

    const [samples] = await pool.execute(
      `SELECT text, intent FROM voice_training_samples WHERE is_active = TRUE`
    );

    const dataset = (samples || []).map((s) => ({ text: s.text, intent: s.intent }));
    const result = voiceModel.train(dataset.length > 0 ? dataset : DEFAULT_TRAINING_SAMPLES);

    await pool.execute(
      `INSERT INTO voice_model_config (setting_key, setting_value, updated_at)
       VALUES ('voice_accuracy', ?, NOW())
       ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()`,
      [String(result.accuracy)]
    );

    await pool.execute(
      `INSERT INTO voice_model_config (setting_key, setting_value, updated_at)
       VALUES ('voice_trained_at', ?, NOW())
       ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()`,
      [result.trainedAt]
    );

    await pool.execute(
      `INSERT INTO voice_model_config (setting_key, setting_value, updated_at)
       VALUES ('voice_total_samples', ?, NOW())
       ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()`,
      [String(result.samplesTrained)]
    );

    await logAudit({
      userId: req.user?.id,
      action: 'train_voice_model',
      entityType: 'voice_model',
      details: result,
    });

    res.json({
      message: `Voice Agent intent model successfully retrained on ${result.samplesTrained} utterances!`,
      metrics: result,
    });
  } catch (err) {
    console.error('[adminController.trainVoiceModel]', err);
    res.status(500).json({ message: 'Failed to retrain voice agent model' });
  }
};

export const updateVoiceModelSettings = async (req, res) => {
  try {
    await ensureVoiceTables();
    const {
      confidenceThreshold = 0.55,
      cadence = 'direct_punchy',
      speechRate = 1.05,
      pitch = 1.0,
      language = 'en-GH',
    } = req.body;

    const entries = [
      ['voice_confidence_threshold', String(confidenceThreshold)],
      ['voice_cadence', String(cadence)],
      ['voice_speech_rate', String(speechRate)],
      ['voice_pitch', String(pitch)],
      ['voice_language', String(language)],
    ];

    for (const [k, v] of entries) {
      await pool.execute(
        `INSERT INTO voice_model_config (setting_key, setting_value, updated_at)
         VALUES (?, ?, NOW())
         ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = NOW()`,
        [k, v]
      );
    }

    voiceModel.confidenceThreshold = Number(confidenceThreshold) || 0.55;

    await logAudit({
      userId: req.user?.id,
      action: 'update_voice_model_settings',
      entityType: 'voice_model',
      details: { confidenceThreshold, cadence, speechRate, pitch, language },
    });

    res.json({ message: 'Voice agent hyperparameters and settings updated successfully' });
  } catch (err) {
    console.error('[adminController.updateVoiceModelSettings]', err);
    res.status(500).json({ message: 'Failed to update voice settings' });
  }
};

export const createVoicePronunciationRule = async (req, res) => {
  try {
    await ensureVoiceTables();
    const { heard, replacement, category = 'general' } = req.body;
    if (!heard || !replacement) {
      return res.status(400).json({ message: 'Heard phrase and phonetic replacement are required' });
    }

    const [result] = await pool.execute(
      `INSERT INTO voice_pronunciation_lexicon (heard, replacement, category, is_active)
       VALUES (?, ?, ?, TRUE)`,
      [heard.trim().toLowerCase(), replacement.trim(), category.trim()]
    );

    res.status(201).json({
      message: 'Pronunciation rule added',
      rule: {
        id: result.insertId,
        heard: heard.trim().toLowerCase(),
        replacement: replacement.trim(),
        category,
        is_active: true,
      },
    });
  } catch (err) {
    console.error('[adminController.createVoicePronunciationRule]', err);
    res.status(500).json({ message: 'Failed to add pronunciation rule' });
  }
};

export const deleteVoicePronunciationRule = async (req, res) => {
  try {
    await ensureVoiceTables();
    const { id } = req.params;
    await pool.execute(`DELETE FROM voice_pronunciation_lexicon WHERE id = ?`, [id]);
    res.json({ message: 'Pronunciation rule removed' });
  } catch (err) {
    console.error('[adminController.deleteVoicePronunciationRule]', err);
    res.status(500).json({ message: 'Failed to delete pronunciation rule' });
  }
};

export const createVoiceTrainingSample = async (req, res) => {
  try {
    await ensureVoiceTables();
    const { text, intent } = req.body;
    if (!text || !intent) {
      return res.status(400).json({ message: 'Utterance text and target intent are required' });
    }

    const [result] = await pool.execute(
      `INSERT INTO voice_training_samples (text, intent, is_active)
       VALUES (?, ?, TRUE)`,
      [text.trim(), intent.trim()]
    );

    // Auto-retrain in-memory model
    const [samples] = await pool.execute(
      `SELECT text, intent FROM voice_training_samples WHERE is_active = TRUE`
    );
    const updatedMetrics = voiceModel.train(samples || []);

    res.status(201).json({
      message: 'Voice training sample added and model updated',
      sample: {
        id: result.insertId,
        text: text.trim(),
        intent: intent.trim(),
        is_active: true,
      },
      metrics: updatedMetrics,
    });
  } catch (err) {
    console.error('[adminController.createVoiceTrainingSample]', err);
    res.status(500).json({ message: 'Failed to add voice training sample' });
  }
};

export const deleteVoiceTrainingSample = async (req, res) => {
  try {
    await ensureVoiceTables();
    const { id } = req.params;
    await pool.execute(`DELETE FROM voice_training_samples WHERE id = ?`, [id]);

    // Retrain in-memory model after deletion
    const [samples] = await pool.execute(
      `SELECT text, intent FROM voice_training_samples WHERE is_active = TRUE`
    );
    const updatedMetrics = voiceModel.train(samples.length > 0 ? samples : DEFAULT_TRAINING_SAMPLES);

    res.json({ message: 'Training sample removed', metrics: updatedMetrics });
  } catch (err) {
    console.error('[adminController.deleteVoiceTrainingSample]', err);
    res.status(500).json({ message: 'Failed to delete voice training sample' });
  }
};

export const testVoiceModel = async (req, res) => {
  try {
    await ensureVoiceTables();
    const { message } = req.body;
    const testUtterance = (message || '').trim();
    if (!testUtterance) {
      return res.status(400).json({ message: 'Test message or speech transcript is required' });
    }

    const [lexiconRows] = await pool.execute(
      `SELECT heard, replacement, category FROM voice_pronunciation_lexicon WHERE is_active = TRUE`
    );

    // 1. Phonetic entity correction
    const phoneticResult = correctVoicePhonetics(testUtterance, lexiconRows || []);

    // 2. Intent prediction & probability distribution
    const intentResult = voiceModel.predict(testUtterance, true, lexiconRows || []);

    // 3. Emotion / Urgency analysis
    const emotionResult = analyzeVoiceEmotion(testUtterance);

    // 4. Synthesized natural voice response preview
    let sampleReply = '';
    switch (intentResult.intent) {
      case 'BOOK_TICKETS':
        sampleReply = `I've prepared your ticket reservation for the requested event. Total is 150 Ghana Cedis. Say confirm to complete payment.`;
        break;
      case 'SEARCH_EVENTS':
        sampleReply = `I found upcoming concerts and events in Ghana matching your request. Here are the top picks for you.`;
        break;
      case 'CONFIRM_PAYMENT':
        sampleReply = `Your tickets are reserved for 10 minutes. Opening secure Mobile Money and card checkout now.`;
        break;
      case 'VERIFY_TRANSACTION':
        sampleReply = `Checking transaction status with the payment provider. Your tickets will appear in My Tickets once confirmed.`;
        break;
      case 'VIEW_MY_TICKETS':
        sampleReply = `Here are your active event tickets and digital QR passes ready for gate check-in.`;
        break;
      case 'SPENDING_ANALYTICS':
        sampleReply = `You have spent 450 Ghana Cedis across 3 events this month.`;
        break;
      case 'EVENT_SCHEDULE':
        sampleReply = `Your next event is coming up on Friday at 8 PM at Untamed Empire.`;
        break;
      case 'RESEND_TICKETS':
        sampleReply = `I've resent your digital entry pass to your verified email and phone number.`;
        break;
      case 'REFUND_DISPUTE':
        sampleReply = `If you cannot attend, you can list your ticket on our verified resale marketplace or submit an official refund request.`;
        break;
      case 'CUSTOMER_SUPPORT':
        sampleReply = `I'm connecting you with our human support desk immediately to resolve your issue.`;
        break;
      default:
        sampleReply = `Hello! Welcome to Tribes and Cliqs. What events or tickets can I help you with today?`;
    }

    const synthesizedSpeech = formatVoiceUtterance(sampleReply);

    res.json({
      rawTranscript: testUtterance,
      phoneticNormalization: {
        correctedText: phoneticResult.corrected,
        changesApplied: phoneticResult.changes,
      },
      intentClassification: {
        predictedIntent: intentResult.intent,
        confidenceScore: intentResult.confidence,
        secondBestIntent: intentResult.secondIntent,
        secondConfidence: intentResult.secondConfidence,
        isLowConfidence: intentResult.isLowConfidence,
        probabilityDistribution: intentResult.probabilities,
      },
      emotionAnalysis: emotionResult,
      synthesizedVoiceOutput: synthesizedSpeech,
      modelInfo: {
        version: voiceModel.version,
        threshold: voiceModel.confidenceThreshold,
        totalTrainedSamples: voiceModel.totalSamples,
      },
    });
  } catch (err) {
    console.error('[adminController.testVoiceModel]', err);
    res.status(500).json({ message: 'Voice model diagnostic test failed' });
  }
};

export const getBotConversations = async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
    const offset = (page - 1) * limit;
    const mode = req.query.mode || 'all';
    const search = (req.query.search || '').trim();

    const conditions = [];
    const params = [];

    if (mode && mode !== 'all') {
      conditions.push('mode = ?');
      params.push(mode);
    }

    if (search) {
      conditions.push('(question ILIKE ? OR answer ILIKE ? OR user_name ILIKE ? OR user_email ILIKE ? OR intent ILIKE ?)');
      const wildcard = `%${search}%`;
      params.push(wildcard, wildcard, wildcard, wildcard, wildcard);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const [[countRow]] = await pool.execute(
      `SELECT COUNT(*) AS total FROM bot_conversations ${whereClause}`,
      params
    );
    const total = parseInt(countRow?.total, 10) || 0;

    const [rows] = await pool.execute(
      `SELECT * FROM bot_conversations ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    const [[statsRow]] = await pool.execute(`
      SELECT 
        COUNT(*) AS total_conversations,
        COUNT(CASE WHEN DATE(created_at) = CURRENT_DATE THEN 1 END) AS today_count,
        COUNT(CASE WHEN mode = 'chat' THEN 1 END) AS chat_count,
        COUNT(CASE WHEN mode = 'voice' THEN 1 END) AS voice_count
      FROM bot_conversations
    `);

    res.json({
      conversations: rows || [],
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit) || 1,
      },
      stats: {
        totalConversations: parseInt(statsRow?.total_conversations, 10) || 0,
        todayCount: parseInt(statsRow?.today_count, 10) || 0,
        chatCount: parseInt(statsRow?.chat_count, 10) || 0,
        voiceCount: parseInt(statsRow?.voice_count, 10) || 0,
      },
    });
  } catch (err) {
    console.error('[adminController.getBotConversations]', err);
    res.status(500).json({ message: 'Failed to retrieve bot conversation logs' });
  }
};

export const deleteBotConversation = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute(`DELETE FROM bot_conversations WHERE id = ?`, [id]);
    res.json({ message: 'Conversation record deleted successfully' });
  } catch (err) {
    console.error('[adminController.deleteBotConversation]', err);
    res.status(500).json({ message: 'Failed to delete bot conversation record' });
  }
};

/* ------------------------------------------------------------------ */
/* Mobile App Management                                              */
/* ------------------------------------------------------------------ */

export const ensureMobileTables = async () => {
  await pool.execute(`
    CREATE TABLE IF NOT EXISTS mobile_app_banners (
      id BIGSERIAL PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      subtitle VARCHAR(255),
      image_url VARCHAR(500) NOT NULL,
      link_type VARCHAR(50) DEFAULT 'none',
      link_target VARCHAR(255) DEFAULT '',
      is_active BOOLEAN DEFAULT TRUE,
      sort_order INT DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
  `);
};

export const getMobileAppConfig = async (req, res) => {
  try {
    await ensureMobileTables();

    const [settingRows] = await pool.execute(
      `SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE 'mobile_%'`
    );
    const settingsMap = {};
    for (const r of settingRows) {
      settingsMap[r.setting_key] = r.setting_value;
    }

    const [banners] = await pool.execute(
      `SELECT * FROM mobile_app_banners ORDER BY sort_order ASC, id DESC`
    );

    const [eventRows] = await pool.execute(
      `SELECT id, title, start_date, venue, city, banner_image FROM events WHERE status = 'published' ORDER BY start_date ASC LIMIT 30`
    );

    res.json({
      settings: {
        maintenance_mode: settingsMap['mobile_maintenance_mode'] === 'true',
        maintenance_message: settingsMap['mobile_maintenance_message'] || 'We are currently performing scheduled maintenance on the mobile app. Please check back shortly.',
        min_version: settingsMap['mobile_min_version'] || '1.0.0',
        support_email: settingsMap['mobile_support_email'] || 'support@tribesandcliqs.com',
        support_phone: settingsMap['mobile_support_phone'] || '+233 55 123 4567',
        announcement_enabled: settingsMap['mobile_announcement_enabled'] === 'true',
        announcement_text: settingsMap['mobile_announcement_text'] || '',
        announcement_type: settingsMap['mobile_announcement_type'] || 'info',
        announcement_link: settingsMap['mobile_announcement_link'] || '',
      },
      banners: banners || [],
      availableEvents: eventRows || [],
    });
  } catch (err) {
    console.error('[adminController.getMobileAppConfig]', err);
    res.status(500).json({ message: 'Failed to retrieve mobile app configuration' });
  }
};

export const updateMobileAppSettings = async (req, res) => {
  try {
    const {
      maintenance_mode,
      maintenance_message,
      min_version,
      support_email,
      support_phone,
      announcement_enabled,
      announcement_text,
      announcement_type,
      announcement_link,
    } = req.body;

    const updates = [
      ['mobile_maintenance_mode', maintenance_mode ? 'true' : 'false'],
      ['mobile_maintenance_message', String(maintenance_message || '').trim()],
      ['mobile_min_version', String(min_version || '1.0.0').trim()],
      ['mobile_support_email', String(support_email || '').trim()],
      ['mobile_support_phone', String(support_phone || '').trim()],
      ['mobile_announcement_enabled', announcement_enabled ? 'true' : 'false'],
      ['mobile_announcement_text', String(announcement_text || '').trim()],
      ['mobile_announcement_type', String(announcement_type || 'info').trim()],
      ['mobile_announcement_link', String(announcement_link || '').trim()],
    ];

    for (const [key, value] of updates) {
      await pool.execute(
        `INSERT INTO system_settings (setting_key, setting_value)
         VALUES (?, ?)
         ON CONFLICT (setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value`,
        [key, value]
      );
    }

    clearSettingsCache();
    await logAudit({
      userId: req.user.id,
      action: 'update_mobile_app_settings',
      entityType: 'system_settings',
      details: { maintenance_mode, announcement_enabled },
    });

    res.json({ message: 'Mobile app settings updated successfully' });
  } catch (err) {
    console.error('[adminController.updateMobileAppSettings]', err);
    res.status(500).json({ message: 'Failed to update mobile app settings' });
  }
};

export const createMobileAppBanner = async (req, res) => {
  try {
    await ensureMobileTables();
    const {
      title,
      subtitle = '',
      image_url,
      link_type = 'none',
      link_target = '',
      is_active = true,
      sort_order = 0,
    } = req.body;

    if (!title || !image_url) {
      return res.status(400).json({ message: 'Banner title and image URL are required' });
    }

    const [result] = await pool.execute(
      `INSERT INTO mobile_app_banners (title, subtitle, image_url, link_type, link_target, is_active, sort_order)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       RETURNING *`,
      [title.trim(), subtitle.trim(), image_url.trim(), link_type, link_target.trim(), Boolean(is_active), Number(sort_order) || 0]
    );

    const newBanner = result[0];
    await logAudit({
      userId: req.user.id,
      action: 'create_mobile_banner',
      entityType: 'mobile_app_banners',
      entityId: newBanner?.id,
      details: { title },
    });

    res.status(201).json({ message: 'Mobile banner created successfully', banner: newBanner });
  } catch (err) {
    console.error('[adminController.createMobileAppBanner]', err);
    res.status(500).json({ message: 'Failed to create mobile banner' });
  }
};

export const updateMobileAppBanner = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      subtitle,
      image_url,
      link_type,
      link_target,
      is_active,
      sort_order,
    } = req.body;

    const [existing] = await pool.execute(`SELECT * FROM mobile_app_banners WHERE id = ?`, [id]);
    if (!existing || existing.length === 0) {
      return res.status(404).json({ message: 'Banner not found' });
    }

    const current = existing[0];
    const newTitle = title !== undefined ? String(title).trim() : current.title;
    const newSubtitle = subtitle !== undefined ? String(subtitle).trim() : current.subtitle;
    const newImageUrl = image_url !== undefined ? String(image_url).trim() : current.image_url;
    const newLinkType = link_type !== undefined ? link_type : current.link_type;
    const newLinkTarget = link_target !== undefined ? String(link_target).trim() : current.link_target;
    const newIsActive = is_active !== undefined ? Boolean(is_active) : current.is_active;
    const newSortOrder = sort_order !== undefined ? Number(sort_order) : current.sort_order;

    await pool.execute(
      `UPDATE mobile_app_banners
       SET title = ?, subtitle = ?, image_url = ?, link_type = ?, link_target = ?, is_active = ?, sort_order = ?, updated_at = NOW()
       WHERE id = ?`,
      [newTitle, newSubtitle, newImageUrl, newLinkType, newLinkTarget, newIsActive, newSortOrder, id]
    );

    await logAudit({
      userId: req.user.id,
      action: 'update_mobile_banner',
      entityType: 'mobile_app_banners',
      entityId: id,
      details: { title: newTitle, is_active: newIsActive },
    });

    res.json({ message: 'Banner updated successfully' });
  } catch (err) {
    console.error('[adminController.updateMobileAppBanner]', err);
    res.status(500).json({ message: 'Failed to update mobile banner' });
  }
};

export const deleteMobileAppBanner = async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute(`DELETE FROM mobile_app_banners WHERE id = ?`, [id]);
    await logAudit({
      userId: req.user.id,
      action: 'delete_mobile_banner',
      entityType: 'mobile_app_banners',
      entityId: id,
    });
    res.json({ message: 'Banner deleted successfully' });
  } catch (err) {
    console.error('[adminController.deleteMobileAppBanner]', err);
    res.status(500).json({ message: 'Failed to delete mobile banner' });
  }
};

export const getPublicMobileConfig = async (req, res) => {
  try {
    await ensureMobileTables();

    const [settingRows] = await pool.execute(
      `SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE 'mobile_%'`
    );
    const settingsMap = {};
    for (const r of settingRows) {
      settingsMap[r.setting_key] = r.setting_value;
    }

    const [banners] = await pool.execute(
      `SELECT id, title, subtitle, image_url, link_type, link_target, sort_order
       FROM mobile_app_banners
       WHERE is_active = TRUE
       ORDER BY sort_order ASC, id DESC`
    );

    res.json({
      maintenance: {
        enabled: settingsMap['mobile_maintenance_mode'] === 'true',
        message: settingsMap['mobile_maintenance_message'] || 'We are currently performing scheduled maintenance on the mobile app. Please check back shortly.',
        minVersion: settingsMap['mobile_min_version'] || '1.0.0',
        supportEmail: settingsMap['mobile_support_email'] || 'support@tribesandcliqs.com',
        supportPhone: settingsMap['mobile_support_phone'] || '+233 55 123 4567',
      },
      announcement: {
        enabled: settingsMap['mobile_announcement_enabled'] === 'true',
        text: settingsMap['mobile_announcement_text'] || '',
        type: settingsMap['mobile_announcement_type'] || 'info',
        link: settingsMap['mobile_announcement_link'] || '',
      },
      banners: banners || [],
    });
  } catch (err) {
    console.error('[adminController.getPublicMobileConfig]', err);
    res.json({
      maintenance: { enabled: false, message: '', minVersion: '1.0.0' },
      announcement: { enabled: false, text: '', type: 'info' },
      banners: [],
    });
  }
};

export default {
  getDashboardStats, getUsers, getUser, updateUser, suspendUser, unsuspendUser, verifyUser, deleteUser, approveOrganizer, rejectOrganizer, resetUserPassword, createAdminUser,
  getUserManagementStats, getUserActivity, getUserSessions, getUserStats, forceLogoutUser, addAdminNote, getAdminNotes, deleteAdminNote, exportUsers, bulkRoleChange, bulkDeleteUsers,
  getEvents, approveEvent, rejectEvent, requestEventChanges, featureEvent, suspendEvent, unsuspendEvent, adminDeleteEvent,
  getCategories, createCategory, updateCategory, deleteCategory,
  getPayments, getPayment, refundPayment, processUnresponsiveRefunds, getWithdrawals, approveWithdrawal, rejectWithdrawal,
  getReports, getRevenueReport, getGrowthReport,
  getSupportTickets, getSupportTicket, respondToSupportTicket, closeSupportTicket, resolveSupportTicket,
  sendAnnouncement, getAdminAnnouncements, getNotificationTemplates, getAdminNotifications, markAdminNotificationsRead, deleteAdminNotification, getAuditLogs, getSystemSettings, updateSystemSettings,
  getContentPages, createContentPage, updateContentPage, deleteContentPage,
  getAITrainingData, createAIKnowledgeItem, updateAIKnowledgeItem, deleteAIKnowledgeItem, updateAISettings, testAIPrompt,
  getVoiceModelData, trainVoiceModel, updateVoiceModelSettings, createVoicePronunciationRule, deleteVoicePronunciationRule, createVoiceTrainingSample, deleteVoiceTrainingSample, testVoiceModel,
  getBotConversations, deleteBotConversation,
  getMobileAppConfig, updateMobileAppSettings, createMobileAppBanner, updateMobileAppBanner, deleteMobileAppBanner, getPublicMobileConfig,
};

