import{j as t,aG as Q,aF as ae,w as le,K as re,y as de,a9 as ce,aJ as xe,aI as fe,bt as pe,R as me}from"./vendor-react-kjnsrEhy.js";import{z as ie}from"./vendor-utils-D3rtD2hg.js";const oe=(s,d=300)=>{try{let x=pe.renderToStaticMarkup(me.createElement(Q,{value:String(s),size:d,level:"H",includeMargin:!1,xmlns:"http://www.w3.org/2000/svg"}));return x.includes("xmlns=")||(x=x.replace("<svg ",'<svg xmlns="http://www.w3.org/2000/svg" ')),x}catch{return null}},ne=async(s,d,x,g,v)=>{const S=oe(d,v);if(!S)return!1;try{const b=S.match(/viewBox="0 0 (\d+) (\d+)"/),u=b?parseInt(b[1],10):41,h=S.match(/fill="#000000" d="([^"]+)"/);if(typeof Path2D<"u"&&h&&h[1]){const p=h[1],w=v/u;return s.save(),s.translate(x,g),s.scale(w,w),s.fillStyle="#000000",s.fill(new Path2D(p)),s.restore(),!0}}catch{}try{const b="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(S);return await new Promise(u=>{const h=new Image;h.onload=()=>{s.drawImage(h,x,g,v,v),u()},h.onerror=p=>{u()},h.src=b}),!0}catch{return!1}},J=s=>{if(!s)return"VALID PASS";const d=s.unitPrice??s.unit_price??s.ticket_price??s.ticketPrice??s.price;if(d!=null&&d!==""){const x=Number(d);if(!isNaN(x))return x<=0?"FREE PASS":`GHS ${x.toFixed(2).replace(/\.00$/,"")}`}if(s.amount&&(s.quantity===1||!s.quantity)){const x=Number(s.amount);if(!isNaN(x)&&x>0)return`GHS ${x.toFixed(2).replace(/\.00$/,"")}`}return"VALID PASS"},K=s=>s?(s.ticketType||s.ticket_type_name||s.ticketTypeName||s.type||s.name||"STANDARD ADMISSION").toString().toUpperCase():"STANDARD ADMISSION",Z=s=>s?(s.ticketNumber||s.ticket_number||s.ticketCode||s.ticket_code||(s.id?`TC-${s.id}`:"TC-00000000")).toString().toUpperCase():"TC-00000000",ee=s=>s?(s.attendeeName||s.attendee_name||s.userName||s.user_name||s.user?.name||"ATTENDEE").toString().toUpperCase():"ATTENDEE",te=s=>{if(!s)return"DATE TBA";try{return new Date(s).toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric",year:"numeric"}).toUpperCase()}catch{return String(s).toUpperCase()}},be=async s=>{try{const d=s.event||{},x=(d.title||s.eventName||"LIVE CONCERT EVENT").toUpperCase(),g=te(d.startDate||s.startDate||s.eventDate),v=(d.startTime||s.startTime||"7:00 PM - 11:00 PM").toUpperCase(),S=(d.venue||s.venue||"ACCRA, GHANA").toUpperCase(),b=(d.city||s.city||"ACCRA").toUpperCase(),u=K(s),h=J(s),p=Z(s),w=s.seat||s.seatNumber||"GA",F=s.row||(w.includes("-")?w.split("-")[0]:"AAA"),A=ee(s),k=s.ticketTemplate||d.ticketTemplate||s.ticket_template||d.ticket_template,$=typeof window<"u"&&window.location?.origin?window.location.origin:"https://tribesandcliqs.com",O=s.qrCode||s.qr_code||`${$}/verify/${encodeURIComponent(p)}`,y=document.createElement("canvas");y.width=1600,y.height=680;const e=y.getContext("2d");e.imageSmoothingEnabled=!0,e.imageSmoothingQuality="high",e.fillStyle="#0F1215",e.fillRect(0,0,1600,680);const r=30,a=30,N=1540,m=580,G=24,C=(l,n,o,c,i)=>{e.beginPath(),e.moveTo(l+i,n),e.lineTo(l+o-i,n),e.quadraticCurveTo(l+o,n,l+o,n+i),e.lineTo(l+o,n+c-i),e.quadraticCurveTo(l+o,n+c,l+o-i,n+c),e.lineTo(l+i,n+c),e.quadraticCurveTo(l,n+c,l,n+c-i),e.lineTo(l,n+i),e.quadraticCurveTo(l,n,l+i,n),e.closePath()};let _=null;if(k)try{_=await new Promise(l=>{const n=new Image;n.crossOrigin="anonymous",n.onload=()=>l(n),n.onerror=()=>l(null),n.src=k})}catch{_=null}if(e.save(),C(r,a,N,m,G),e.clip(),_){e.drawImage(_,r,a,N,m);const l=e.createLinearGradient(r,a,r+N,a);l.addColorStop(0,"rgba(15, 18, 21, 0.92)"),l.addColorStop(.24,"rgba(15, 18, 21, 0.75)"),l.addColorStop(.32,"rgba(15, 18, 21, 0.2)"),l.addColorStop(.7,"rgba(15, 18, 21, 0.2)"),l.addColorStop(.78,"rgba(15, 18, 21, 0.75)"),l.addColorStop(1,"rgba(15, 18, 21, 0.95)"),e.fillStyle=l,e.fillRect(r,a,N,m);const n=380,o=r+N-n;e.setLineDash([12,10]),e.strokeStyle="rgba(255, 255, 255, 0.5)",e.lineWidth=3,e.beginPath(),e.moveTo(o,a),e.lineTo(o,a+m),e.stroke();const i=r+340;e.beginPath(),e.moveTo(i,a),e.lineTo(i,a+m),e.stroke(),e.setLineDash([]),e.fillStyle="#0F1215",e.beginPath(),e.arc(o,a,24,0,Math.PI*2),e.fill(),e.beginPath(),e.arc(o,a+m,24,0,Math.PI*2),e.fill(),e.beginPath(),e.arc(r,a+m/2,24,0,Math.PI*2),e.fill(),e.beginPath(),e.arc(r+N,a+m/2,24,0,Math.PI*2),e.fill();const X=r+45,f=a+45,M=250;e.fillStyle="#FFFFFF",C(X,f,M,M,16),e.fill(),await ne(e,O,X+15,f+15,M-30),e.textAlign="left",e.fillStyle="#E5A93C",e.font='bold 18px "Inter", Arial, sans-serif',e.fillText("ROW",r+85,a+345),e.fillText("SEAT",r+215,a+345),e.fillStyle="#FFFFFF",e.font='900 38px "Inter", Arial, sans-serif',e.fillText(F,r+85,a+395),e.fillText(w,r+215,a+395),e.font='bold 16px "Inter", Arial, monospace',e.fillStyle="#F5C862",e.fillText(`#${p}`,r+75,a+460),e.font='bold 15px "Inter", Arial, sans-serif',e.fillStyle="#EFEFF1",e.fillText(A,r+75,a+490),e.textAlign="center",e.font='bold 16px "Inter", Arial, sans-serif',e.fillStyle="#F5C862",e.fillText("🌐 WWW.TRIBESANDCLIQS.COM",i+(o-i)/2,a+55),e.font='900 50px "Inter", Arial, sans-serif',e.fillStyle="#FFFFFF";const Y=o-i-80,R=x.split(" ");let B="",I=a+140;for(let j=0;j<R.length;j++){const z=B+R[j]+" ";e.measureText(z).width>Y&&j>0?(e.fillText(B,i+(o-i)/2,I),B=R[j]+" ",I+=58):B=z}e.fillText(B,i+(o-i)/2,I),e.fillStyle="#E5A93C";const P=280,U=44,L=i+(o-i)/2-P/2,W=I+25;C(L,W,P,U,22),e.fill(),e.font='900 20px "Inter", Arial, sans-serif',e.fillStyle="#160F06",e.fillText(`✦ ${u} ✦`,i+(o-i)/2,W+29);const q=W+75;e.textAlign="left",e.fillStyle="#F5C862",e.font='bold 22px "Inter", Arial, sans-serif',e.fillText("📅 "+g,i+60,q),e.fillStyle="#EFEFF1",e.font='bold 20px "Inter", Arial, sans-serif',e.fillText("⏰ "+v,i+60,q+38),e.fillText("📍 "+S+(b?`, ${b}`:""),i+60,q+76),e.textAlign="center";const E=o+n/2;e.font='900 22px "Inter", Arial, sans-serif',e.fillStyle="#F5C862",e.fillText("★ ADMISSION PASS ★",E,a+80),e.font='bold 18px "Inter", Arial, sans-serif',e.fillStyle="#E5A93C",e.fillText("TIER & PRICING",E,a+160),e.font='900 32px "Inter", Arial, sans-serif',e.fillStyle="#FFFFFF",e.fillText(u.slice(0,16),E,a+220),e.font='900 54px "Inter", Arial, sans-serif',e.fillStyle="#F5C862",e.fillText(h,E,a+290),e.font='bold 16px "Inter", Arial, sans-serif',e.fillStyle="#FFFFFF",e.fillText("OFFICIAL DIGITAL PASS",E,a+390),e.font='bold 14px "Inter", Arial, monospace',e.fillStyle="#F5C862",e.fillText(p,E,a+425);const H=a+460;e.fillStyle="#FFFFFF";const D=[4,8,3,12,4,16,6,8,4,14,8,4,10,6,12,4,8,14,4];let V=o+50;for(const j of D)e.fillRect(V,H,j,45),V+=j+8}else{const l=e.createLinearGradient(r,a,r+N*.75,a+m);l.addColorStop(0,"#E5A93C"),l.addColorStop(.35,"#F5C862"),l.addColorStop(.7,"#E5A93C"),l.addColorStop(1,"#C98B28"),e.fillStyle=l,e.fill();const n=e.createRadialGradient(800,280,50,800,280,550);n.addColorStop(0,"rgba(255, 245, 200, 0.45)"),n.addColorStop(.5,"rgba(255, 215, 120, 0.15)"),n.addColorStop(1,"rgba(0, 0, 0, 0)"),e.fillStyle=n,e.fillRect(r,a,N,m),e.strokeStyle="rgba(120, 40, 10, 0.18)",e.lineWidth=14,e.beginPath(),e.arc(520,260,190,0,Math.PI*2),e.stroke(),e.lineWidth=8,e.beginPath(),e.arc(520,260,140,0,Math.PI*2),e.stroke(),e.lineWidth=4,e.beginPath(),e.arc(520,260,80,0,Math.PI*2),e.stroke();const o=380,c=r+N-o,i=e.createLinearGradient(c,a,c+o,a+m);i.addColorStop(0,"#6B0F24"),i.addColorStop(.5,"#7F132C"),i.addColorStop(1,"#500B1B"),e.fillStyle=i,e.fillRect(c,a,o,m),e.setLineDash([12,10]),e.strokeStyle="rgba(255, 255, 255, 0.45)",e.lineWidth=3,e.beginPath(),e.moveTo(c,a),e.lineTo(c,a+m),e.stroke(),e.setLineDash([]),e.fillStyle="#0F1215",e.beginPath(),e.arc(c,a,26,0,Math.PI*2),e.fill(),e.beginPath(),e.arc(c,a+m,26,0,Math.PI*2),e.fill();const f=r+340;e.beginPath(),e.arc(r,a+m/2,26,0,Math.PI*2),e.fill(),e.beginPath(),e.arc(r+N,a+m/2,26,0,Math.PI*2),e.fill(),e.beginPath(),e.setLineDash([10,8]),e.strokeStyle="rgba(80, 40, 10, 0.35)",e.lineWidth=2.5,e.beginPath(),e.moveTo(f,a+20),e.lineTo(f,a+m-20),e.stroke(),e.setLineDash([]);const M=r+45,Y=a+45,R=250;e.fillStyle="#FFFFFF",C(M,Y,R,R,16),e.fill(),await ne(e,O,M+15,Y+15,R-30),e.font='bold 18px "Inter", Arial, sans-serif',e.fillText("ROW",r+85,a+345),e.fillText("SEAT",r+215,a+345),e.font='900 38px "Inter", Arial, sans-serif',e.fillText(F,r+85,a+395),e.fillText(w,r+215,a+395),e.font='bold 16px "Inter", Arial, monospace',e.fillStyle="#3D2A0F",e.fillText(`#${p}`,r+75,a+460),e.font='bold 15px "Inter", Arial, sans-serif',e.fillStyle="#1A1208",e.fillText(A,r+75,a+490),e.font='bold 16px "Inter", Arial, sans-serif',e.fillStyle="#1C150A",e.textAlign="center",e.fillText("🌐 WWW.TRIBESANDCLIQS.COM",f+(c-f)/2,a+55),e.font='900 52px "Inter", Arial, sans-serif',e.fillStyle="#160F06";const B=c-f-80,I=x.split(" ");let P="",U=a+140;for(let T=0;T<I.length;T++){const se=P+I[T]+" ";e.measureText(se).width>B&&T>0?(e.fillText(P,f+(c-f)/2,U),P=I[T]+" ",U+=56):P=se}e.fillText(P,f+(c-f)/2,U);const L=U+50;e.font='bold 18px "Inter", Arial, sans-serif',e.fillStyle="#6B0F24",e.fillText(`🗓 ${g}`,f+(c-f)/2,L),e.font='bold 17px "Inter", Arial, sans-serif',e.fillStyle="#4A2A08",e.fillText(`⏰ ${v}`,f+(c-f)/2,L+34),e.font='bold 17px "Inter", Arial, sans-serif',e.fillStyle="#301A04",e.fillText(`📍 ${S}${b?`, ${b}`:""}`,f+(c-f)/2,L+68);const W=220,q=44,E=f+(c-f-W)/2,H=L-110;e.fillStyle="#6B0F24",C(E,H,W,q,22),e.fill(),e.fillStyle="#FFFFFF",e.font='900 18px "Inter", Arial, sans-serif',e.fillText(`✦ ${u} ✦`,f+(c-f)/2,H+29);const D=c+o/2;e.textAlign="center",e.fillStyle="#F5C862",e.font='900 18px "Inter", Arial, sans-serif',e.fillText("★ ADMISSION PASS ★",D,a+70),e.font='bold 12px "Inter", Arial, sans-serif',e.fillStyle="rgba(255, 235, 200, 0.85)",e.fillText("TIER & PRICING",D,a+140),e.font='900 24px "Inter", Arial, sans-serif',e.fillStyle="#FFFFFF",e.fillText(u,D,a+180),e.font='900 46px "Inter", Arial, sans-serif',e.fillStyle="#F5C862",e.fillText(h,D,a+260),e.font='900 14px "Inter", Arial, sans-serif',e.fillStyle="rgba(255, 255, 255, 0.9)",e.fillText("OFFICIAL DIGITAL PASS",D,a+390),e.font='bold 14px "Inter", Arial, monospace',e.fillStyle="#F5C862",e.fillText(p,D,a+425);const V=a+460;e.fillStyle="#FFFFFF";const j=[4,8,3,12,4,16,6,8,4,14,8,4,10,6,12,4,8,14,4];let z=c+50;for(const T of j)e.fillRect(z,V,T,45),z+=T+8}e.restore(),e.textAlign="center",e.font='bold 15px "Inter", Arial, sans-serif',e.fillStyle="#E5A93C",e.fillText("✔ SECURE YOUR SEAT   |   NON-REFUNDABLE   |   ★ GOOD MUSIC • GOOD VIBES • GOOD PEOPLE",800,645),y.toBlob(l=>{if(!l)throw new Error("Canvas export failed");const n=URL.createObjectURL(l),o=document.createElement("a");o.href=n,o.download=`ticket-${p.slice(-8)}.png`,document.body.appendChild(o),o.click(),o.remove(),URL.revokeObjectURL(n),ie.success("Ticket downloaded successfully!")},"image/png")}catch{ie.error("Could not generate ticket image. Opening print view.")}},he=s=>{if(typeof window>"u")return;const d=s.event||{},x=(d.title||s.eventName||"Live Concert Event").toUpperCase(),g=te(d.startDate||s.startDate||s.eventDate),v=(d.startTime||s.startTime||"7:00 PM - 11:00 PM").toUpperCase(),S=(d.venue||s.venue||"Accra, Ghana").toUpperCase(),b=(d.city||s.city||"Accra").toUpperCase(),u=K(s),h=J(s),p=Z(s),w=s.seat||s.seatNumber||"GA",F=s.row||(w.includes("-")?w.split("-")[0]:"AAA"),A=ee(s),k=typeof window<"u"&&window.location?.origin?window.location.origin:"https://tribesandcliqs.com",$=s.qrCode||s.qr_code||`${k}/verify/${encodeURIComponent(p)}`,O=oe($,200),y=window.open("","_blank","width=920,height=720");if(!y){window.print();return}y.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>Ticket Pass #${p.slice(-8)} - ${x}</title>
        <style>
          @page {
            size: landscape;
            margin: 10mm;
          }
          * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: #ffffff;
            margin: 0;
            padding: 24px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
          }
          .ticket-wrapper {
            width: 100%;
            max-width: 860px;
            border-radius: 20px;
            background: #0F1215;
            padding: 14px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
          }
          .ticket-card {
            display: flex;
            border-radius: 16px;
            overflow: hidden;
            background: linear-gradient(135deg, #D49A32, #F3C760, #D49A32);
            color: #171007;
          }
          .stub-left {
            width: 250px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            border-right: 2px dashed rgba(80,40,10,0.4);
            background: rgba(232, 175, 62, 0.35);
          }
          .qr-box {
            width: 170px;
            height: 170px;
            background: #ffffff;
            border-radius: 12px;
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
          }
          .qr-box svg {
            width: 100%;
            height: 100%;
          }
          .seat-box {
            display: flex;
            width: 100%;
            justify-content: space-around;
            text-align: center;
            background: rgba(0,0,0,0.1);
            border-radius: 10px;
            padding: 8px 4px;
            margin-top: 12px;
          }
          .seat-col p { margin: 0; }
          .seat-label { font-size: 10px; font-weight: 800; color: #6B0F24; text-transform: uppercase; }
          .seat-val { font-size: 18px; font-weight: 900; color: #1A1208; }
          .serial { font-family: monospace; font-size: 11px; font-weight: bold; margin-top: 8px; color: #3D2A0F; }
          .attendee { font-size: 12px; font-weight: bold; color: #1A1208; }
          .center-body {
            flex: 1;
            padding: 24px 28px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
          }
          .domain { font-size: 11px; font-weight: 900; letter-spacing: 1.5px; color: #1C150A; }
          .badge {
            background: #6B0F24;
            color: #ffffff;
            font-size: 10px;
            font-weight: 900;
            padding: 4px 12px;
            border-radius: 9999px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .event-title {
            font-size: 26px;
            font-weight: 900;
            margin: 14px 0;
            color: #160F06;
            line-height: 1.2;
          }
          .meta-row { font-size: 13px; font-weight: 800; margin-bottom: 6px; display: flex; align-items: center; gap: 6px; }
          .meta-date { color: #6B0F24; }
          .meta-other { color: #502A0B; }
          .stub-right {
            width: 220px;
            padding: 20px;
            background: linear-gradient(135deg, #6B0F24, #7F132C, #500B1B);
            color: #ffffff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            border-left: 2px dashed rgba(255,255,255,0.3);
            text-align: center;
          }
          .pass-tag { font-size: 11px; font-weight: 900; letter-spacing: 1.5px; color: #F5C862; }
          .price-large { font-size: 24px; font-weight: 900; color: #F5C862; margin: 10px 0 4px; }
          .barcode { display: flex; justify-content: center; gap: 3px; margin-top: 10px; opacity: 0.85; }
          .bar { background: #ffffff; height: 32px; border-radius: 1px; }
          .bottom-slogan {
            text-align: center;
            font-size: 10px;
            font-weight: 800;
            color: #E5A93C;
            margin-top: 8px;
            letter-spacing: 0.5px;
          }
        </style>
      </head>
      <body>
        <div class="ticket-wrapper">
          <div class="ticket-card">
            <!-- Left QR Stub -->
            <div class="stub-left">
              <div class="qr-box">
                ${O||""}
              </div>
              <div class="seat-box">
                <div class="seat-col">
                  <p class="seat-label">Row</p>
                  <p class="seat-val">${F}</p>
                </div>
                <div class="seat-col">
                  <p class="seat-label">Seat</p>
                  <p class="seat-val">${w}</p>
                </div>
              </div>
              <div class="serial">#${p.slice(-8)}</div>
              <div class="attendee">${A}</div>
            </div>

            <!-- Center Stage Details -->
            <div class="center-body">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <span class="domain">WWW.TRIBESANDCLIQS.COM</span>
                <span class="badge">${u}</span>
              </div>
              <div class="event-title">${x}</div>
              <div>
                <div class="meta-row meta-date">📅 ${g}</div>
                <div class="meta-row meta-other">⏰ ${v}</div>
                <div class="meta-row meta-other">📍 ${S}${b?", "+b:""}</div>
              </div>
            </div>

            <!-- Right Stub -->
            <div class="stub-right">
              <div>
                <div class="pass-tag">★ ADMISSION PASS ★</div>
                <div style="font-size: 10px; opacity: 0.7; margin-top: 4px; text-transform: uppercase;">Tier &amp; Pricing</div>
                <div style="font-size: 13px; font-weight: bold; margin-top: 2px;">${u}</div>
              </div>
              <div>
                <div class="price-large">${h}</div>
                <div style="font-size: 10px; font-family: monospace; opacity: 0.8;">#${p.slice(-8)}</div>
              </div>
              <div class="barcode">
                <div class="bar" style="width: 4px;"></div>
                <div class="bar" style="width: 8px;"></div>
                <div class="bar" style="width: 3px;"></div>
                <div class="bar" style="width: 10px;"></div>
                <div class="bar" style="width: 4px;"></div>
                <div class="bar" style="width: 12px;"></div>
                <div class="bar" style="width: 6px;"></div>
                <div class="bar" style="width: 8px;"></div>
                <div class="bar" style="width: 4px;"></div>
                <div class="bar" style="width: 14px;"></div>
                <div class="bar" style="width: 8px;"></div>
              </div>
            </div>
          </div>
          <div class="bottom-slogan">
            ✔ SECURE YOUR SEAT &nbsp;|&nbsp; NON-REFUNDABLE &nbsp;|&nbsp; ★ GOOD MUSIC • GOOD VIBES • GOOD PEOPLE
          </div>
        </div>
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        <\/script>
      </body>
    </html>
  `),y.document.close()};function ve({ticket:s,onDownload:d,onPrint:x}){const g=s.event||{},v=g.title||s.eventName||"Live Concert Event",S=te(g.startDate||s.startDate||s.eventDate),b=g.startTime||s.startTime||"7:00 PM - 11:00 PM",u=g.venue||s.venue||"Accra, Ghana",h=g.city||s.city||"Accra",p=K(s),w=J(s),F=Z(s),A=s.seat||s.seatNumber||"GA",k=s.row||(A.includes("-")?A.split("-")[0]:"AAA"),$=ee(s),O=s.ticketTemplate||g.ticketTemplate||s.ticket_template||g.ticket_template,y=s.ticket_file_url||s.ticketFileUrl,e=s.ticket_file_name||s.ticketFileName,r=typeof window<"u"&&window.location?.origin?window.location.origin:"https://tribesandcliqs.com",a=s.qrCode||s.qr_code||`${r}/verify/${encodeURIComponent(F)}`,N=()=>{d?d():be(s)},m=()=>{x?x():he(s)};return t.jsxs("div",{className:"w-full max-w-4xl mx-auto space-y-4",children:[t.jsx("div",{className:"hidden",children:t.jsx(Q,{id:`ticket-qr-${s.id||"export"}`,value:a,size:256,level:"H",includeMargin:!1})}),t.jsxs("div",{className:"relative rounded-3xl overflow-hidden shadow-2xl border border-amber-500/30 bg-[#0F1215] p-3 select-none",children:[O?t.jsxs("div",{className:"relative rounded-2xl overflow-hidden min-h-[360px] md:min-h-[420px] flex flex-col md:flex-row bg-[#161D22] border border-amber-500/20 shadow-2xl",children:[t.jsxs("div",{className:"absolute inset-0 z-0",children:[t.jsx("img",{src:O,alt:"Event Ticket Artwork",className:"w-full h-full object-cover object-center filter brightness-90"}),t.jsx("div",{className:"absolute inset-0 bg-gradient-to-r from-[#0F1215]/95 via-[#0F1215]/60 to-[#0F1215]/95 md:from-[#0F1215]/90 md:via-[#0F1215]/30 md:to-[#0F1215]/95"})]}),t.jsxs("div",{className:"relative z-10 md:w-72 p-6 flex flex-col items-center justify-between border-b md:border-b-0 md:border-r-2 border-dashed border-white/20 bg-black/60 backdrop-blur-md",children:[t.jsx("div",{className:"w-44 h-44 rounded-2xl bg-white p-3.5 shadow-2xl flex items-center justify-center border-2 border-amber-400/40",children:t.jsx(Q,{value:a,size:150,level:"H",includeMargin:!1})}),t.jsxs("div",{className:"mt-4 w-full flex items-center justify-around text-center py-2 px-3 rounded-xl bg-white/10 border border-white/10 backdrop-blur-sm",children:[t.jsxs("div",{children:[t.jsx("p",{className:"text-[10px] font-bold uppercase tracking-wider text-amber-400",children:"Row"}),t.jsx("p",{className:"text-xl font-black text-white",children:k})]}),t.jsx("div",{className:"w-px h-8 bg-white/20"}),t.jsxs("div",{children:[t.jsx("p",{className:"text-[10px] font-bold uppercase tracking-wider text-amber-400",children:"Seat"}),t.jsx("p",{className:"text-xl font-black text-white",children:A})]})]}),t.jsxs("div",{className:"mt-3 text-center",children:[t.jsxs("p",{className:"text-[11px] font-mono font-bold tracking-wider text-amber-300",children:["#",F.slice(-8)]}),t.jsx("p",{className:"text-xs font-bold text-white truncate max-w-[180px]",children:$})]})]}),t.jsxs("div",{className:"relative z-10 flex-1 p-6 md:p-8 flex flex-col justify-between",children:[t.jsxs("div",{className:"flex items-center justify-between",children:[t.jsx("span",{className:"text-[11px] font-black uppercase tracking-widest text-amber-300 drop-shadow",children:"WWW.TRIBESANDCLIQS.COM"}),t.jsx("span",{className:"px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500 text-black shadow-lg",children:p})]}),t.jsx("div",{className:"my-6",children:t.jsx("h2",{className:"text-2xl md:text-4xl font-black tracking-tight text-white drop-shadow-lg leading-tight",children:v})}),t.jsxs("div",{className:"space-y-2 text-xs md:text-sm font-bold text-white/90 drop-shadow",children:[t.jsxs("div",{className:"flex items-center gap-2 text-amber-300",children:[t.jsx(ae,{className:"w-4 h-4 shrink-0 text-amber-400"}),t.jsx("span",{className:"font-extrabold",children:S})]}),t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx(le,{className:"w-4 h-4 shrink-0 text-white/70"}),t.jsx("span",{children:b})]}),t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx(re,{className:"w-4 h-4 shrink-0 text-white/70"}),t.jsxs("span",{className:"truncate",children:[u,`, ${h}`]})]})]})]}),t.jsxs("div",{className:"relative z-10 md:w-64 p-6 bg-black/75 backdrop-blur-md text-white flex flex-col items-center justify-between border-t md:border-t-0 md:border-l-2 border-dashed border-white/20",children:[t.jsxs("div",{className:"text-center",children:[t.jsx("p",{className:"text-[11px] font-black uppercase tracking-widest text-amber-400",children:"★ ADMISSION PASS ★"}),t.jsx("div",{className:"w-12 h-0.5 bg-amber-400/40 mx-auto my-2"}),t.jsx("p",{className:"text-[10px] font-bold uppercase tracking-wider text-white/60",children:"Tier & Price"}),t.jsx("p",{className:"text-sm font-bold text-white mt-0.5 truncate max-w-[180px]",children:p})]}),t.jsxs("div",{className:"my-4 text-center",children:[t.jsx("p",{className:"text-2xl md:text-3xl font-black text-amber-400 tracking-tight",children:w}),t.jsxs("p",{className:"text-[10px] font-mono text-white/70 mt-1",children:["#",F.slice(-8)]})]}),t.jsx("div",{className:"w-full flex justify-center items-center gap-1 opacity-80 pt-2 border-t border-white/20",children:[4,8,3,10,4,12,6,8,4,14,8,4,10,4,8,12].map((G,C)=>t.jsx("div",{className:"bg-white h-7 rounded-sm",style:{width:`${G}px`}},C))})]})]}):t.jsxs("div",{className:"relative rounded-2xl overflow-hidden flex flex-col md:flex-row bg-gradient-to-r from-[#D49A32] via-[#F3C760] to-[#D49A32] shadow-inner text-[#171007]",children:[t.jsxs("div",{className:"relative md:w-72 p-6 flex flex-col items-center justify-between border-b md:border-b-0 md:border-r-2 border-dashed border-[#78450F]/40 bg-[#E8AF3E]/30 backdrop-blur-sm",children:[t.jsx("div",{className:"hidden md:block absolute -left-4 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-[#0F1215] border border-amber-500/20"}),t.jsx("div",{className:"w-44 h-44 rounded-2xl bg-white p-3.5 shadow-xl flex items-center justify-center border border-amber-900/10",children:t.jsx(Q,{value:a,size:150,level:"H",includeMargin:!1})}),t.jsxs("div",{className:"mt-5 w-full flex items-center justify-around text-center py-2 px-3 rounded-xl bg-black/10 border border-black/5",children:[t.jsxs("div",{children:[t.jsx("p",{className:"text-[10px] font-extrabold uppercase tracking-wider text-[#6B0F24]",children:"Row"}),t.jsx("p",{className:"text-xl font-black text-[#1A1208]",children:k})]}),t.jsx("div",{className:"w-px h-8 bg-[#6B0F24]/30"}),t.jsxs("div",{children:[t.jsx("p",{className:"text-[10px] font-extrabold uppercase tracking-wider text-[#6B0F24]",children:"Seat"}),t.jsx("p",{className:"text-xl font-black text-[#1A1208]",children:A})]})]}),t.jsxs("div",{className:"mt-3 text-center",children:[t.jsxs("p",{className:"text-[11px] font-mono font-bold tracking-wider text-[#3D2A0F]",children:["#",F.slice(-8)]}),t.jsx("p",{className:"text-xs font-bold text-[#1A1208] truncate max-w-[180px]",children:$})]})]}),t.jsxs("div",{className:"relative flex-1 p-6 md:p-8 flex flex-col justify-between overflow-hidden",children:[t.jsx("div",{className:"absolute right-6 top-1/2 -translate-y-1/2 w-64 h-64 rounded-full border-[12px] border-[#78280A]/10 pointer-events-none"}),t.jsx("div",{className:"absolute right-14 top-1/2 -translate-y-1/2 w-48 h-48 rounded-full border-[6px] border-[#78280A]/10 pointer-events-none"}),t.jsxs("div",{className:"flex items-center justify-between",children:[t.jsx("span",{className:"text-[11px] font-black uppercase tracking-widest text-[#1C150A]",children:"WWW.TRIBESANDCLIQS.COM"}),t.jsx("span",{className:"px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#6B0F24] text-white shadow",children:p})]}),t.jsx("div",{className:"my-5",children:t.jsx("h2",{className:"text-2xl md:text-3xl font-black tracking-tight text-[#160F06] leading-tight",children:v})}),t.jsxs("div",{className:"space-y-2 text-xs md:text-sm font-bold text-[#2C1E0A]",children:[t.jsxs("div",{className:"flex items-center gap-2 text-[#6B0F24]",children:[t.jsx(ae,{className:"w-4 h-4 shrink-0 text-[#6B0F24]"}),t.jsx("span",{className:"font-extrabold",children:S})]}),t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx(le,{className:"w-4 h-4 shrink-0 text-[#78450F]"}),t.jsx("span",{children:b})]}),t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx(re,{className:"w-4 h-4 shrink-0 text-[#78450F]"}),t.jsxs("span",{className:"truncate",children:[u,`, ${h}`]})]})]})]}),t.jsxs("div",{className:"relative md:w-64 p-6 bg-gradient-to-br from-[#6B0F24] via-[#7F132C] to-[#500B1B] text-white flex flex-col items-center justify-between border-t md:border-t-0 md:border-l-2 border-dashed border-white/30",children:[t.jsx("div",{className:"hidden md:block absolute -left-3.5 -top-3.5 w-7 h-7 rounded-full bg-[#0F1215]"}),t.jsx("div",{className:"hidden md:block absolute -left-3.5 -bottom-3.5 w-7 h-7 rounded-full bg-[#0F1215]"}),t.jsx("div",{className:"hidden md:block absolute -right-3.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-[#0F1215]"}),t.jsxs("div",{className:"text-center",children:[t.jsx("p",{className:"text-[11px] font-black uppercase tracking-widest text-[#F5C862]",children:"★ ADMISSION PASS ★"}),t.jsx("div",{className:"w-12 h-0.5 bg-[#F5C862]/40 mx-auto my-2"}),t.jsx("p",{className:"text-[10px] font-bold uppercase tracking-wider text-amber-200/80",children:"Tier & Price"}),t.jsx("p",{className:"text-sm font-bold text-white mt-0.5 truncate max-w-[180px]",children:p})]}),t.jsxs("div",{className:"my-4 text-center",children:[t.jsx("p",{className:"text-2xl md:text-3xl font-black text-[#F5C862] tracking-tight",children:w}),t.jsxs("p",{className:"text-[10px] font-mono text-amber-200/70 mt-1",children:["#",F.slice(-8)]})]}),t.jsx("div",{className:"w-full flex justify-center items-center gap-1 opacity-80 pt-2 border-t border-white/20",children:[4,8,3,10,4,12,6,8,4,14,8,4,10,4,8,12].map((G,C)=>t.jsx("div",{className:"bg-white h-7 rounded-sm",style:{width:`${G}px`}},C))})]})]}),t.jsxs("div",{className:"mt-3 py-1.5 px-4 text-center flex flex-wrap items-center justify-center gap-3 text-[11px] font-bold text-[#E5A93C] uppercase tracking-wider",children:[t.jsxs("span",{className:"flex items-center gap-1 text-emerald-400",children:[t.jsx(de,{className:"w-3.5 h-3.5"})," SECURE YOUR SEAT"]}),t.jsx("span",{className:"text-[#494F55]",children:"•"}),t.jsx("span",{children:"NON-REFUNDABLE"}),t.jsx("span",{className:"text-[#494F55]",children:"•"}),t.jsx("span",{className:"text-amber-300",children:"★ GOOD MUSIC • GOOD VIBES • GOOD PEOPLE"})]})]}),t.jsxs("div",{className:"flex flex-wrap items-center justify-end gap-3 pt-2",children:[y&&t.jsxs("a",{href:y,target:"_blank",rel:"noopener noreferrer",download:e||"Official-Ticket-Pass",className:"inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black text-sm font-extrabold hover:brightness-110 transition shadow-lg shadow-amber-500/20",children:[t.jsx(ce,{className:"w-4 h-4"})," Download Official File (",e?.toLowerCase().endsWith(".pdf")?"PDF":"Pass",")"]}),t.jsxs("button",{onClick:m,className:"inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#1C232B] border border-[#494F55]/40 text-sm font-semibold text-[#EFEFF1] hover:bg-[#242B32] hover:border-white/40 transition shadow-md",children:[t.jsx(xe,{className:"w-4 h-4"})," Print Pass"]}),t.jsxs("button",{onClick:N,className:"inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-white text-[#1C232B] text-sm font-bold hover:bg-[#CBD5E1] transition shadow-lg shadow-black/40",children:[t.jsx(fe,{className:"w-4 h-4"})," Download Ticket (PNG)"]})]})]})}export{ve as T,be as d,oe as g,he as p};
