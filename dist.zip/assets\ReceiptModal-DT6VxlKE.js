import{r as u,j as e,ad as q,U as L,H as I,J as U,aF as M,K as Q,a9 as V,aG as G,Q as A,y as J,L as H,aJ as K,aI as W}from"./vendor-react-kjnsrEhy.js";import{z as Y}from"./vendor-utils-D3rtD2hg.js";import{M as z}from"./Modal-Bld-H6OT.js";import{B as X}from"./Badge-S7B-bsaY.js";import{u as Z,a as ee}from"./index-B72eX1Og.js";import{b as te,d as se}from"./orders-C4aco_rd.js";import{g as ie}from"./TicketPass-4-ofG3NO.js";function xe({open:d,onClose:g,order:o,ticket:s}){const{format:n}=Z(),N=u.useRef(null),[S,F]=u.useState(null),[ae,E]=u.useState(!1),b=o?.id||s?.orderId||s?.order_id||null;u.useEffect(()=>{let i=!0;return d&&b&&(!o?.items||o.items.length===0)?(E(!0),te(b).then(a=>{i&&a.data?.order&&F(a.data.order)}).catch(()=>{}).finally(()=>{i&&E(!1)})):F(null),()=>{i=!1}},[d,b,o?.items]);const t=S||o||(s?{...s,id:s.orderId||s.order_id||s.id,reference:s.paymentRef||s.payment_reference||s.ticketNumber,totalAmount:s.orderTotal??s.price,customerName:s.attendeeName,customerEmail:s.attendeeEmail,customerPhone:s.attendeePhone,createdAt:s.orderCreatedAt||s.created_at,event:s.event,ticketFileUrl:s.ticketFileUrl||s.ticket_file_url||null,ticketFileName:s.ticketFileName||s.ticket_file_name||null,items:[{ticketType:s.ticketType||s.ticket_type_name||"Event Pass",quantity:1,unit_price:s.unitPrice??s.price,subtotal:s.unitPrice??s.price,ticket_file_url:s.ticketFileUrl||s.ticket_file_url||null,ticket_file_name:s.ticketFileName||s.ticket_file_name||null}]}:null);if(!t)return d?e.jsx(z,{open:d,onClose:g,title:"Official Receipt",size:"md",children:e.jsxs("div",{className:"py-12 text-center space-y-3",children:[e.jsx(q,{className:"w-8 h-8 animate-spin mx-auto text-white"}),e.jsx("p",{className:"text-sm text-[#949599]",children:"Loading official receipt..."})]})}):null;const p=t.event||{},y=p.title||t.eventTitle||t.event_title||t.eventName||"Event",x=p.startDate||p.start_date||t.eventDate||t.event_date||t.startDate,B=p.venue||t.venue||t.eventVenue||t.event_venue||"Venue TBA",_=t.customerName||t.buyer_name||t.user?.name||t.userName||"Attendee",D=t.customerEmail||t.buyer_email||t.user?.email||t.userEmail||"—",v=t.customerPhone||t.buyer_phone||t.user?.phone||t.phone||"—",l=t.reference||t.payment_reference||t.orderId||String(t.id??"").slice(-8).toUpperCase(),k=t.createdAt||t.created_at?new Date(t.createdAt||t.created_at).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}):"—",c=Number(t.totalAmount??t.total_amount??t.total??t.amount??0),m=Number(t.discountAmount??t.discount_amount??t.discount??0),C=t.couponCode||t.coupon_code||null,P=Array.isArray(t.items)&&t.items.length>0?t.items:null,j=P?P.map(i=>{const a=Number(i.quantity||1),r=Number(i.unit_price??i.price??i.ticketPrice??0),w=i.subtotal!==void 0&&i.subtotal!==null?Number(i.subtotal):r*a;return{name:i.ticket_type_name||i.ticketType||i.name||"Event Pass",quantity:a,unitPrice:r,subtotal:w}}):[{name:t.ticketType||t.ticket_type_name||"General Admission",quantity:t.quantity||t.ticketCount||1,unitPrice:Number(t.unitPrice??t.ticketPrice??c/(t.quantity||t.ticketCount||1)),subtotal:c}],T=j.reduce((i,a)=>i+a.subtotal,0);JSON.stringify({ref:l,orderId:t.id,event:y,amount:c,status:t.paymentStatus||t.status||"paid"});const $=typeof window<"u"&&window.location?.origin?window.location.origin:"https://tribesandcliqs.com",h=`${$}/verify/${encodeURIComponent(l)}`,R=()=>{if(!N.current)return;const a=window.open("","_blank","width=840,height=960");if(!a){window.print();return}const r=ie(h,160)||"",w=`${$}/assets/images/Logo.jpeg`;a.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Receipt - #${l} - Tribes & Cliqs</title>
          <meta charset="utf-8" />
          <style>
            @page { size: A4; margin: 20mm; }
            * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
            body { background: #ffffff; color: #111827; margin: 0; padding: 24px; font-size: 13px; line-height: 1.5; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
            .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #E5E7EB; padding-bottom: 20px; margin-bottom: 24px; }
            .brand-lockup { display: flex; align-items: center; gap: 14px; }
            .logo-img { width: 50px; height: 50px; border-radius: 10px; object-fit: cover; border: 1px solid #E5E7EB; }
            .brand { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; color: #111827; }
            .badge { display: inline-block; padding: 4px 10px; border-radius: 9999px; font-size: 11px; font-weight: 700; text-transform: uppercase; background: #DEF7EC; color: #03543F; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; }
            .card { background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 8px; padding: 16px; }
            .card-title { font-size: 11px; font-weight: 700; text-transform: uppercase; color: #6B7280; margin-bottom: 8px; }
            table { width: 100%; border-collapse: collapse; margin: 24px 0; }
            th { text-align: left; padding: 10px 12px; background: #F3F4F6; font-size: 11px; text-transform: uppercase; color: #4B5563; font-weight: 600; border-bottom: 1px solid #E5E7EB; }
            td { padding: 12px; border-bottom: 1px solid #E5E7EB; }
            .text-right { text-align: right; }
            .totals { margin-left: auto; width: 280px; }
            .totals-row { display: flex; justify-content: space-between; padding: 6px 0; }
            .totals-row.grand { border-top: 2px solid #111827; font-size: 16px; font-weight: 800; padding-top: 10px; margin-top: 6px; }
            .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #E5E7EB; text-align: center; color: #6B7280; font-size: 11px; }
            .qr-box { text-align: center; margin-top: 16px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="brand-lockup">
              <img src="${w}" alt="Tribes & Cliqs Logo" class="logo-img" />
              <div>
                <div class="brand">TRIBES &amp; CLIQS</div>
                <p style="color: #D97706; font-size: 10px; font-weight: 700; letter-spacing: 2px; margin: 2px 0 0 0; text-transform: uppercase;">Living The Moment</p>
                <p style="color: #6B7280; margin: 2px 0 0 0; font-size: 11px;">Official Transaction Receipt &amp; Proof of Purchase</p>
              </div>
            </div>
            <div style="text-align: right;">
              <span class="badge">PAID &amp; CONFIRMED</span>
              <p style="font-family: monospace; font-size: 13px; font-weight: 700; margin: 6px 0 0 0;">#${l}</p>
              <p style="color: #6B7280; font-size: 11px; margin: 2px 0 0 0;">${k}</p>
            </div>
          </div>

          <div class="grid">
            <div class="card">
              <div class="card-title">Billed To</div>
              <p style="font-weight: 700; margin: 0 0 4px 0;">${_}</p>
              <p style="color: #4B5563; margin: 0 0 2px 0;">${D}</p>
              <p style="color: #4B5563; margin: 0;">${v}</p>
            </div>
            <div class="card">
              <div class="card-title">Event Information</div>
              <p style="font-weight: 700; margin: 0 0 4px 0;">${y}</p>
              <p style="color: #4B5563; margin: 0 0 2px 0;">Date: ${x?new Date(x).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}):"TBA"}</p>
              <p style="color: #4B5563; margin: 0;">Venue: ${B}</p>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Item / Ticket Tier</th>
                <th class="text-right">Qty</th>
                <th class="text-right">Price</th>
                <th class="text-right">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${j.map(f=>`
                <tr>
                  <td><strong>${f.name}</strong></td>
                  <td class="text-right">${f.quantity}</td>
                  <td class="text-right">${n(f.unitPrice)}</td>
                  <td class="text-right font-medium">${n(f.subtotal)}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>

          <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 24px;">
            <div style="display: flex; align-items: center; gap: 14px;">
              ${r?`<div style="padding: 6px; border: 1px solid #E5E7EB; border-radius: 8px; background: #fff; width: 88px; height: 88px; display: flex; align-items: center; justify-content: center;">${r}</div>`:""}
              <div>
                <p style="font-size: 11px; font-weight: 700; color: #111827; margin: 0 0 2px 0;">Official Verification QR</p>
                <p style="font-size: 10px; color: #6B7280; margin: 0 0 2px 0;">Scan at event gate or verify online:</p>
                <p style="font-size: 10px; color: #6B7280; font-family: monospace; margin: 0;">${h}</p>
                <p style="font-size: 10px; color: #6B7280; font-family: monospace; margin: 2px 0 0 0;">Ref: #${l}</p>
              </div>
            </div>
            <div class="totals" style="margin: 0; width: 280px;">
              <div class="totals-row">
                <span style="color: #6B7280;">Subtotal</span>
                <span>${n(T)}</span>
              </div>
              ${m>0?`
                <div class="totals-row" style="color: #059669;">
                  <span>Discount Applied</span>
                  <span>-${n(m)}</span>
                </div>
              `:""}
              <div class="totals-row grand">
                <span>Total Paid</span>
                <span>${n(c)}</span>
              </div>
            </div>
          </div>

          <div class="footer">
            <p>Thank you for booking with Tribes &amp; Cliqs. Please show this receipt or your ticket QR code at the event gate for entry.</p>
            <p>For questions or support, contact support@tribesandcliqs.com</p>
          </div>
        </body>
      </html>
    `),a.document.close(),a.focus(),setTimeout(()=>{a.print(),a.close()},250)},O=async()=>{try{const i=await se(o.id),a=window.URL.createObjectURL(new Blob([i.data],{type:"application/pdf"})),r=document.createElement("a");r.href=a,r.download=`receipt-${l}.pdf`,document.body.appendChild(r),r.click(),r.remove(),window.URL.revokeObjectURL(a),Y.success("Receipt PDF downloaded")}catch{R()}};return e.jsx(z,{open:d,onClose:g,title:"Official Receipt",size:"lg",footer:e.jsxs("div",{className:"flex items-center justify-between w-full",children:[e.jsx("button",{onClick:g,className:"px-4 py-2.5 rounded-lg text-xs font-medium text-[#949599] hover:text-[#EFEFF1] transition",children:"Close"}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs(H,{to:`/receipt/${l}`,state:{order:t},target:"_blank",className:"inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#242B32] border border-[#494F55]/50 text-xs font-semibold text-[#EFEFF1] hover:bg-[#2C343D] hover:text-white transition shadow-sm",children:[e.jsx(A,{className:"w-3.5 h-3.5 text-[#CBD5E1]"})," Open Full Page"]}),e.jsxs("button",{onClick:R,className:"inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg bg-[#242B32] border border-[#494F55]/50 text-xs font-semibold text-[#EFEFF1] hover:bg-[#2C343D] hover:border-white/40 transition shadow-sm",children:[e.jsx(K,{className:"w-4 h-4 text-[#949599]"})," Print Receipt"]}),e.jsxs("button",{onClick:O,className:"inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-white text-[#1C232B] text-xs font-bold hover:bg-[#CBD5E1] transition shadow-md",children:[e.jsx(W,{className:"w-4 h-4"})," Download PDF"]})]})]}),children:e.jsxs("div",{ref:N,className:"space-y-5",children:[e.jsxs("div",{className:"p-5 rounded-xl bg-gradient-to-br from-[#1C232B] to-[#171A1D] border border-[#262B2F]",children:[e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#262B2F]",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx(ee,{size:"sm",showText:!1,asLink:!1}),e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"text-xs font-bold uppercase tracking-widest text-white",children:"Tribes & Cliqs"}),e.jsx(X,{variant:"success",size:"sm",dot:!0,children:"Payment Completed"})]}),e.jsx("h2",{className:"text-lg font-bold text-[#EFEFF1] mt-0.5",children:"Payment Receipt"})]})]}),e.jsxs("div",{className:"text-left sm:text-right",children:[e.jsx("p",{className:"text-xs text-[#949599]",children:"Order Reference"}),e.jsxs("p",{className:"font-mono font-bold text-sm text-[#EFEFF1]",children:["#",l]}),e.jsx("p",{className:"text-[11px] text-[#6B7278]",children:k})]})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 text-xs",children:[e.jsxs("div",{className:"space-y-1.5",children:[e.jsx("p",{className:"text-[11px] font-semibold uppercase tracking-wider text-[#949599]",children:"Customer Details"}),e.jsxs("p",{className:"font-semibold text-sm text-[#EFEFF1] flex items-center gap-1.5",children:[e.jsx(L,{className:"w-3.5 h-3.5 text-[#6B7278]"})," ",_]}),e.jsxs("p",{className:"text-[#949599] flex items-center gap-1.5",children:[e.jsx(I,{className:"w-3.5 h-3.5 text-[#6B7278]"})," ",D]}),v!=="—"&&e.jsxs("p",{className:"text-[#949599] flex items-center gap-1.5",children:[e.jsx(U,{className:"w-3.5 h-3.5 text-[#6B7278]"})," ",v]})]}),e.jsxs("div",{className:"space-y-1.5",children:[e.jsx("p",{className:"text-[11px] font-semibold uppercase tracking-wider text-[#949599]",children:"Event Details"}),e.jsx("p",{className:"font-semibold text-sm text-[#EFEFF1] truncate",children:y}),e.jsxs("p",{className:"text-[#949599] flex items-center gap-1.5",children:[e.jsx(M,{className:"w-3.5 h-3.5 text-[#6B7278] shrink-0"}),x?new Date(x).toLocaleDateString("en-GB",{weekday:"short",day:"numeric",month:"short",year:"numeric"}):"TBA"]}),e.jsxs("p",{className:"text-[#949599] flex items-center gap-1.5 truncate",children:[e.jsx(Q,{className:"w-3.5 h-3.5 text-[#6B7278] shrink-0"})," ",B]})]})]})]}),e.jsxs("div",{className:"rounded-xl bg-[#1C232B]/60 border border-[#262B2F] overflow-hidden",children:[e.jsxs("table",{className:"w-full text-xs",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-[#171A1D] text-[#949599] border-b border-[#262B2F]",children:[e.jsx("th",{className:"text-left px-4 py-3 font-semibold uppercase",children:"Ticket Tier / Item"}),e.jsx("th",{className:"text-center px-4 py-3 font-semibold uppercase",children:"Qty"}),e.jsx("th",{className:"text-right px-4 py-3 font-semibold uppercase",children:"Unit Price"}),e.jsx("th",{className:"text-right px-4 py-3 font-semibold uppercase",children:"Subtotal"})]})}),e.jsx("tbody",{className:"divide-y divide-[#262B2F]",children:j.map((i,a)=>e.jsxs("tr",{className:"hover:bg-[#1D2124]/40",children:[e.jsx("td",{className:"px-4 py-3 font-medium text-[#EFEFF1]",children:i.name}),e.jsx("td",{className:"px-4 py-3 text-center text-[#949599]",children:i.quantity}),e.jsx("td",{className:"px-4 py-3 text-right text-[#949599]",children:n(i.unitPrice)}),e.jsx("td",{className:"px-4 py-3 text-right font-semibold text-[#EFEFF1]",children:n(i.subtotal)})]},a))})]}),(t.ticketFileUrl||t.items&&t.items[0]?.ticket_file_url)&&e.jsxs("div",{className:"p-3 bg-white/5 border-t border-[#262B2F] flex items-center justify-between text-xs",children:[e.jsxs("div",{className:"flex items-center gap-2 text-[#CBD5E1]",children:[e.jsx(V,{className:"w-4 h-4 text-[#CBD5E1] shrink-0"}),e.jsxs("span",{children:["Official Attached Ticket: ",e.jsx("strong",{className:"text-white",children:t.ticketFileName||t.items?.[0]?.ticket_file_name||"Ticket Pass"})]})]}),e.jsx("a",{href:t.ticketFileUrl||t.items?.[0]?.ticket_file_url,target:"_blank",rel:"noopener noreferrer",download:t.ticketFileName||t.items?.[0]?.ticket_file_name||"Official-Ticket",className:"px-2.5 py-1 rounded bg-white text-[#1C232B] font-bold hover:bg-[#CBD5E1] transition",children:"Download File"})]}),e.jsxs("div",{className:"p-4 bg-[#171A1D]/80 border-t border-[#262B2F] flex flex-col sm:flex-row items-center justify-between gap-4",children:[e.jsxs("div",{className:"flex items-center gap-3.5",children:[e.jsx("div",{className:"w-16 h-16 rounded-xl bg-white p-1.5 flex items-center justify-center shrink-0 shadow-md border border-white",children:e.jsx(G,{value:h,size:58,level:"M",includeMargin:!1})}),e.jsxs("div",{className:"text-[11px] text-[#949599]",children:[e.jsx("p",{className:"font-bold text-[#EFEFF1]",children:"Digital Verification QR"}),e.jsx("p",{className:"text-[#6B7278]",children:"Scan at gate or verify online"}),e.jsxs("a",{href:h,target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center gap-1 text-[10px] text-[#CBD5E1] hover:text-white font-semibold",children:["Verify Online ",e.jsx(A,{className:"w-2.5 h-2.5"})]})]})]}),e.jsxs("div",{className:"w-full sm:w-60 space-y-1.5 text-xs",children:[e.jsxs("div",{className:"flex justify-between text-[#949599]",children:[e.jsx("span",{children:"Subtotal"}),e.jsx("span",{children:n(T)})]}),m>0&&e.jsxs("div",{className:"flex justify-between text-emerald-400",children:[e.jsxs("span",{children:["Discount ",C?`(${C})`:""]}),e.jsxs("span",{children:["-",n(m)]})]}),e.jsxs("div",{className:"pt-2 border-t border-[#262B2F] flex justify-between items-baseline font-bold text-sm text-[#EFEFF1]",children:[e.jsx("span",{children:"Total Paid"}),e.jsx("span",{className:"text-base text-white",children:n(c)})]})]})]})]}),e.jsxs("div",{className:"flex items-center gap-2 p-3 rounded-lg bg-[#1D2124] border border-[#262B2F] text-[11px] text-[#949599]",children:[e.jsx(J,{className:"w-4 h-4 text-emerald-400 shrink-0"}),e.jsx("span",{children:"This is an official receipt issued by Tribes & Cliqs. All payments are encrypted and secured."})]})]})})}export{xe as R};
