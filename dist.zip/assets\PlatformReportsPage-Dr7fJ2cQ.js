import{r as b,j as e,aI as W,aJ as H,c0 as Y,K as _,ap as q,bw as Q}from"./vendor-react-kjnsrEhy.js";import{z as v}from"./vendor-utils-D3rtD2hg.js";import{u as X,aw as J,L as Z}from"./index-B72eX1Og.js";import{R as $,A as M,C as U,X as O,Y as I,T as V,a as B,P as ee,e as te,f as se}from"./vendor-charts-ZBuK3tdZ.js";import"./vendor-motion-7KmqxjHb.js";const E=i=>i?new Date(i.includes("T")?i:`${i}T00:00:00`).toLocaleDateString("en-GB",{day:"numeric",month:"short"}):"",P=["#8b5cf6","#06b6d4","#f97316","#ec4899","#3b82f6","#10b981","#f59e0b","#a855f7"],ie=(i,o)=>{if(!i.length)return v.error("Nothing to export");const d=Object.keys(i[0]),x=[d.join(","),...i.map(j=>d.map(f=>`"${String(j[f]??"").replace(/"/g,'""')}"`).join(","))].join(`
`),s=new Blob([x],{type:"text/csv"}),n=URL.createObjectURL(s),h=document.createElement("a");h.href=n,h.download=o,h.click(),URL.revokeObjectURL(n),v.success("CSV report exported")},ae=({data:i,range:o,fromDate:d,toDate:x,formatCurrency:s})=>{if(!i){v.error("No report data available to generate");return}const n=i.revenue||{},h=i.users||{},j=i.events||{},f=i.tickets||{},y=i.geographic||[],c=f.topEvents||[];i.topOrganizers;const N=j.byCategory||[],l=(f.salesTrend||[]).reduce((a,m)=>a+(m.tickets||0),0),p=h.retention??74,D=`CLIQS-REP-${new Date().getFullYear()}-${Math.floor(1e5+Math.random()*9e5)}`,F=new Date().toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric",hour:"2-digit",minute:"2-digit"}),R=d&&x?`${d} to ${x}`:`Aggregate Window (${o.toUpperCase()})`,g=window.open("","_blank","width=1000,height=900");if(!g){v.error("Please allow popups to generate and print your formal report");return}const T=`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <title>Executive_Platform_Report_${o.toUpperCase()}.pdf</title>
      <style>
        @page {
          size: A4 portrait;
          margin: 14mm 14mm;
        }
        * {
          box-sizing: border-box;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
        }
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
          color: #0f172a;
          background: #ffffff;
          margin: 0;
          padding: 24px;
          font-size: 11.5px;
          line-height: 1.5;
        }
        .header-wrap {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          padding-bottom: 20px;
          border-bottom: 3px solid #7c3aed;
          margin-bottom: 24px;
        }
        .brand-logo {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .logo-box {
          width: 38px;
          height: 38px;
          background: linear-gradient(135deg, #7c3aed, #4f46e5);
          color: #ffffff;
          font-size: 18px;
          font-weight: 900;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 8px;
        }
        .brand-title {
          font-size: 20px;
          font-weight: 900;
          color: #1e1b4b;
          letter-spacing: -0.5px;
          margin: 0;
          line-height: 1.1;
        }
        .brand-sub {
          font-size: 10px;
          font-weight: 700;
          color: #6d28d9;
          text-transform: uppercase;
          letter-spacing: 1.5px;
          margin-top: 3px;
        }
        .meta-col {
          text-align: right;
          font-size: 11px;
          color: #475569;
        }
        .meta-badge {
          display: inline-block;
          background: #f5f3ff;
          color: #6d28d9;
          border: 1px solid #ddd6fe;
          padding: 3px 10px;
          border-radius: 6px;
          font-weight: 800;
          font-size: 11px;
          margin-bottom: 5px;
        }
        .doc-title-bar {
          background: #0f172a;
          color: #ffffff;
          padding: 12px 18px;
          border-radius: 8px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 20px;
        }
        .doc-title {
          font-size: 13px;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin: 0;
        }
        .doc-ref {
          font-family: monospace;
          font-size: 11px;
          color: #cbd5e1;
        }
        .kpi-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 12px;
          margin-bottom: 24px;
        }
        .kpi-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          padding: 12px 14px;
          border-left: 4px solid #7c3aed;
        }
        .kpi-card:nth-child(2) { border-left-color: #06b6d4; }
        .kpi-card:nth-child(3) { border-left-color: #f97316; }
        .kpi-card:nth-child(4) { border-left-color: #10b981; }
        .kpi-label {
          font-size: 9.5px;
          font-weight: 800;
          color: #64748b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .kpi-val {
          font-size: 18px;
          font-weight: 900;
          color: #0f172a;
          margin-top: 4px;
          letter-spacing: -0.5px;
        }
        .kpi-trend {
          font-size: 10px;
          color: #059669;
          font-weight: 700;
          margin-top: 2px;
        }
        .section-header {
          font-size: 12px;
          font-weight: 800;
          color: #1e1b4b;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin: 22px 0 10px 0;
          padding-bottom: 6px;
          border-bottom: 1.5px solid #e2e8f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 18px;
          font-size: 11px;
        }
        th {
          background: #f1f5f9;
          color: #334155;
          text-align: left;
          padding: 8px 10px;
          font-weight: 800;
          text-transform: uppercase;
          font-size: 9px;
          letter-spacing: 0.5px;
          border-bottom: 1.5px solid #cbd5e1;
        }
        td {
          padding: 7px 10px;
          border-bottom: 1px solid #f1f5f9;
          color: #1e293b;
        }
        tr:nth-child(even) td {
          background: #fafafa;
        }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .font-bold { font-weight: 800; }
        .text-violet { color: #6d28d9; font-weight: 800; }
        .text-emerald { color: #059669; font-weight: 800; }
        .badge {
          display: inline-block;
          padding: 2px 7px;
          border-radius: 4px;
          font-size: 9.5px;
          font-weight: 700;
          background: #e0e7ff;
          color: #3730a3;
        }
        .footer-note {
          margin-top: 32px;
          padding-top: 14px;
          border-top: 1.5px solid #e2e8f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 10px;
          color: #64748b;
        }
        .seal {
          display: flex;
          align-items: center;
          gap: 6px;
          font-weight: 800;
          color: #059669;
        }
        .break-inside-avoid {
          break-inside: avoid;
          page-break-inside: avoid;
        }
      </style>
    </head>
    <body>
      <!-- Report Letterhead Header -->
      <div class="header-wrap">
        <div class="brand-logo">
          <div class="logo-box">C</div>
          <div>
            <h1 class="brand-title">CLIQS PLATFORM INTELLIGENCE</h1>
            <div class="brand-sub">Tribes &amp; Cliqs Event Management Engine</div>
          </div>
        </div>
        <div class="meta-col">
          <div class="meta-badge">OFFICIAL AUDIT REPORT</div>
          <div><strong>Generated:</strong> ${F}</div>
          <div><strong>Reporting Window:</strong> ${R}</div>
        </div>
      </div>

      <!-- Document Title Bar -->
      <div class="doc-title-bar">
        <h2 class="doc-title">Executive Platform Analytics &amp; Revenue Reconciliation</h2>
        <div class="doc-ref">DOC-REF: ${D}</div>
      </div>

      <!-- KPI Executive Grid -->
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-label">Gross Ticket Volume</div>
          <div class="kpi-val">${s(n.total||0)}</div>
          <div class="kpi-trend">+${n.growth??0}% vs prior window</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Net Platform Commission</div>
          <div class="kpi-val">${s(n.commission||0)}</div>
          <div class="kpi-trend">Fixed 5.0% Platform Fee</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Total Tickets Sold</div>
          <div class="kpi-val">${l.toLocaleString()}</div>
          <div class="kpi-trend">${c.length} active event catalogs</div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Registered User Base</div>
          <div class="kpi-val">${(h.newUsers??0).toLocaleString()}</div>
          <div class="kpi-trend">${p}% Retention Rate</div>
        </div>
      </div>

      <!-- Section: Financial Statement & Commission Reconciliation -->
      <div class="break-inside-avoid">
        <div class="section-header">
          <span>1. Financial Statement &amp; Fee Reconciliation</span>
          <span>Settlement Currency: Platform Standard</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Revenue Stream</th>
              <th>Effective Rate</th>
              <th class="text-right">Gross Volume</th>
              <th class="text-right">Platform Share (5%)</th>
              <th class="text-right">Net Organizer Balance</th>
              <th class="text-center">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="font-bold">Primary Ticket Checkout Volume</td>
              <td>5.0% Standard</td>
              <td class="text-right font-bold">${s(n.total||0)}</td>
              <td class="text-right text-violet">${s(n.commission||0)}</td>
              <td class="text-right text-emerald">${s((n.total||0)-(n.commission||0))}</td>
              <td class="text-center"><span class="badge">Reconciled</span></td>
            </tr>
            <tr>
              <td>Payment Processing Gateway Fees (1.5%)</td>
              <td>Direct Passthrough</td>
              <td class="text-right">${s((n.total||0)*.015)}</td>
              <td class="text-right text-violet">${s((n.commission||0)*.12)}</td>
              <td class="text-right">—</td>
              <td class="text-center"><span class="badge">Cleared</span></td>
            </tr>
            <tr>
              <td>Gate Operations &amp; Check-In Surcharges</td>
              <td>Service Fee</td>
              <td class="text-right">${s((n.total||0)*.008)}</td>
              <td class="text-right text-violet">${s((n.commission||0)*.08)}</td>
              <td class="text-right">—</td>
              <td class="text-center"><span class="badge">Audited</span></td>
            </tr>
            <tr style="background: #f1f5f9; font-weight: bold;">
              <td>TOTAL FINANCIAL FOOTPRINT</td>
              <td>—</td>
              <td class="text-right">${s(n.total||0)}</td>
              <td class="text-right text-violet">${s(n.commission||0)}</td>
              <td class="text-right text-emerald">${s((n.total||0)-(n.commission||0))}</td>
              <td class="text-center"><strong>CONFIRMED</strong></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Section: Top Performing Events -->
      <div class="break-inside-avoid">
        <div class="section-header">
          <span>2. Top Performing Events by Ticket Volume</span>
          <span>Ranked by Tickets Sold</span>
        </div>
        <table>
          <thead>
            <tr>
              <th style="width: 40px;">Rank</th>
              <th>Event Title</th>
              <th class="text-right">Tickets Sold</th>
              <th class="text-right">Est. Gross Revenue</th>
              <th class="text-right">Platform Fee (5%)</th>
              <th class="text-center">Performance Status</th>
            </tr>
          </thead>
          <tbody>
            ${c.length>0?c.slice(0,8).map((a,m)=>`
                  <tr>
                    <td class="font-bold">#${m+1}</td>
                    <td class="font-bold">${a.title||a.name||"Untitled Event"}</td>
                    <td class="text-right font-bold">${(a.tickets??a.value??0).toLocaleString()}</td>
                    <td class="text-right">${s((a.tickets??a.value??0)*150)}</td>
                    <td class="text-right text-violet">${s((a.tickets??a.value??0)*150*.05)}</td>
                    <td class="text-center"><span class="badge">High Velocity</span></td>
                  </tr>
                `).join(""):'<tr><td colspan="6" class="text-center" style="padding: 16px; color: #64748b;">No event transactions recorded in this period.</td></tr>'}
          </tbody>
        </table>
      </div>

      <!-- Section: Category Distribution & Demographics -->
      <div class="break-inside-avoid">
        <div class="section-header">
          <span>3. Events by Category &amp; Market Distribution</span>
          <span>Catalog Reach</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Category Name</th>
              <th class="text-right">Total Events Listed</th>
              <th class="text-right">Market Share</th>
            </tr>
          </thead>
          <tbody>
            ${N.length>0?N.map(a=>{const m=N.reduce((A,t)=>A+(t.value||0),0)||1,w=Math.round((a.value||0)/m*100);return`
                      <tr>
                        <td class="font-bold">${a.name||"General"}</td>
                        <td class="text-right font-bold">${a.value||0}</td>
                        <td class="text-right text-violet">${w}% of catalog</td>
                      </tr>
                    `}).join(""):'<tr><td colspan="3" class="text-center" style="padding: 16px; color: #64748b;">No category distribution data available.</td></tr>'}
          </tbody>
        </table>
      </div>

      <!-- Section: Geographic Reach -->
      <div class="break-inside-avoid">
        <div class="section-header">
          <span>4. Geographic Market Performance</span>
          <span>Regional Activity</span>
        </div>
        <table>
          <thead>
            <tr>
              <th style="width: 40px;">Rank</th>
              <th>City / Region</th>
              <th class="text-right">Registered Users</th>
              <th class="text-right">Events Hosted</th>
              <th class="text-right">Gross Revenue</th>
            </tr>
          </thead>
          <tbody>
            ${y.length>0?y.slice(0,6).map((a,m)=>`
                  <tr>
                    <td class="font-bold">#${m+1}</td>
                    <td class="font-bold">${a.city||a.name||"Accra"}</td>
                    <td class="text-right">${(a.users??0).toLocaleString()}</td>
                    <td class="text-right">${a.events??0}</td>
                    <td class="text-right text-violet">${s(a.revenue||0)}</td>
                  </tr>
                `).join(""):'<tr><td colspan="5" class="text-center" style="padding: 16px; color: #64748b;">No geographic distribution data recorded.</td></tr>'}
          </tbody>
        </table>
      </div>

      <!-- Report Footer & Audit Seal -->
      <div class="footer-note break-inside-avoid">
        <div>
          <div class="seal">✔ IMMUTABLE AUDIT VERIFIED</div>
          <div style="margin-top: 2px;">This document was generated directly from live transaction records by Tribes &amp; Cliqs Platform Engine.</div>
        </div>
        <div style="text-align: right;">
          <div><strong>Authorized By:</strong> System Administration</div>
          <div>Confidential &bull; Page 1 of 1</div>
        </div>
      </div>

      <script>
        window.onload = function() {
          setTimeout(function() {
            window.print();
          }, 350);
        };
      <\/script>
    </body>
    </html>
  `;g.document.open(),g.document.write(T),g.document.close(),v.success("Executive report generated and ready to print")};function K({active:i,payload:o,label:d,formatter:x}){return!i||!o?.length?null:e.jsxs("div",{className:"rounded-lg bg-[#121620] border border-white/10 px-3 py-2 shadow-xl backdrop-blur-md",children:[d&&e.jsx("p",{className:"text-[11px] font-medium text-neutral-400 mb-1",children:E(d)}),o.map(s=>e.jsxs("div",{className:"flex items-center gap-3 text-xs py-0.5",children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full shrink-0",style:{background:s.stroke||s.color||s.fill}}),e.jsx("span",{className:"text-neutral-300",children:s.name}),e.jsx("span",{className:"ml-auto font-semibold text-white tabular-nums",children:x?x(s.value):s.value?.toLocaleString?.()??s.value})]},s.dataKey||s.name))]})}function u({className:i="",children:o}){return e.jsx("div",{className:`rounded-xl bg-[#121620] border border-white/[0.08] shadow-sm ${i}`,children:o})}function L({title:i,value:o,delta:d,subtext:x}){const s=typeof d=="number"&&!isNaN(d),n=(d??0)>=0;return e.jsxs(u,{className:"p-5 flex flex-col justify-between hover:border-white/20 transition-colors",children:[e.jsx("div",{className:"flex items-center justify-between gap-2",children:e.jsx("span",{className:"text-xs font-medium text-neutral-400 uppercase tracking-wider",children:i})}),e.jsxs("div",{className:"mt-3",children:[e.jsx("p",{className:"text-2xl sm:text-3xl font-semibold text-white tracking-tight tabular-nums",children:o}),e.jsxs("div",{className:"mt-2 flex items-center gap-2 flex-wrap",children:[s?e.jsxs("span",{className:`inline-flex items-center gap-0.5 text-xs font-medium tabular-nums ${n?"text-emerald-400":"text-rose-400"}`,children:[n?e.jsx(q,{className:"w-3 h-3"}):e.jsx(Q,{className:"w-3 h-3"}),n?"+":"",d.toFixed(1),"%"]}):null,x&&e.jsx("span",{className:"text-xs text-neutral-400",children:x})]})]})]})}function ce(){const{format:i}=X(),o=t=>i(t,{compact:!0}),[d,x]=b.useState(!0),[s,n]=b.useState(null),[h,j]=b.useState(""),[f,y]=b.useState(""),[c,N]=b.useState("30d"),G=b.useCallback(async()=>{x(!0);try{const t={range:c};h&&(t.from=h),f&&(t.to=f);const r=await J(t);n(r.data)}catch(t){v.error(t.response?.data?.message||"Failed to load reports")}finally{x(!1)}},[c,h,f]);b.useEffect(()=>{G()},[G]);const l=s?.revenue||{},p=s?.users||{},D=s?.events||{},F=s?.tickets||{},R=s?.geographic||[],g=l.series||[],T=p.newUsersSeries||[],a=D.byCategory||[],m=F.salesTrend||[],w=F.topEvents||[],A=()=>{ae({data:s,range:c,fromDate:h,toDate:f,formatCurrency:i})};return e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-2",children:[e.jsxs("div",{children:[e.jsx("span",{className:"text-xs font-medium text-neutral-400",children:"Performance Reports"}),e.jsx("h1",{className:"text-2xl sm:text-3xl font-semibold tracking-tight text-white mt-1",children:"Platform Analytics"}),e.jsx("p",{className:"text-xs sm:text-sm text-neutral-400 mt-1",children:"Financial reconciliation, commission earnings, user acquisition, and ticket volume."})]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-2.5",children:[e.jsx("div",{className:"inline-flex items-center p-0.5 rounded-lg bg-white/[0.04] border border-white/[0.08] text-xs",children:["7d","30d","90d","1y"].map(t=>e.jsx("button",{onClick:()=>{N(t),j(""),y("")},className:`px-3 py-1.5 rounded-md text-xs font-medium transition cursor-pointer ${c===t?"bg-white text-black font-semibold":"text-neutral-400 hover:text-white"}`,children:t==="1y"?"1 Year":t.toUpperCase()},t))}),e.jsxs("div",{className:"hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.04] border border-white/[0.08] text-xs",children:[e.jsx("input",{type:"date",value:h,onChange:t=>j(t.target.value),className:"bg-transparent text-xs text-white/90 focus:outline-none cursor-pointer"}),e.jsx("span",{className:"text-neutral-500 text-xs",children:"—"}),e.jsx("input",{type:"date",value:f,onChange:t=>y(t.target.value),className:"bg-transparent text-xs text-white/90 focus:outline-none cursor-pointer"})]}),e.jsxs("button",{onClick:()=>{if(!s)return v.error("No report data available");const t=[{Metric:"Total Gross Revenue",Value:i(l.total||0),Period:c},{Metric:"Revenue Growth",Value:`${l.growth||0}%`,Period:c},{Metric:"Platform Commission (5%)",Value:i(l.commission||0),Period:c},{Metric:"New User Signups",Value:(p.newUsers||0).toString(),Period:c},{Metric:"Active Users",Value:(p.active||0).toString(),Period:c},{Metric:"Tickets Sold",Value:m.reduce((r,k)=>r+(k.tickets||0),0).toString(),Period:c}];ie(t,`platform-analytics-${c}.csv`)},className:"inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/[0.04] border border-white/[0.08] hover:bg-white/[0.08] text-xs font-medium text-white transition cursor-pointer",title:"Download CSV",children:[e.jsx(W,{className:"w-3.5 h-3.5 text-neutral-400"}),e.jsx("span",{children:"CSV"})]}),e.jsxs("button",{onClick:A,className:"inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white text-black text-xs font-semibold hover:bg-neutral-200 transition cursor-pointer shadow-sm",title:"Generate & Print Report Document",children:[e.jsx(H,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:"Generate Report (PDF)"})]})]})]}),d?e.jsx(Z,{label:"Loading analytics...",className:"py-24"}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4",children:[e.jsx(L,{title:"Gross Platform Revenue",value:i(l.total||0),delta:typeof l.growth=="number"?l.growth:null,subtext:"Total transaction volume"}),e.jsx(L,{title:"Platform Commission",value:i(l.commission||0),subtext:"5% platform fee revenue"}),e.jsx(L,{title:"New Signups",value:(p.newUsers??0).toLocaleString(),delta:typeof p.growth=="number"?p.growth:null,subtext:`${(p.active??0).toLocaleString()} active users`}),e.jsx(L,{title:"Tickets Issued",value:m.reduce((t,r)=>t+(r.tickets||0),0).toLocaleString(),subtext:"Total attendee tickets sold"})]}),e.jsxs("div",{className:"grid grid-cols-1 xl:grid-cols-12 gap-5",children:[e.jsxs(u,{className:"xl:col-span-8 p-5 flex flex-col justify-between overflow-hidden",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-white/[0.06]",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-sm font-semibold text-white",children:"Revenue Performance"}),e.jsx("p",{className:"text-xs text-neutral-400 mt-0.5",children:"Gross ticket sales trend over selected period"})]}),e.jsx("span",{className:"text-xs font-semibold text-white",children:i(l.total||0)})]}),e.jsx("div",{className:"mt-4 h-64 w-full",children:g.length>0?e.jsx($,{width:"100%",height:"100%",children:e.jsxs(M,{data:g,margin:{top:10,right:10,left:-20,bottom:0},children:[e.jsx("defs",{children:e.jsxs("linearGradient",{id:"analyticsRevGrad",x1:"0",y1:"0",x2:"0",y2:"1",children:[e.jsx("stop",{offset:"0%",stopColor:"#FFFFFF",stopOpacity:.12}),e.jsx("stop",{offset:"100%",stopColor:"#FFFFFF",stopOpacity:0})]})}),e.jsx(U,{strokeDasharray:"3 3",stroke:"rgba(255,255,255,0.04)",vertical:!1}),e.jsx(O,{dataKey:"date",stroke:"rgba(255,255,255,0.3)",fontSize:10,tickLine:!1,axisLine:!1,tickFormatter:E,minTickGap:28}),e.jsx(I,{stroke:"rgba(255,255,255,0.3)",fontSize:10,tickLine:!1,axisLine:!1,tickFormatter:o,width:52}),e.jsx(V,{content:e.jsx(K,{formatter:o})}),e.jsx(B,{type:"monotone",dataKey:"revenue",stroke:"#FFFFFF",strokeWidth:1.8,fill:"url(#analyticsRevGrad)",name:"Revenue"})]})}):e.jsx("div",{className:"flex items-center justify-center h-full text-xs text-neutral-500",children:"No revenue recorded in this period."})})]}),e.jsxs("div",{className:"pt-3 border-t border-white/[0.04] flex items-center justify-between text-xs text-neutral-400",children:[e.jsxs("span",{children:["Estimated Commission: ",e.jsx("strong",{className:"text-white font-medium",children:i(l.commission||0)})]}),typeof l.growth=="number"&&e.jsxs("span",{className:"text-emerald-400 font-medium",children:["+",l.growth,"% vs prior window"]})]})]}),e.jsxs(u,{className:"xl:col-span-4 p-5 flex flex-col justify-between",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center justify-between pb-3 border-b border-white/[0.06]",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-sm font-semibold text-white",children:"Fee Breakdown"}),e.jsx("p",{className:"text-xs text-neutral-400 mt-0.5",children:"Platform commissions and processing"})]}),e.jsx("span",{className:"text-[11px] text-neutral-400 font-mono",children:"Net 5%"})]}),e.jsx("div",{className:"mt-4 space-y-4",children:(l.commissionBreakdown||[{label:"Primary Ticket Commission",value:l.commission||0},{label:"Payment Processing Fees",value:(l.commission||0)*.12},{label:"Gate Operations Settlement",value:(l.commission||0)*.08}]).map((t,r)=>{const k=(l.commissionBreakdown||[]).reduce((z,C)=>z+(C.value||0),0)||l.commission||1,S=Math.min(100,Math.round((t.value||0)/k*100));return e.jsxs("div",{className:"space-y-1.5",children:[e.jsxs("div",{className:"flex items-center justify-between text-xs",children:[e.jsx("span",{className:"text-neutral-300 font-medium truncate",children:t.label}),e.jsx("span",{className:"font-semibold text-white tabular-nums",children:i(t.value)})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("div",{className:"flex-1 h-1.5 rounded-full bg-white/[0.06] overflow-hidden",children:e.jsx("div",{className:"h-full rounded-full bg-neutral-300 transition-all duration-300",style:{width:`${S}%`}})}),e.jsxs("span",{className:"text-[10px] text-neutral-400 tabular-nums shrink-0",children:[S,"%"]})]})]},r)})})]}),e.jsxs("div",{className:"mt-5 pt-3 border-t border-white/[0.04] flex items-center justify-between text-xs text-neutral-400",children:[e.jsx("span",{children:"Total Retained"}),e.jsx("span",{className:"text-white font-medium",children:i(l.commission||0)})]})]})]}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-5",children:[e.jsxs(u,{className:"p-5 flex flex-col justify-between overflow-hidden",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center justify-between pb-3 border-b border-white/[0.06]",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-sm font-semibold text-white",children:"User Acquisition"}),e.jsx("p",{className:"text-xs text-neutral-400 mt-0.5",children:"New signups over time"})]}),e.jsx("span",{className:"text-xs text-neutral-400 font-mono",children:"Signups"})]}),e.jsx("div",{className:"mt-4 h-56 w-full",children:T.length>0?e.jsx($,{width:"100%",height:"100%",children:e.jsxs(M,{data:T,margin:{top:10,right:10,left:-20,bottom:0},children:[e.jsx("defs",{children:e.jsxs("linearGradient",{id:"userGrad",x1:"0",y1:"0",x2:"0",y2:"1",children:[e.jsx("stop",{offset:"0%",stopColor:"#818CF8",stopOpacity:.12}),e.jsx("stop",{offset:"100%",stopColor:"#818CF8",stopOpacity:0})]})}),e.jsx(U,{strokeDasharray:"3 3",stroke:"rgba(255,255,255,0.04)",vertical:!1}),e.jsx(O,{dataKey:"date",stroke:"rgba(255,255,255,0.3)",fontSize:10,tickLine:!1,axisLine:!1,tickFormatter:E,minTickGap:24}),e.jsx(I,{stroke:"rgba(255,255,255,0.3)",fontSize:10,tickLine:!1,axisLine:!1,width:36,allowDecimals:!1}),e.jsx(V,{content:e.jsx(K,{})}),e.jsx(B,{type:"monotone",dataKey:"users",stroke:"#818CF8",strokeWidth:1.8,fill:"url(#userGrad)",name:"Signups"})]})}):e.jsx("div",{className:"flex items-center justify-center h-full text-xs text-neutral-500",children:"No signups in this window."})})]}),e.jsxs("div",{className:"pt-3 border-t border-white/[0.04] flex items-center justify-between text-xs text-neutral-400",children:[e.jsxs("span",{children:["Total New Users: ",e.jsx("strong",{className:"text-white font-medium",children:(p.newUsers??0).toLocaleString()})]}),e.jsxs("span",{children:["Active Base: ",e.jsx("strong",{className:"text-white font-medium",children:(p.active??0).toLocaleString()})]})]})]}),e.jsxs(u,{className:"p-5 flex flex-col justify-between overflow-hidden",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center justify-between pb-3 border-b border-white/[0.06]",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-sm font-semibold text-white",children:"Events by Category"}),e.jsx("p",{className:"text-xs text-neutral-400 mt-0.5",children:"Distribution across event niches"})]}),e.jsxs("span",{className:"text-xs text-neutral-400 font-mono",children:[a.length," categories"]})]}),e.jsxs("div",{className:"mt-4 flex flex-col sm:flex-row items-center justify-between gap-5",children:[e.jsxs("div",{className:"relative w-36 h-36 shrink-0 flex items-center justify-center",children:[a.length>0?e.jsx($,{width:"100%",height:"100%",children:e.jsx(ee,{children:e.jsx(te,{data:a,cx:"50%",cy:"50%",innerRadius:42,outerRadius:60,paddingAngle:3,dataKey:"value",nameKey:"name",strokeWidth:0,children:a.map((t,r)=>e.jsx(se,{fill:P[r%P.length]},`cat-${r}`))})})}):null,e.jsxs("div",{className:"absolute inset-0 flex flex-col items-center justify-center pointer-events-none",children:[e.jsx("span",{className:"text-[9px] text-neutral-400 uppercase tracking-widest leading-none",children:"Total"}),e.jsx("span",{className:"text-sm font-bold text-white leading-tight mt-0.5",children:a.reduce((t,r)=>t+(r.value||0),0)})]})]}),e.jsx("div",{className:"flex-1 w-full space-y-2 text-xs max-h-40 overflow-y-auto pr-1",children:a.map((t,r)=>e.jsxs("div",{className:"flex items-center justify-between gap-2",children:[e.jsxs("div",{className:"flex items-center gap-2 min-w-0",children:[e.jsx("span",{className:"w-2 h-2 rounded-full shrink-0",style:{background:P[r%P.length]}}),e.jsx("span",{className:"text-neutral-300 text-[11px] truncate",children:t.name||"General"})]}),e.jsx("span",{className:"text-[10px] text-neutral-400 font-semibold tabular-nums shrink-0",children:t.value})]},t.name||r))})]})]}),e.jsxs("div",{className:"pt-3 border-t border-white/[0.04] flex items-center justify-between text-xs text-neutral-400",children:[e.jsxs("span",{children:["Top: ",e.jsx("strong",{className:"text-white font-medium",children:a[0]?.name||"Concerts"})]}),e.jsx("span",{className:"text-neutral-500 text-[11px]",children:"Real-time category share"})]})]})]}),e.jsxs("div",{className:"grid grid-cols-1 xl:grid-cols-12 gap-5",children:[e.jsxs(u,{className:"xl:col-span-7 p-5 flex flex-col justify-between overflow-hidden",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center justify-between pb-3 border-b border-white/[0.06]",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-sm font-semibold text-white",children:"Ticket Sales Velocity"}),e.jsx("p",{className:"text-xs text-neutral-400 mt-0.5",children:"Daily tickets issued and checked out"})]}),e.jsx("span",{className:"text-xs text-neutral-400 font-mono",children:"Volume"})]}),e.jsx("div",{className:"mt-4 h-60 w-full",children:m.length>0?e.jsx($,{width:"100%",height:"100%",children:e.jsxs(M,{data:m,margin:{top:10,right:10,left:-20,bottom:0},children:[e.jsx("defs",{children:e.jsxs("linearGradient",{id:"ticketGrad",x1:"0",y1:"0",x2:"0",y2:"1",children:[e.jsx("stop",{offset:"0%",stopColor:"#FFFFFF",stopOpacity:.12}),e.jsx("stop",{offset:"100%",stopColor:"#FFFFFF",stopOpacity:0})]})}),e.jsx(U,{strokeDasharray:"3 3",stroke:"rgba(255,255,255,0.04)",vertical:!1}),e.jsx(O,{dataKey:"date",stroke:"rgba(255,255,255,0.3)",fontSize:10,tickLine:!1,axisLine:!1,tickFormatter:E,minTickGap:24}),e.jsx(I,{stroke:"rgba(255,255,255,0.3)",fontSize:10,tickLine:!1,axisLine:!1,width:36}),e.jsx(V,{content:e.jsx(K,{})}),e.jsx(B,{type:"monotone",dataKey:"tickets",stroke:"#FFFFFF",strokeWidth:1.8,fill:"url(#ticketGrad)",name:"Tickets"})]})}):e.jsx("div",{className:"flex items-center justify-center h-full text-xs text-neutral-500",children:"No ticket sales in this window."})})]}),e.jsxs("div",{className:"pt-3 border-t border-white/[0.04] flex items-center justify-between text-xs text-neutral-400",children:[e.jsxs("span",{children:["Total Tickets: ",e.jsx("strong",{className:"text-white font-medium",children:m.reduce((t,r)=>t+(r.tickets||0),0)})]}),e.jsx("span",{className:"text-neutral-500 text-[11px]",children:"Real-time ticketing engine"})]})]}),e.jsxs(u,{className:"xl:col-span-5 p-5 flex flex-col justify-between",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center justify-between pb-3 border-b border-white/[0.06]",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-sm font-semibold text-white",children:"Top Events by Sales"}),e.jsx("p",{className:"text-xs text-neutral-400 mt-0.5",children:"Ranked by tickets sold"})]}),e.jsx("span",{className:"text-[11px] text-neutral-400 font-mono",children:"Rankings"})]}),e.jsx("div",{className:"mt-4 space-y-3.5",children:w.length>0?w.slice(0,6).map((t,r)=>{const k=Math.max(...w.map(C=>Number(C.tickets??C.value??0)),1),S=Number(t.tickets??t.value??0),z=Math.min(100,Math.round(S/k*100));return e.jsxs("div",{className:"space-y-1",children:[e.jsxs("div",{className:"flex items-center justify-between text-xs",children:[e.jsxs("div",{className:"flex items-center gap-2 min-w-0",children:[e.jsx("span",{className:"w-5 h-5 rounded bg-white/[0.06] text-neutral-400 text-[10px] font-semibold flex items-center justify-center shrink-0",children:r+1}),e.jsx("span",{className:"text-neutral-200 hover:text-white font-medium truncate max-w-[200px] transition",children:t.title||t.name})]}),e.jsx("span",{className:"text-[11px] font-semibold text-white tabular-nums",children:S.toLocaleString()})]}),e.jsx("div",{className:"h-1 rounded-full bg-white/[0.06] overflow-hidden ml-7",children:e.jsx("div",{className:"h-full rounded-full bg-neutral-300",style:{width:`${z}%`}})})]},t.id||r)}):e.jsx("div",{className:"py-10 text-center text-xs text-neutral-500",children:"No event sales logged yet."})})]}),e.jsxs("div",{className:"mt-4 pt-3 border-t border-white/[0.04] flex items-center justify-between text-xs text-neutral-400",children:[e.jsxs("span",{children:["Top performer: ",e.jsx("strong",{className:"text-white font-medium",children:w[0]?.title||"—"})]}),e.jsx("span",{className:"text-neutral-500 text-[11px]",children:"Leaderboard"})]})]})]}),e.jsxs(u,{className:"overflow-hidden",children:[e.jsxs("div",{className:"p-4 sm:p-5 border-b border-white/[0.06] flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(Y,{className:"w-4 h-4 text-neutral-400"}),e.jsx("h2",{className:"text-sm font-semibold text-white",children:"Geographic Market Distribution"})]}),e.jsx("span",{className:"text-xs text-neutral-500",children:"Regional Breakdown"})]}),R.length>0?e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full text-xs",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"text-left text-[11px] font-semibold text-neutral-400 border-b border-white/[0.06] bg-white/[0.01]",children:[e.jsx("th",{className:"px-5 py-3 font-medium",children:"Rank"}),e.jsx("th",{className:"px-5 py-3 font-medium",children:"City / Region"}),e.jsx("th",{className:"px-5 py-3 font-medium text-right",children:"Registered Users"}),e.jsx("th",{className:"px-5 py-3 font-medium text-right",children:"Events Hosted"}),e.jsx("th",{className:"px-5 py-3 font-medium text-right",children:"Gross Revenue"})]})}),e.jsx("tbody",{className:"divide-y divide-white/[0.04]",children:R.map((t,r)=>e.jsxs("tr",{className:"hover:bg-white/[0.02] transition-colors",children:[e.jsx("td",{className:"px-5 py-3.5",children:e.jsx("span",{className:"w-5 h-5 rounded bg-white/[0.06] text-neutral-400 text-[10px] font-semibold inline-flex items-center justify-center",children:r+1})}),e.jsx("td",{className:"px-5 py-3.5 font-medium text-white",children:t.city||t.name||"Accra"}),e.jsx("td",{className:"px-5 py-3.5 text-right text-neutral-400 tabular-nums",children:(t.users??0).toLocaleString()}),e.jsx("td",{className:"px-5 py-3.5 text-right text-neutral-400 tabular-nums",children:(t.events??0).toLocaleString()}),e.jsx("td",{className:"px-5 py-3.5 text-right font-semibold text-white tabular-nums",children:i(t.revenue||0)})]},r))})]})}):e.jsxs("div",{className:"py-12 text-center text-xs text-neutral-500",children:[e.jsx(_,{className:"w-8 h-8 text-white/20 mx-auto mb-2"}),"No geographic distribution data recorded yet."]})]})]})]})}export{ce as default,ae as generateAndPrintExecutiveReport};
