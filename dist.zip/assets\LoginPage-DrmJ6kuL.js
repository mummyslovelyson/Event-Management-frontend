import{l as k,u as F,r as g,j as e,V as N,H as z,bb as E,bl as C,b7 as S,L as b,ad as P,f as B}from"./vendor-react-kjnsrEhy.js";import{u as I,z as s}from"./vendor-utils-D3rtD2hg.js";import{b as L,a as R}from"./index-B72eX1Og.js";import{G as A}from"./GoogleAuthButton-C57KkWxe.js";import{m as M}from"./vendor-motion-7KmqxjHb.js";function U(){const t=k(),u=F(),{login:h,loading:d}=L(),[p,f]=g.useState(!1),[n,x]=g.useState(!1),[c,m]=g.useState(""),{register:l,handleSubmit:w,formState:{errors:a}}=I(),v=async i=>{m("");try{const o=await h(i.email,i.password,i.website);s.success(`Welcome back, ${o.name||o.email}!`,{duration:4e3});const r=u.state?.from?.pathname;r&&!r.startsWith("/admin")?t(r,{replace:!0}):["admin","system_admin","superadmin","staff"].includes(o.role)?t("/admin/dashboard",{replace:!0}):o.role==="organizer"?t("/organizer/dashboard",{replace:!0}):t("/",{replace:!0})}catch(o){if(o.response?.data?.isAdminPortalRedirect){s.error(o.response.data.message||"Admin accounts must log in via the Admin Portal",{duration:5e3}),t("/admin-login");return}if(o.response?.data?.requiresVerification){s.error(o.response.data.message||"Please verify your account first",{duration:6e3});const y=encodeURIComponent(o.response.data.email||i.email||""),j=o.response.data.phone?`&phone=${encodeURIComponent(o.response.data.phone)}`:"";t(`/verify-email?email=${y}${j}`);return}const r=o.friendlyMessage||o.response?.data?.message||"Invalid email or password";m(r),s.error(r)}};return e.jsxs("div",{className:"login-page-root",children:[e.jsx("style",{children:`
        .login-page-root {
          min-height: 100vh;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          background-color: #1C232B;
          color: #EFEFF1;
          font-family: 'Inter', system-ui, -apple-system, sans-serif;
          position: relative;
          overflow: hidden;
          padding: 20px;
        }

        /* Ambient Glow Background */
        .login-page-root .bg-ambient {
          position: absolute;
          inset: 0;
          pointer-events: none;
          overflow: hidden;
        }
        .login-page-root .ambient-orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(80px);
          opacity: 0.18;
        }
        .login-page-root .ambient-orb-1 {
          width: 520px;
          height: 520px;
          background: #ffffff;
          top: -120px;
          left: 50%;
          transform: translateX(-50%);
        }
        .login-page-root .ambient-orb-2 {
          width: 440px;
          height: 440px;
          background: #b21414;
          bottom: -100px;
          right: 12%;
          opacity: 0.12;
        }

        /* Grid Pattern */
        .login-page-root .grid-overlay {
          position: absolute;
          inset: 0;
          opacity: 0.03;
          pointer-events: none;
          background-image: linear-gradient(#EFEFF1 1px, transparent 1px), linear-gradient(90deg, #EFEFF1 1px, transparent 1px);
          background-size: 40px 40px;
        }

        /* Circular Container */
        .login-page-root .circle-container {
          position: relative;
          width: 550px;
          height: 550px;
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 10;
        }

        /* Neumorphic Glass Circle using Project Colors */
        .login-page-root .glass-circle {
          position: relative;
          width: 550px;
          height: 550px;
          border-radius: 50%;
          display: flex;
          justify-content: center;
          align-items: center;
          background: #161D22;
          box-shadow:
            -18px -18px 40px rgba(255, 255, 255, 0.035),
            24px 24px 50px rgba(0, 0, 0, 0.75),
            inset -1px -1px 1px rgba(255, 255, 255, 0.08),
            inset 1px 1px 1px rgba(0, 0, 0, 0.6);
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        /* Inner Ring with Depth */
        .login-page-root .glass-circle::before {
          content: "";
          position: absolute;
          inset: 14px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.06);
          box-shadow:
            inset 4px 4px 12px rgba(0, 0, 0, 0.45),
            inset -3px -3px 8px rgba(255, 255, 255, 0.03);
          pointer-events: none;
        }

        /* Form Structure */
        .login-page-root .login-form {
          position: relative;
          width: 300px;
          z-index: 20;
        }

        /* Titles */
        .login-page-root .login-form h1 {
          color: #EFEFF1;
          font-size: 30px;
          font-weight: 700;
          letter-spacing: .5px;
          margin-bottom: 2px;
          text-align: center;
          text-shadow:
            1px 1px 2px rgba(0, 0, 0, 0.8),
            -1px -1px 1px rgba(255, 255, 255, 0.06);
        }

        .login-page-root .login-form .subtitle {
          text-align: center;
          color: #949599;
          font-size: 12px;
          font-weight: 500;
          letter-spacing: .3px;
          margin-bottom: 14px;
        }

        /* Alert Notification Box */
        .login-page-root .alert-box {
          background: rgba(161, 15, 15, 0.15);
          border: 1px solid rgba(161, 15, 15, 0.35);
          border-radius: 10px;
          padding: 6px 10px;
          font-size: 11px;
          text-align: center;
          margin-bottom: 10px;
          color: #fca5a5;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          line-height: 1.3;
          animation: alertFadeIn 0.3s ease;
        }

        @keyframes alertFadeIn {
          from { opacity: 0; transform: translateY(-4px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Recessed Neumorphic Input Box */
        .login-page-root .input-box {
          position: relative;
          margin-bottom: 11px;
        }

        .login-page-root .input-box .input-icon {
          position: absolute;
          left: 15px;
          top: 50%;
          transform: translateY(-50%);
          color: #949599;
          z-index: 2;
          pointer-events: none;
          transition: color .25s ease;
          display: flex;
          align-items: center;
        }

        .login-page-root .input-box input {
          width: 100%;
          height: 42px;
          padding: 0 15px 0 42px;
          border: 1px solid rgba(73, 79, 85, 0.35);
          outline: none;
          background: #1C232B;
          color: #EFEFF1;
          font-family: inherit;
          font-size: 13px;
          font-weight: 500;
          letter-spacing: .2px;
          border-radius: 11px;
          box-shadow:
            inset 3px 3px 6px rgba(0, 0, 0, 0.45),
            inset -2px -2px 5px rgba(255, 255, 255, 0.03);
          transition: box-shadow .3s ease, border-color .3s ease;
        }

        .login-page-root .input-box input.has-eye {
          padding-right: 42px;
        }

        .login-page-root .input-box input::placeholder {
          color: #494F55;
          font-weight: 400;
        }

        .login-page-root .input-box input:focus {
          border-color: rgba(255, 255, 255, 0.35);
          box-shadow:
            inset 3px 3px 6px rgba(0, 0, 0, 0.6),
            inset -2px -2px 5px rgba(255, 255, 255, 0.05),
            0 0 0 1px rgba(255, 255, 255, 0.15);
        }

        .login-page-root .input-box input:focus + .input-icon,
        .login-page-root .input-box:focus-within .input-icon {
          color: #EFEFF1;
        }

        .login-page-root .input-box .toggle-eye {
          position: absolute;
          right: 12px;
          top: 50%;
          transform: translateY(-50%);
          color: #949599;
          cursor: pointer;
          background: transparent;
          border: none;
          padding: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: color .25s ease;
          z-index: 5;
        }

        .login-page-root .input-box .toggle-eye:hover {
          color: #EFEFF1;
        }

        .login-page-root .field-error {
          font-size: 10.5px;
          color: #f87171;
          margin-top: -8px;
          margin-bottom: 8px;
          padding-left: 4px;
        }

        /* Remember Me & Forgot Password Row */
        .login-page-root .options-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: 1px;
          margin-bottom: 14px;
        }

        .login-page-root .remember {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          color: #949599;
          cursor: pointer;
          user-select: none;
        }

        /* Neumorphic Capsule Switch */
        .login-page-root .switch {
          position: relative;
          width: 32px;
          height: 18px;
          border-radius: 20px;
          background: #1C232B;
          border: 1px solid rgba(73, 79, 85, 0.35);
          box-shadow:
            inset 3px 3px 6px rgba(0, 0, 0, 0.5),
            inset -2px -2px 4px rgba(255, 255, 255, 0.04);
          cursor: pointer;
          flex-shrink: 0;
          transition: background .25s ease, border-color .25s ease;
        }

        .login-page-root .switch::after {
          content: "";
          position: absolute;
          top: 2px;
          left: 2px;
          width: 12px;
          height: 12px;
          border-radius: 50%;
          background: #494F55;
          box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.4);
          transition: left .25s cubic-bezier(0.4, 0, 0.2, 1), background .25s ease;
        }

        .login-page-root .switch.on {
          border-color: rgba(178, 20, 20, 0.5);
          background: #242B32;
        }

        .login-page-root .switch.on::after {
          left: 16px;
          background: #b21414;
        }

        .login-page-root .forgot-link {
          font-size: 11.5px;
          color: #949599;
          text-decoration: none;
          transition: color .2s ease;
        }

        .login-page-root .forgot-link:hover {
          color: #EFEFF1;
          text-decoration: underline;
        }

        /* Submit Button */
        .login-page-root .submit-btn {
          position: relative;
          width: 100%;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin: 0 auto;
          overflow: hidden;
          border: none;
          outline: none;
          border-radius: 11px;
          cursor: pointer;
          font-family: inherit;
          font-size: 13.5px;
          font-weight: 600;
          letter-spacing: .8px;
          text-transform: uppercase;
          color: #1C232B;
          background: #EFEFF1;
          box-shadow:
            0 4px 14px rgba(0, 0, 0, 0.3),
            -4px -4px 10px rgba(255, 255, 255, 0.05),
            4px 4px 10px rgba(0, 0, 0, 0.4);
          transition: color .3s ease, background .3s ease, box-shadow .3s ease, transform .2s ease;
        }

        .login-page-root .submit-btn::before {
          content: "";
          position: absolute;
          top: 0;
          left: -60%;
          width: 40%;
          height: 100%;
          background: linear-gradient(115deg, transparent, rgba(255, 255, 255, 0.6), transparent);
          transform: skewX(-20deg);
          transition: left .6s ease;
        }

        .login-page-root .submit-btn:hover:not(:disabled)::before {
          left: 130%;
        }

        .login-page-root .submit-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          background: #CBD5E1;
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.45);
        }

        .login-page-root .submit-btn:active:not(:disabled) {
          transform: translateY(0) scale(0.98);
        }

        .login-page-root .submit-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        /* Divider */
        .login-page-root .divider-row {
          display: flex;
          align-items: center;
          gap: 8px;
          margin: 10px 0;
        }
        .login-page-root .divider-line {
          flex: 1;
          height: 1px;
          background: rgba(73, 79, 85, 0.35);
        }
        .login-page-root .divider-text {
          font-size: 10px;
          color: #494F55;
          text-transform: uppercase;
          letter-spacing: 1px;
        }

        /* Footer Links */
        .login-page-root .footer-links {
          text-align: center;
          margin-top: 10px;
          font-size: 11.5px;
          color: #949599;
        }

        .login-page-root .footer-links a.signup-link {
          color: #EFEFF1;
          font-weight: 600;
          text-decoration: none;
          transition: color .2s ease;
          margin-left: 3px;
        }

        .login-page-root .footer-links a.signup-link:hover {
          color: #ffffff;
          text-decoration: underline;
        }

        /* Responsive */
        @media (max-width: 640px) {
          .login-page-root {
            padding: 20px 14px;
            align-items: center;
          }
          .login-page-root .circle-container {
            width: 100%;
            max-width: 420px;
            height: auto;
            min-height: auto;
          }
          .login-page-root .glass-circle {
            width: 100%;
            max-width: 420px;
            height: auto;
            min-height: auto;
            border-radius: 28px;
            padding: 30px 22px 24px;
            box-shadow:
              -10px -10px 24px rgba(255, 255, 255, 0.025),
              16px 16px 36px rgba(0, 0, 0, 0.7);
          }
          .login-page-root .glass-circle::before {
            border-radius: 22px;
            inset: 8px;
          }
          .login-page-root .login-form {
            width: 100%;
          }
          .login-page-root .login-form h1 {
            font-size: 26px;
          }
          .login-page-root .login-form .subtitle {
            font-size: 11.5px;
            margin-bottom: 14px;
          }
          .login-page-root .input-box {
            margin-bottom: 12px;
          }
          .login-page-root .input-box input {
            height: 44px;
            font-size: 13.5px;
            padding-left: 42px;
          }
          .login-page-root .input-box .input-icon {
            left: 14px;
          }
          .login-page-root .options-row {
            margin-bottom: 14px;
          }
          .login-page-root .remember,
          .login-page-root .forgot-link {
            font-size: 11.5px;
          }
          .login-page-root .submit-btn {
            height: 44px;
            font-size: 13.5px;
          }
          .login-page-root .divider-row {
            margin: 10px 0;
          }
          .login-page-root .footer-links {
            margin-top: 12px;
            font-size: 11.5px;
          }
        }

        @media (max-width: 380px) {
          .login-page-root .glass-circle {
            padding: 24px 16px 20px;
            border-radius: 22px;
          }
          .login-page-root .glass-circle::before {
            border-radius: 18px;
            inset: 6px;
          }
          .login-page-root .login-form h1 {
            font-size: 23px;
          }
          .login-page-root .input-box input {
            font-size: 12.5px;
            padding-left: 38px;
          }
        }
      `}),e.jsxs("div",{className:"bg-ambient",children:[e.jsx("div",{className:"ambient-orb ambient-orb-1"}),e.jsx("div",{className:"ambient-orb ambient-orb-2"})]}),e.jsx("div",{className:"grid-overlay"}),e.jsx(M.div,{initial:{opacity:0,scale:.95},animate:{opacity:1,scale:1},transition:{duration:.35,ease:"easeOut"},className:"circle-container",children:e.jsx("div",{className:"glass-circle",children:e.jsxs("form",{className:"login-form",onSubmit:w(v),noValidate:!0,children:[e.jsx("input",{type:"text",...l("website"),tabIndex:-1,autoComplete:"off","aria-hidden":"true",style:{display:"none"}}),e.jsx("div",{className:"flex justify-center mb-1.5",children:e.jsx(R,{size:"md",showText:!1,asLink:!1})}),e.jsx("h1",{children:"Login"}),e.jsx("div",{className:"subtitle",children:"Sign in to your account"}),c&&e.jsxs("div",{className:"alert-box",role:"alert",children:[e.jsx(N,{size:13,style:{flexShrink:0}}),e.jsx("span",{children:c})]}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(z,{size:15})}),e.jsx("input",{type:"email",id:"loginEmail",placeholder:"Username or email",autoComplete:"email",...l("email",{required:"Email is required",pattern:{value:/^\S+@\S+\.\S+$/,message:"Enter a valid email"}})})]}),a.email&&e.jsx("div",{className:"field-error",children:a.email.message}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(E,{size:15})}),e.jsx("input",{type:p?"text":"password",id:"loginPassword",className:"has-eye",placeholder:"Password",autoComplete:"current-password",...l("password",{required:"Password is required",minLength:{value:6,message:"Minimum 6 characters"}})}),e.jsx("button",{type:"button",className:"toggle-eye",onClick:()=>f(i=>!i),"aria-label":p?"Hide password":"Show password",children:p?e.jsx(C,{size:14}):e.jsx(S,{size:14})})]}),a.password&&e.jsx("div",{className:"field-error",children:a.password.message}),e.jsxs("div",{className:"options-row",children:[e.jsxs("div",{className:"remember",onClick:()=>x(!n),role:"checkbox","aria-checked":n,tabIndex:0,onKeyDown:i=>{(i.key===" "||i.key==="Enter")&&(i.preventDefault(),x(!n))},children:[e.jsx("div",{className:`switch ${n?"on":""}`}),e.jsx("span",{children:"Remember me"})]}),e.jsx(b,{to:"/forgot-password",className:"forgot-link",children:"Forgot password?"})]}),e.jsx("button",{type:"submit",id:"loginSubmitBtn",className:"submit-btn",disabled:d,children:d?e.jsxs(e.Fragment,{children:[e.jsx(P,{size:15,className:"animate-spin"}),e.jsx("span",{children:"Signing in..."})]}):e.jsxs(e.Fragment,{children:[e.jsx(B,{size:15}),e.jsx("span",{children:"Sign In"})]})}),e.jsxs("div",{className:"divider-row",children:[e.jsx("div",{className:"divider-line"}),e.jsx("span",{className:"divider-text",children:"or"}),e.jsx("div",{className:"divider-line"})]}),e.jsx(A,{text:"Continue with Google",className:"!w-full !py-2 !text-xs !bg-[#1C232B] !border !border-[#494F55]/40 hover:!border-white/40 !rounded-xl shadow-none"}),e.jsxs("div",{className:"footer-links",children:["Don't have an account?"," ",e.jsx(b,{to:"/register",className:"signup-link",children:"Sign up"})]})]})})})]})}export{U as default};
