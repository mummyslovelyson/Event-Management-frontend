import{l as D,r as p,j as e,V as G,Z as Y,D as C,U as F,H as E,ak as S,E as W,K as H,G as K,aK as P,J as _,bb as B,bl as q,b7 as A,a5 as X,L as f,ad as Z,h as J}from"./vendor-react-kjnsrEhy.js";import{u as Q,z as b}from"./vendor-utils-D3rtD2hg.js";import{a as ee,o as te}from"./index-B72eX1Og.js";import{G as re}from"./GoogleAuthButton-C57KkWxe.js";import{m as u,A as ie}from"./vendor-motion-7KmqxjHb.js";function le(){const I=D(),[i,j]=p.useState("attendee"),[o,x]=p.useState(1),[g,U]=p.useState(!1),[m,L]=p.useState(!1),[l,y]=p.useState(!1),[h,v]=p.useState(!1),[w,c]=p.useState(""),N=i==="organizer"?3:2,{register:s,handleSubmit:O,watch:d,trigger:$,formState:{errors:r}}=Q(),R=d("password")||"",z=async()=>{c("");let t=[];o===1?i==="attendee"?t=["name","email"]:t=["name","organizationName"]:o===2&&i==="organizer"&&(t=["category","city","websiteUrl","description"]),await $(t)&&x(n=>Math.min(n+1,N))},k=()=>{c(""),x(t=>Math.max(t-1,1))},M=async t=>{if(c(""),!l){c("Please accept the Terms of Service to continue"),b.error("Please accept the terms to continue");return}v(!0);try{const a={name:t.name,email:t.email,phone:t.phone,password:t.password,role:i,website:t.website};if(i==="organizer"){if(!t.organizationName?.trim()||!t.category?.trim()||!t.city?.trim()||!t.websiteUrl?.trim()||!t.description?.trim()||!t.phone?.trim()){c("All organizer fields are mandatory: Organization Name, Category, City, Website/Social Link, Bio, and Phone."),b.error("Please fill in all organizer fields");return}a.organizationName=t.organizationName.trim(),a.category=t.category.trim(),a.city=t.city.trim(),a.description=t.description.trim(),a.websiteUrl=t.websiteUrl.trim()}const n=await te(a);b.success(n.data?.message||(t.phone?`Verification code sent to ${t.phone} via SMS and email!`:`Verification code sent to ${t.email}!`),{duration:6e3});const T=n.data?.registrationId?`&regId=${encodeURIComponent(n.data.registrationId)}`:"",V=t.phone?`&phone=${encodeURIComponent(t.phone)}`:"";I(`/verify-email?email=${encodeURIComponent(t.email)}${V}${T}`)}catch(a){const n=a.response?.data?.message||"Registration failed. Please try again.";c(n),b.error(n)}finally{v(!1)}};return e.jsxs("div",{className:"register-page-root",children:[e.jsx("style",{children:`
        .register-page-root {
          min-height: 100vh;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          background-color: #1C232B;
          color: #EFEFF1;
          font-family: 'Inter', system-ui, -apple-system, sans-serif;
          position: relative;
          overflow: hidden;
          padding: 20px;
        }

        /* Ambient Glow Background */
        .register-page-root .bg-ambient {
          position: absolute;
          inset: 0;
          pointer-events: none;
          overflow: hidden;
        }
        .register-page-root .ambient-orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(80px);
          opacity: 0.18;
        }
        .register-page-root .ambient-orb-1 {
          width: 550px;
          height: 550px;
          background: #ffffff;
          top: -120px;
          left: 50%;
          transform: translateX(-50%);
        }
        .register-page-root .ambient-orb-2 {
          width: 460px;
          height: 460px;
          background: #b21414;
          bottom: -100px;
          right: 10%;
          opacity: 0.12;
        }

        /* Grid Pattern */
        .register-page-root .grid-overlay {
          position: absolute;
          inset: 0;
          opacity: 0.03;
          pointer-events: none;
          background-image: linear-gradient(#EFEFF1 1px, transparent 1px), linear-gradient(90deg, #EFEFF1 1px, transparent 1px);
          background-size: 40px 40px;
        }

        /* Circular Container - Expanded */
        .register-page-root .circle-container {
          position: relative;
          width: 570px;
          height: 570px;
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 10;
        }

        .register-page-root .glass-circle {
          position: relative;
          width: 570px;
          height: 570px;
          border-radius: 50%;
          display: flex;
          justify-content: center;
          align-items: center;
          background: #161D22;
          box-shadow:
            -18px -18px 40px rgba(255, 255, 255, 0.035),
            24px 24px 50px rgba(0, 0, 0, 0.75),
            inset -1px -1px 1px rgba(255, 255, 255, 0.08),
            inset 1px 1px 1px rgba(0, 0, 0, 0.6);
        }

        /* Inner Ring with Depth */
        .register-page-root .glass-circle::before {
          content: "";
          position: absolute;
          inset: 14px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.06);
          box-shadow:
            inset 4px 4px 12px rgba(0, 0, 0, 0.45),
            inset -3px -3px 8px rgba(255, 255, 255, 0.03);
          pointer-events: none;
        }

        /* Form Container */
        .register-page-root .form-inner {
          position: relative;
          width: 310px;
          z-index: 20;
        }

        /* Titles */
        .register-page-root h1 {
          color: #EFEFF1;
          font-size: 28px;
          font-weight: 700;
          letter-spacing: .5px;
          margin-bottom: 2px;
          text-align: center;
          text-shadow:
            1px 1px 2px rgba(0, 0, 0, 0.8),
            -1px -1px 1px rgba(255, 255, 255, 0.06);
        }

        .register-page-root .subtitle {
          text-align: center;
          color: #949599;
          font-size: 12px;
          font-weight: 500;
          letter-spacing: .3px;
          margin-bottom: 10px;
        }

        /* Step Progress Indicator */
        .register-page-root .step-progress {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          margin-bottom: 14px;
        }

        .register-page-root .step-bar {
          height: 3.5px;
          border-radius: 4px;
          background: #242B32;
          transition: all 0.3s ease;
        }

        .register-page-root .step-bar.active {
          width: 32px;
          background: #EFEFF1;
          box-shadow: 0 0 6px rgba(255, 255, 255, 0.3);
        }

        .register-page-root .step-bar.inactive {
          width: 18px;
          background: #333C45;
        }

        .register-page-root .step-bar.completed {
          width: 18px;
          background: #b21414;
        }

        /* Role Switch Pills */
        .register-page-root .role-pills {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 6px;
          padding: 3px;
          border-radius: 11px;
          background: #1C232B;
          border: 1px solid rgba(73, 79, 85, 0.35);
          box-shadow:
            inset 2px 2px 5px rgba(0, 0, 0, 0.45),
            inset -2px -2px 5px rgba(255, 255, 255, 0.02);
          margin-bottom: 14px;
        }

        .register-page-root .role-pill-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 7px 4px;
          border-radius: 8px;
          font-size: 11.5px;
          font-weight: 600;
          border: none;
          cursor: pointer;
          transition: background .25s ease, color .25s ease, box-shadow .25s ease;
          background: transparent;
          color: #949599;
        }

        .register-page-root .role-pill-btn.active {
          background: #EFEFF1;
          color: #1C232B;
          box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        }

        /* Alert Notification Box */
        .register-page-root .alert-box {
          background: rgba(161, 15, 15, 0.15);
          border: 1px solid rgba(161, 15, 15, 0.35);
          border-radius: 10px;
          padding: 6px 10px;
          font-size: 11px;
          text-align: center;
          margin-bottom: 10px;
          color: #fca5a5;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          line-height: 1.3;
          animation: alertFadeIn 0.3s ease;
        }

        @keyframes alertFadeIn {
          from { opacity: 0; transform: translateY(-4px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Recessed Neumorphic Input Box */
        .register-page-root .input-box {
          position: relative;
          margin-bottom: 11px;
        }

        .register-page-root .input-box .input-icon {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: #949599;
          z-index: 2;
          pointer-events: none;
          transition: color .25s ease;
          display: flex;
          align-items: center;
        }

        .register-page-root .input-box input,
        .register-page-root .input-box select,
        .register-page-root .input-box textarea {
          width: 100%;
          height: 42px;
          padding: 0 14px 0 40px;
          border: 1px solid rgba(73, 79, 85, 0.35);
          outline: none;
          background: #1C232B;
          color: #EFEFF1;
          font-family: inherit;
          font-size: 13px;
          font-weight: 500;
          letter-spacing: .2px;
          border-radius: 11px;
          box-shadow:
            inset 3px 3px 6px rgba(0, 0, 0, 0.45),
            inset -2px -2px 5px rgba(255, 255, 255, 0.03);
          transition: box-shadow .3s ease, border-color .3s ease;
        }

        .register-page-root .input-box input.has-eye {
          padding-right: 40px;
        }

        .register-page-root .input-box input::placeholder,
        .register-page-root .input-box textarea::placeholder {
          color: #494F55;
          font-weight: 400;
        }

        .register-page-root .input-box input:focus,
        .register-page-root .input-box select:focus,
        .register-page-root .input-box textarea:focus {
          border-color: rgba(255, 255, 255, 0.35);
          box-shadow:
            inset 3px 3px 6px rgba(0, 0, 0, 0.6),
            inset -2px -2px 5px rgba(255, 255, 255, 0.05),
            0 0 0 1px rgba(255, 255, 255, 0.15);
        }

        .register-page-root .input-box input:focus + .input-icon,
        .register-page-root .input-box:focus-within .input-icon {
          color: #EFEFF1;
        }

        .register-page-root .input-box .toggle-eye {
          position: absolute;
          right: 12px;
          top: 50%;
          transform: translateY(-50%);
          color: #949599;
          cursor: pointer;
          background: transparent;
          border: none;
          padding: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: color .25s ease;
          z-index: 5;
        }

        .register-page-root .input-box .toggle-eye:hover {
          color: #EFEFF1;
        }

        .register-page-root .field-error {
          font-size: 10px;
          color: #f87171;
          margin-top: -8px;
          margin-bottom: 8px;
          padding-left: 4px;
        }

        /* Terms Checkbox */
        .register-page-root .terms-row {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          margin: 6px 0 12px 2px;
          cursor: pointer;
          user-select: none;
        }

        .register-page-root .terms-checkbox {
          width: 16px;
          height: 16px;
          border-radius: 4px;
          background: #1C232B;
          border: 1px solid rgba(73, 79, 85, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          margin-top: 1px;
          transition: background .2s ease, border-color .2s ease;
        }

        .register-page-root .terms-checkbox.checked {
          background: #b21414;
          border-color: #b21414;
        }

        .register-page-root .terms-text {
          font-size: 10.5px;
          color: #949599;
          line-height: 1.35;
        }

        .register-page-root .terms-text a {
          color: #EFEFF1;
          text-decoration: underline;
        }

        /* Action Buttons */
        .register-page-root .actions-row {
          display: flex;
          gap: 8px;
          margin-top: 6px;
        }

        .register-page-root .submit-btn {
          position: relative;
          width: 100%;
          height: 42px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin: 0 auto;
          overflow: hidden;
          border: none;
          outline: none;
          border-radius: 11px;
          cursor: pointer;
          font-family: inherit;
          font-size: 13.5px;
          font-weight: 600;
          letter-spacing: .8px;
          text-transform: uppercase;
          color: #1C232B;
          background: #EFEFF1;
          box-shadow:
            0 4px 14px rgba(0, 0, 0, 0.3),
            -4px -4px 10px rgba(255, 255, 255, 0.05),
            4px 4px 10px rgba(0, 0, 0, 0.4);
          transition: color .3s ease, background .3s ease, box-shadow .3s ease, transform .2s ease;
        }

        .register-page-root .submit-btn::before {
          content: "";
          position: absolute;
          top: 0;
          left: -60%;
          width: 40%;
          height: 100%;
          background: linear-gradient(115deg, transparent, rgba(255, 255, 255, 0.6), transparent);
          transform: skewX(-20deg);
          transition: left .6s ease;
        }

        .register-page-root .submit-btn:hover:not(:disabled)::before {
          left: 130%;
        }

        .register-page-root .submit-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          background: #CBD5E1;
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.45);
        }

        .register-page-root .submit-btn:active:not(:disabled) {
          transform: translateY(0) scale(0.98);
        }

        .register-page-root .submit-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .register-page-root .back-step-btn {
          height: 42px;
          padding: 0 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          border: 1px solid rgba(73, 79, 85, 0.4);
          outline: none;
          border-radius: 11px;
          cursor: pointer;
          background: #1C232B;
          color: #949599;
          font-size: 13px;
          font-weight: 500;
          transition: color .2s ease, border-color .2s ease;
        }

        .register-page-root .back-step-btn:hover {
          color: #EFEFF1;
          border-color: rgba(255, 255, 255, 0.3);
        }

        /* Divider */
        .register-page-root .divider-row {
          display: flex;
          align-items: center;
          gap: 8px;
          margin: 10px 0;
        }
        .register-page-root .divider-line {
          flex: 1;
          height: 1px;
          background: rgba(73, 79, 85, 0.35);
        }
        .register-page-root .divider-text {
          font-size: 10px;
          color: #494F55;
          text-transform: uppercase;
          letter-spacing: 1px;
        }

        /* Footer Links */
        .register-page-root .footer-links {
          text-align: center;
          margin-top: 10px;
          font-size: 11.5px;
          color: #949599;
        }

        .register-page-root .footer-links a {
          color: #EFEFF1;
          font-weight: 600;
          text-decoration: none;
          transition: color .2s ease;
          margin-left: 3px;
        }

        .register-page-root .footer-links a:hover {
          color: #ffffff;
          text-decoration: underline;
        }

        /* =========================================
           MOBILE RESPONSIVE VIEW (<640px)
           ========================================= */
        @media (max-width: 640px) {
          .register-page-root {
            padding: 20px 14px;
            align-items: center;
          }
          .register-page-root .circle-container {
            width: 100%;
            max-width: 420px;
            height: auto;
            min-height: auto;
          }
          .register-page-root .glass-circle {
            width: 100%;
            max-width: 420px;
            height: auto;
            min-height: auto;
            border-radius: 28px;
            padding: 30px 22px 24px;
            box-shadow:
              -10px -10px 24px rgba(255, 255, 255, 0.025),
              16px 16px 36px rgba(0, 0, 0, 0.7);
          }
          .register-page-root .glass-circle::before {
            border-radius: 22px;
            inset: 8px;
          }
          .register-page-root .form-inner {
            width: 100%;
          }
          .register-page-root h1 {
            font-size: 26px;
          }
          .register-page-root .subtitle {
            font-size: 11.5px;
            margin-bottom: 12px;
          }
          .register-page-root .input-box {
            margin-bottom: 12px;
          }
          .register-page-root .input-box input,
          .register-page-root .input-box select {
            height: 44px;
            font-size: 13.5px;
            padding-left: 42px;
          }
          .register-page-root .submit-btn,
          .register-page-root .back-step-btn {
            height: 44px;
            font-size: 13.5px;
          }
        }

        @media (max-width: 380px) {
          .register-page-root .glass-circle {
            padding: 24px 16px 20px;
            border-radius: 22px;
          }
          .register-page-root .glass-circle::before {
            border-radius: 18px;
            inset: 6px;
          }
          .register-page-root h1 {
            font-size: 23px;
          }
          .register-page-root .input-box input {
            font-size: 12.5px;
            padding-left: 38px;
          }
        }
      `}),e.jsxs("div",{className:"bg-ambient",children:[e.jsx("div",{className:"ambient-orb ambient-orb-1"}),e.jsx("div",{className:"ambient-orb ambient-orb-2"})]}),e.jsx("div",{className:"grid-overlay"}),e.jsx(u.div,{initial:{opacity:0,scale:.95},animate:{opacity:1,scale:1},transition:{duration:.35,ease:"easeOut"},className:"circle-container",children:e.jsx("div",{className:"glass-circle",children:e.jsx("div",{className:"form-inner",children:e.jsxs("form",{onSubmit:O(M),noValidate:!0,children:[e.jsx("input",{type:"text",...s("website"),tabIndex:-1,autoComplete:"off","aria-hidden":"true",style:{display:"none"}}),e.jsx("div",{className:"flex justify-center mb-1.5",children:e.jsx(ee,{size:"md",showText:!1,asLink:!1})}),e.jsx("h1",{children:"Create Account"}),e.jsxs("div",{className:"subtitle",children:[o===1&&(i==="organizer"?"Organization basics":"Account details"),o===2&&(i==="organizer"?"Organization profile":"Security & contact"),o===3&&"Security & credentials"]}),e.jsx("div",{className:"step-progress",children:Array.from({length:N}).map((t,a)=>e.jsx("div",{className:`step-bar ${o===a+1?"active":o>a+1?"completed":"inactive"}`},a))}),w&&e.jsxs("div",{className:"alert-box",role:"alert",children:[e.jsx(G,{size:13,style:{flexShrink:0}}),e.jsx("span",{children:w})]}),e.jsxs(ie,{mode:"wait",children:[o===1&&e.jsxs(u.div,{initial:{opacity:0,x:16},animate:{opacity:1,x:0},exit:{opacity:0,x:-16},transition:{duration:.2},children:[e.jsxs("div",{className:"role-pills",children:[e.jsxs("button",{type:"button",onClick:()=>{j("attendee"),x(1)},className:`role-pill-btn ${i==="attendee"?"active":""}`,children:[e.jsx(Y,{size:13})," Attendee"]}),e.jsxs("button",{type:"button",onClick:()=>{j("organizer"),x(1)},className:`role-pill-btn ${i==="organizer"?"active":""}`,children:[e.jsx(C,{size:13})," Organizer"]})]}),i==="attendee"?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(F,{size:15})}),e.jsx("input",{type:"text",placeholder:"Full Name *",autoComplete:"name",...s("name",{required:"Full name is required"})})]}),r.name&&e.jsx("div",{className:"field-error",children:r.name.message}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(E,{size:15})}),e.jsx("input",{type:"email",placeholder:"Email address *",autoComplete:"email",...s("email",{required:"Email is required",pattern:{value:/^\S+@\S+\.\S+$/,message:"Enter a valid email"}})})]}),r.email&&e.jsx("div",{className:"field-error",children:r.email.message})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(F,{size:15})}),e.jsx("input",{type:"text",placeholder:"Contact Person Full Name *",autoComplete:"name",...s("name",{required:"Contact name is required"})})]}),r.name&&e.jsx("div",{className:"field-error",children:r.name.message}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(C,{size:15})}),e.jsx("input",{type:"text",placeholder:"Organization / Brand Name *",...s("organizationName",{required:"Organization name is required"})})]}),r.organizationName&&e.jsx("div",{className:"field-error",children:r.organizationName.message})]}),e.jsxs("button",{type:"button",onClick:z,className:"submit-btn",children:[e.jsx("span",{children:"Continue"}),e.jsx(S,{size:14})]}),e.jsxs("div",{className:"divider-row",children:[e.jsx("div",{className:"divider-line"}),e.jsx("span",{className:"divider-text",children:"or"}),e.jsx("div",{className:"divider-line"})]}),e.jsx(re,{role:i,organizerData:{organizationName:d("organizationName"),category:d("category"),city:d("city"),phone:d("phone")},text:"Continue with Google",className:"!w-full !py-2 !text-xs !bg-[#1C232B] !border !border-[#494F55]/40 hover:!border-white/40 !rounded-xl shadow-none"})]},"step-1"),o===2&&i==="organizer"&&e.jsxs(u.div,{initial:{opacity:0,x:16},animate:{opacity:1,x:0},exit:{opacity:0,x:-16},transition:{duration:.2},children:[e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(W,{size:15})}),e.jsxs("select",{...s("category",{required:"Please select category"}),children:[e.jsx("option",{value:"Music & Concerts",children:"Music & Concerts"}),e.jsx("option",{value:"Nightlife & Parties",children:"Nightlife & Parties"}),e.jsx("option",{value:"Corporate & Conferences",children:"Corporate & Conferences"}),e.jsx("option",{value:"Festivals & Cultural",children:"Festivals & Cultural"}),e.jsx("option",{value:"Sports & Fitness",children:"Sports & Fitness"}),e.jsx("option",{value:"Theatre & Arts",children:"Theatre & Arts"}),e.jsx("option",{value:"Community & Lifestyle",children:"Community & Lifestyle"}),e.jsx("option",{value:"Other",children:"Other Events"})]})]}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(H,{size:15})}),e.jsx("input",{type:"text",placeholder:"City / Location *",...s("city",{required:"City is required"})})]}),r.city&&e.jsx("div",{className:"field-error",children:r.city.message}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(K,{size:15})}),e.jsx("input",{type:"text",placeholder:"Website or Social link *",...s("websiteUrl",{required:"Website or social link is required"})})]}),r.websiteUrl&&e.jsx("div",{className:"field-error",children:r.websiteUrl.message}),e.jsx("div",{className:"input-box",style:{height:"auto",minHeight:"68px",padding:"8px 12px"},children:e.jsx("textarea",{placeholder:"Organization Bio & Event Scope *",rows:2,className:"w-full bg-transparent text-xs text-[#EFEFF1] placeholder-[#494F55] focus:outline-none resize-none",...s("description",{required:"Organization bio and event scope is required",minLength:{value:10,message:"Please provide at least 10 characters"}})})}),r.description&&e.jsx("div",{className:"field-error",children:r.description.message}),e.jsxs("div",{className:"actions-row",children:[e.jsxs("button",{type:"button",onClick:k,className:"back-step-btn",children:[e.jsx(P,{size:14})," Back"]}),e.jsxs("button",{type:"button",onClick:z,className:"submit-btn",children:[e.jsx("span",{children:"Next"}),e.jsx(S,{size:14})]})]})]},"step-2-organizer"),(o===2&&i==="attendee"||o===3&&i==="organizer")&&e.jsxs(u.div,{initial:{opacity:0,x:16},animate:{opacity:1,x:0},exit:{opacity:0,x:-16},transition:{duration:.2},children:[i==="organizer"&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(E,{size:15})}),e.jsx("input",{type:"email",placeholder:"Email address *",autoComplete:"email",...s("email",{required:"Email is required",pattern:{value:/^\S+@\S+\.\S+$/,message:"Enter a valid email"}})})]}),r.email&&e.jsx("div",{className:"field-error",children:r.email.message})]}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(_,{size:15})}),e.jsx("input",{type:"tel",placeholder:"Phone number *",autoComplete:"tel",...s("phone",{required:"Phone is required"})})]}),r.phone&&e.jsx("div",{className:"field-error",children:r.phone.message}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(B,{size:15})}),e.jsx("input",{type:g?"text":"password",className:"has-eye",placeholder:"Password (min 8 chars) *",autoComplete:"new-password",...s("password",{required:"Password is required",validate:{length:t=>t.length>=8||"Min 8 characters",letter:t=>/[a-zA-Z]/.test(t)||"Needs a letter",number:t=>/\d/.test(t)||"Needs a number"}})}),e.jsx("button",{type:"button",className:"toggle-eye",onClick:()=>U(!g),"aria-label":g?"Hide password":"Show password",children:g?e.jsx(q,{size:14}):e.jsx(A,{size:14})})]}),r.password&&e.jsx("div",{className:"field-error",children:r.password.message}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(B,{size:15})}),e.jsx("input",{type:m?"text":"password",className:"has-eye",placeholder:"Confirm password *",autoComplete:"new-password",...s("confirmPassword",{required:"Confirm password",validate:t=>t===R||"Passwords do not match"})}),e.jsx("button",{type:"button",className:"toggle-eye",onClick:()=>L(!m),"aria-label":m?"Hide password":"Show password",children:m?e.jsx(q,{size:14}):e.jsx(A,{size:14})})]}),r.confirmPassword&&e.jsx("div",{className:"field-error",children:r.confirmPassword.message}),e.jsxs("div",{className:"terms-row",onClick:()=>y(!l),role:"checkbox","aria-checked":l,tabIndex:0,onKeyDown:t=>{(t.key===" "||t.key==="Enter")&&(t.preventDefault(),y(!l))},children:[e.jsx("div",{className:`terms-checkbox ${l?"checked":""}`,children:l&&e.jsx(X,{size:11,className:"text-white",strokeWidth:3})}),e.jsxs("span",{className:"terms-text",children:["I agree to the"," ",e.jsx(f,{to:"/terms",onClick:t=>t.stopPropagation(),target:"_blank",rel:"noreferrer",children:"Terms"})," ","&"," ",e.jsx(f,{to:"/privacy",onClick:t=>t.stopPropagation(),target:"_blank",rel:"noreferrer",children:"Privacy"})]})]}),e.jsxs("div",{className:"actions-row",children:[e.jsxs("button",{type:"button",onClick:k,className:"back-step-btn",disabled:h,children:[e.jsx(P,{size:14})," Back"]}),e.jsx("button",{type:"submit",id:"registerSubmitBtn",className:"submit-btn",disabled:h,children:h?e.jsxs(e.Fragment,{children:[e.jsx(Z,{size:15,className:"animate-spin"}),e.jsx("span",{children:"Creating..."})]}):e.jsxs(e.Fragment,{children:[e.jsx(J,{size:15}),e.jsx("span",{children:"Create"})]})})]})]},"step-final")]}),e.jsxs("div",{className:"footer-links",children:["Already have an account?"," ",e.jsx(f,{to:"/login",children:"Sign in"})]})]})})})})]})}export{le as default};
