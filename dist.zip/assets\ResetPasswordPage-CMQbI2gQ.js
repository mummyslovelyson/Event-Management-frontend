import{l as S,aC as P,r,j as e,V as L,z as B,H as R,bm as q,bb as I,bl as u,b7 as h,y as Y,ad as A,L as M,aK as G}from"./vendor-react-kjnsrEhy.js";import{u as T,z as f}from"./vendor-utils-D3rtD2hg.js";import{a as D,v as H}from"./index-B72eX1Og.js";import{m as V}from"./vendor-motion-7KmqxjHb.js";function Z(){const w=S(),[p]=P(),j=p.get("token")||"",y=p.get("code")||j,c=p.get("email")||"",[a,v]=r.useState(!1),[i,k]=r.useState(!1),[g,l]=r.useState(!1),[z,N]=r.useState(!1),[b,d]=r.useState(""),{register:o,handleSubmit:F,watch:C,formState:{errors:X}}=T({defaultValues:{email:c,code:y}}),s=C("password")||"",n=r.useMemo(()=>{let t=0;return s.length>=8&&t++,/[A-Z]/.test(s)&&t++,/[0-9]/.test(s)&&t++,/[^A-Za-z0-9]/.test(s)&&t++,s.length===0?{width:"0%",color:"#494F55",label:"Weak",labelColor:"#949599"}:t<=1?{width:"25%",color:"#e74c3c",label:"Weak",labelColor:"#f87171"}:t===2?{width:"50%",color:"#f39c12",label:"Fair",labelColor:"#fbbf24"}:t===3?{width:"75%",color:"#38bdf8",label:"Good",labelColor:"#38bdf8"}:{width:"100%",color:"#34d399",label:"Strong",labelColor:"#34d399"}},[s]),E=async t=>{if(l(!0),d(""),t.password!==t.confirmPassword){d("Passwords do not match"),l(!1);return}try{const x={email:t.email,code:t.code,token:t.code,password:t.password,website:t.website};await H(x),N(!0),f.success("Password updated successfully! Redirecting...",{duration:4e3}),setTimeout(()=>w("/login"),1800)}catch(x){const m=x.response?.data?.message||"Could not reset password. Invalid or expired code.";d(m),f.error(m)}finally{l(!1)}};return e.jsxs("div",{className:"reset-page-root",children:[e.jsx("style",{children:`
        .reset-page-root {
          min-height: 100vh;
          width: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          background-color: #1C232B;
          color: #EFEFF1;
          font-family: 'Inter', system-ui, -apple-system, sans-serif;
          position: relative;
          overflow: hidden;
          padding: 20px;
        }

        /* Ambient Glow Background */
        .reset-page-root .bg-ambient {
          position: absolute;
          inset: 0;
          pointer-events: none;
          overflow: hidden;
        }
        .reset-page-root .ambient-orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(80px);
          opacity: 0.18;
        }
        .reset-page-root .ambient-orb-1 {
          width: 500px;
          height: 500px;
          background: #ffffff;
          top: -100px;
          left: 50%;
          transform: translateX(-50%);
        }
        .reset-page-root .ambient-orb-2 {
          width: 400px;
          height: 400px;
          background: #b21414;
          bottom: -80px;
          right: 15%;
          opacity: 0.12;
        }

        /* Grid Pattern */
        .reset-page-root .grid-overlay {
          position: absolute;
          inset: 0;
          opacity: 0.03;
          pointer-events: none;
          background-image: linear-gradient(#EFEFF1 1px, transparent 1px), linear-gradient(90deg, #EFEFF1 1px, transparent 1px);
          background-size: 40px 40px;
        }

        /* Circular Container */
        .reset-page-root .circle-container {
          position: relative;
          width: 530px;
          height: 530px;
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 10;
        }

        /* Neumorphic Glass Circle using Project Colors */
        .reset-page-root .glass-circle {
          position: relative;
          width: 530px;
          height: 530px;
          border-radius: 50%;
          display: flex;
          justify-content: center;
          align-items: center;
          background: #161D22;
          box-shadow:
            -18px -18px 40px rgba(255, 255, 255, 0.035),
            24px 24px 50px rgba(0, 0, 0, 0.75),
            inset -1px -1px 1px rgba(255, 255, 255, 0.08),
            inset 1px 1px 1px rgba(0, 0, 0, 0.6);
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        /* Inner Ring with Depth */
        .reset-page-root .glass-circle::before {
          content: "";
          position: absolute;
          inset: 14px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.06);
          box-shadow:
            inset 4px 4px 12px rgba(0, 0, 0, 0.45),
            inset -3px -3px 8px rgba(255, 255, 255, 0.03);
          pointer-events: none;
        }

        /* Form Structure */
        .reset-page-root .reset-form {
          position: relative;
          width: 300px;
          z-index: 20;
        }

        /* Titles */
        .reset-page-root .reset-form h1 {
          color: #EFEFF1;
          font-size: 30px;
          font-weight: 700;
          letter-spacing: .5px;
          margin-bottom: 2px;
          text-align: center;
          text-shadow:
            1px 1px 2px rgba(0, 0, 0, 0.8),
            -1px -1px 1px rgba(255, 255, 255, 0.06);
        }

        .reset-page-root .reset-form .subtitle {
          text-align: center;
          color: #949599;
          font-size: 12px;
          font-weight: 500;
          letter-spacing: .3px;
          margin-bottom: 4px;
        }

        .reset-page-root .reset-form .desc-text {
          text-align: center;
          color: #949599;
          font-size: 11px;
          line-height: 1.35;
          margin-bottom: 12px;
          padding: 0 4px;
        }

        /* Alert Notification Box */
        .reset-page-root .alert-box {
          border-radius: 10px;
          padding: 7px 10px;
          font-size: 11px;
          text-align: center;
          margin-bottom: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          line-height: 1.35;
          animation: alertFadeIn 0.3s ease;
        }
        .reset-page-root .alert-box.error {
          background: rgba(161, 15, 15, 0.15);
          border: 1px solid rgba(161, 15, 15, 0.35);
          color: #fca5a5;
        }
        .reset-page-root .alert-box.success {
          background: rgba(43, 122, 75, 0.15);
          border: 1px solid rgba(43, 122, 75, 0.35);
          color: #86efac;
        }

        @keyframes alertFadeIn {
          from { opacity: 0; transform: translateY(-4px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Recessed Neumorphic Input Box */
        .reset-page-root .input-box {
          position: relative;
          margin-bottom: 10px;
        }

        .reset-page-root .input-box .input-icon {
          position: absolute;
          left: 15px;
          top: 50%;
          transform: translateY(-50%);
          color: #949599;
          z-index: 2;
          pointer-events: none;
          transition: color .25s ease;
          display: flex;
          align-items: center;
        }

        .reset-page-root .input-box input {
          width: 100%;
          height: 40px;
          padding: 0 15px 0 42px;
          border: 1px solid rgba(73, 79, 85, 0.35);
          outline: none;
          background: #1C232B;
          color: #EFEFF1;
          font-family: inherit;
          font-size: 13px;
          font-weight: 500;
          letter-spacing: .2px;
          border-radius: 11px;
          box-shadow:
            inset 3px 3px 6px rgba(0, 0, 0, 0.45),
            inset -2px -2px 5px rgba(255, 255, 255, 0.03);
          transition: box-shadow .3s ease, border-color .3s ease;
        }

        .reset-page-root .input-box input.has-eye {
          padding-right: 40px;
        }

        .reset-page-root .input-box input::placeholder {
          color: #494F55;
          font-weight: 400;
        }

        .reset-page-root .input-box input:focus {
          border-color: rgba(255, 255, 255, 0.35);
          box-shadow:
            inset 3px 3px 6px rgba(0, 0, 0, 0.6),
            inset -2px -2px 5px rgba(255, 255, 255, 0.05),
            0 0 0 1px rgba(255, 255, 255, 0.15);
        }

        .reset-page-root .input-box input:focus + .input-icon,
        .reset-page-root .input-box:focus-within .input-icon {
          color: #EFEFF1;
        }

        .reset-page-root .input-box .toggle-eye {
          position: absolute;
          right: 12px;
          top: 50%;
          transform: translateY(-50%);
          color: #949599;
          cursor: pointer;
          background: transparent;
          border: none;
          padding: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: color .25s ease;
          z-index: 5;
        }

        .reset-page-root .input-box .toggle-eye:hover {
          color: #EFEFF1;
        }

        /* Password Strength Bar */
        .reset-page-root .strength-wrapper {
          display: flex;
          align-items: center;
          gap: 6px;
          margin: -4px 0 10px 2px;
        }

        .reset-page-root .strength-bar {
          flex: 1;
          height: 3.5px;
          background: #242B32;
          border-radius: 4px;
          overflow: hidden;
          position: relative;
        }

        .reset-page-root .strength-fill {
          height: 100%;
          transition: width 0.3s ease, background 0.3s ease;
          border-radius: 4px;
        }

        .reset-page-root .strength-text {
          font-size: 10.5px;
          font-weight: 500;
          min-width: 46px;
          text-align: right;
        }

        /* Submit Button */
        .reset-page-root .submit-btn {
          position: relative;
          width: 100%;
          height: 42px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin: 6px auto 0;
          overflow: hidden;
          border: none;
          outline: none;
          border-radius: 12px;
          cursor: pointer;
          font-family: inherit;
          font-size: 13.5px;
          font-weight: 600;
          letter-spacing: .8px;
          text-transform: uppercase;
          color: #1C232B;
          background: #EFEFF1;
          box-shadow:
            0 4px 14px rgba(0, 0, 0, 0.3),
            -4px -4px 10px rgba(255, 255, 255, 0.05),
            4px 4px 10px rgba(0, 0, 0, 0.4);
          transition: color .3s ease, background .3s ease, box-shadow .3s ease, transform .2s ease;
        }

        .reset-page-root .submit-btn::before {
          content: "";
          position: absolute;
          top: 0;
          left: -60%;
          width: 40%;
          height: 100%;
          background: linear-gradient(115deg, transparent, rgba(255, 255, 255, 0.6), transparent);
          transform: skewX(-20deg);
          transition: left .6s ease;
        }

        .reset-page-root .submit-btn:hover:not(:disabled)::before {
          left: 130%;
        }

        .reset-page-root .submit-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          background: #CBD5E1;
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.45);
        }

        .reset-page-root .submit-btn:active:not(:disabled) {
          transform: translateY(0) scale(0.98);
        }

        .reset-page-root .submit-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        /* Back to Login Link */
        .reset-page-root .back-btn-box {
          text-align: center;
          margin-top: 14px;
        }

        .reset-page-root .back-btn-box a {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          color: #949599;
          font-size: 12px;
          font-weight: 500;
          text-decoration: none;
          transition: transform .2s ease, color .2s ease;
        }

        .reset-page-root .back-btn-box a:hover {
          color: #EFEFF1;
          transform: translateX(-3px);
        }

        /* Responsive */
        @media (max-width: 640px) {
          .reset-page-root {
            padding: 20px 14px;
            align-items: center;
          }
          .reset-page-root .circle-container {
            width: 100%;
            max-width: 420px;
            height: auto;
            min-height: auto;
          }
          .reset-page-root .glass-circle {
            width: 100%;
            max-width: 420px;
            height: auto;
            min-height: auto;
            border-radius: 28px;
            padding: 30px 22px 24px;
            box-shadow:
              -10px -10px 24px rgba(255, 255, 255, 0.025),
              16px 16px 36px rgba(0, 0, 0, 0.7);
          }
          .reset-page-root .glass-circle::before {
            border-radius: 22px;
            inset: 8px;
          }
          .reset-page-root .reset-form {
            width: 100%;
          }
          .reset-page-root .reset-form h1 {
            font-size: 26px;
          }
          .reset-page-root .reset-form .subtitle {
            font-size: 11.5px;
            margin-bottom: 6px;
          }
          .reset-page-root .reset-form .desc-text {
            font-size: 11px;
            margin-bottom: 12px;
          }
          .reset-page-root .input-box {
            margin-bottom: 12px;
          }
          .reset-page-root .input-box input {
            height: 42px;
            font-size: 13px;
            padding-left: 40px;
          }
          .reset-page-root .input-box .input-icon {
            left: 14px;
          }
          .reset-page-root .submit-btn {
            height: 44px;
            font-size: 13.5px;
            margin-top: 8px;
          }
          .reset-page-root .back-btn-box {
            margin-top: 14px;
          }
        }

        @media (max-width: 380px) {
          .reset-page-root .glass-circle {
            padding: 24px 16px 20px;
            border-radius: 22px;
          }
          .reset-page-root .glass-circle::before {
            border-radius: 18px;
            inset: 6px;
          }
          .reset-page-root .reset-form h1 {
            font-size: 23px;
          }
          .reset-page-root .input-box input {
            font-size: 12.5px;
            padding-left: 36px;
          }
        }
      `}),e.jsxs("div",{className:"bg-ambient",children:[e.jsx("div",{className:"ambient-orb ambient-orb-1"}),e.jsx("div",{className:"ambient-orb ambient-orb-2"})]}),e.jsx("div",{className:"grid-overlay"}),e.jsx(V.div,{initial:{opacity:0,scale:.95},animate:{opacity:1,scale:1},transition:{duration:.35,ease:"easeOut"},className:"circle-container",children:e.jsx("div",{className:"glass-circle",children:e.jsxs("form",{className:"reset-form",onSubmit:F(E),noValidate:!0,children:[e.jsx("input",{type:"text",...o("website"),tabIndex:-1,autoComplete:"off","aria-hidden":"true",style:{display:"none"}}),e.jsx("div",{className:"flex justify-center mb-2",children:e.jsx(D,{size:"md",showText:!1,asLink:!1})}),e.jsx("h1",{children:"Reset"}),e.jsx("div",{className:"subtitle",children:"Set a new password"}),e.jsx("p",{className:"desc-text",children:"Must be at least 8 characters long with numbers or symbols."}),b&&e.jsxs("div",{className:"alert-box error",role:"alert",children:[e.jsx(L,{size:13,style:{flexShrink:0}}),e.jsx("span",{children:b})]}),z&&e.jsxs("div",{className:"alert-box success",role:"status",children:[e.jsx(B,{size:13,style:{flexShrink:0}}),e.jsx("span",{children:"Password updated! Redirecting..."})]}),c?e.jsx("input",{type:"hidden",...o("email")}):e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(R,{size:15})}),e.jsx("input",{type:"email",placeholder:"Your email address",autoComplete:"email",...o("email",{required:"Email is required"})})]}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(q,{size:15})}),e.jsx("input",{type:"text",maxLength:6,placeholder:"6-digit reset code",autoComplete:"one-time-code",...o("code",{required:"6-digit code is required",minLength:{value:6,message:"Code must be 6 digits"}})})]}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(I,{size:15})}),e.jsx("input",{type:a?"text":"password",className:"has-eye",placeholder:"New password",autoComplete:"new-password",...o("password",{required:"Password is required",minLength:{value:8,message:"Minimum 8 characters"}})}),e.jsx("button",{type:"button",className:"toggle-eye",onClick:()=>v(!a),"aria-label":a?"Hide password":"Show password",children:a?e.jsx(u,{size:14}):e.jsx(h,{size:14})})]}),e.jsxs("div",{className:"strength-wrapper",children:[e.jsx("div",{className:"strength-bar",children:e.jsx("div",{className:"strength-fill",style:{width:n.width,background:n.color}})}),e.jsx("span",{className:"strength-text",style:{color:n.labelColor},children:n.label})]}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{className:"input-icon",children:e.jsx(Y,{size:15})}),e.jsx("input",{type:i?"text":"password",className:"has-eye",placeholder:"Confirm password",autoComplete:"new-password",...o("confirmPassword",{required:"Confirm password is required",validate:t=>t===s||"Passwords do not match"})}),e.jsx("button",{type:"button",className:"toggle-eye",onClick:()=>k(!i),"aria-label":i?"Hide password":"Show password",children:i?e.jsx(u,{size:14}):e.jsx(h,{size:14})})]}),e.jsx("button",{type:"submit",className:"submit-btn",disabled:g,children:g?e.jsxs(e.Fragment,{children:[e.jsx(A,{size:15,className:"animate-spin"}),e.jsx("span",{children:"Updating..."})]}):e.jsx("span",{children:"Update Password"})}),e.jsx("div",{className:"back-btn-box",children:e.jsxs(M,{to:"/login",children:[e.jsx(G,{size:13})," Back to Login"]})})]})})})]})}export{Z as default};
